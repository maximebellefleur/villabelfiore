<?php
/** @var array $bed */
/** @var array $catalog */
/** @var array $cropsById */
/** @var array $item */
/** @var array|null $parentGarden */
/** @var string $today */

use App\Support\GardenHelpers;
use App\Support\CSRF;

$csrf = CSRF::getToken();
$mode = $mode ?? 'merged';
$bedId = (int)$item['id'];
?>
<div class="rg-bed-page" id="rgBedPage" data-item-id="<?= $bedId ?>">

  <!-- Header -->
  <div class="rg-bed-header">
    <a href="<?= $parentGarden ? url('/garden') : url('/items/' . $bedId) ?>" class="rg-bed-back" aria-label="<?= $parentGarden ? 'Back to garden hub' : 'Back to bed' ?>">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
    </a>
    <div style="flex:1;min-width:0">
      <?php if ($parentGarden): ?>
      <div class="rg-label-tiny"><?= e($parentGarden['name']) ?></div>
      <?php endif; ?>
      <div class="rg-bed-title"><?= e($item['name']) ?></div>
    </div>
    <a href="<?= url('/items/' . $bedId . '/edit') ?>" aria-label="Edit bed" style="display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:50%;background:rgba(0,0,0,.07);color:#444;flex-shrink:0;text-decoration:none">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>
    </a>
  </div>

  <!-- Mode tabs -->
  <div class="rg-mode-tabs" role="tablist">
    <a href="<?= url('/items/' . $bedId . '/planting') ?>" class="rg-mode-tab <?= $mode==='merged' ? 'is-active' : '' ?>">🌱 Plant</a>
    <a href="<?= url('/items/' . $bedId . '/planting/inline') ?>" class="rg-mode-tab <?= $mode==='inline' ? 'is-active' : '' ?>">⏭ Plan</a>
    <a href="<?= url('/items/' . $bedId . '/planting/timeline') ?>" class="rg-mode-tab rg-mode-tab--desktop <?= $mode==='timeline' ? 'is-active' : '' ?>">📅 Timeline</a>
  </div>

  <?php include BASE_PATH . '/resources/views/partials/flash.php'; ?>

  <?php if (!$parentGarden): ?>
  <div style="margin:12px 0;padding:14px 16px;background:#fff3cd;border:1px solid #ffc107;border-radius:var(--radius);display:flex;gap:12px;align-items:flex-start">
    <span style="font-size:1.4rem;flex-shrink:0">🟫</span>
    <div>
      <div style="font-weight:700;font-size:.95rem;margin-bottom:4px">Prep Bed — not assigned to a garden</div>
      <div style="font-size:.82rem;color:#856404;line-height:1.5">Assign this bed to an Active Garden before adding plantings. Logs, treatments and harvests can still be recorded from the bed's <a href="<?= url('/items/' . $bedId) ?>" style="color:#856404;font-weight:600">item page</a>.</div>
      <a href="<?= url('/garden') ?>" style="display:inline-block;margin-top:8px;font-size:.82rem;font-weight:600;color:#856404;text-decoration:underline">Go to Active Gardens →</a>
    </div>
  </div>
  <?php elseif (empty($bed['lines'])): ?>
    <div class="rg-week-empty">No lines configured. <a href="<?= url('/items/' . $bedId . '/edit') ?>">Set bed dimensions</a> to add lines.</div>
  <?php else: ?>

  <!-- Lines -->
  <?php foreach ($bed['lines'] as $idx => $line):
    $segments = GardenHelpers::computeSegments($line, $cropsById);
    $fill     = GardenHelpers::computeFill($line, $cropsById);
    $totalSlots = max(1, (int)floor((int)$line['lengthCm'] / 5));
    $overcap = $fill['used'] > (int)$line['lengthCm'];

    // Build slot map (1 slot = 5 cm)
    $slots = array_fill(0, $totalSlots, null);
    $cur = 0;
    foreach ($line['plantings'] as $p) {
      $c = $cropsById[$p['cropId']] ?? null;
      if (!$c) continue;
      $slotsPerPlant = max(1, (int)round((int)$c['spacing_cm'] / 5));
      for ($n = 0; $n < (int)$p['plants'] && $cur + $slotsPerPlant <= $totalSlots; $n++) {
        for ($k = 0; $k < $slotsPerPlant; $k++) {
          $slots[$cur + $k] = ['cropId' => (int)$c['id'], 'head' => $k === 0];
        }
        $cur += $slotsPerPlant;
      }
    }
    $suggestions = GardenHelpers::getSuggestions($line, $catalog, $cropsById);
  ?>
    <div class="rg-line <?= $overcap ? 'rg-line--overcap' : '' ?>" data-line="<?= (int)$line['lineNumber'] ?>">
      <div class="rg-line-head">
        <div class="rg-line-num"><?= (int)$line['lineNumber'] ?></div>
        <div class="rg-line-name">
          Line <?= (int)$line['lineNumber'] ?>
          <span class="rg-line-fill">· <?= (int)$fill['used'] ?>/<?= (int)$line['lengthCm'] ?>cm</span>
        </div>
        <?php if (!empty($line['plantings'])): ?>
        <div class="rg-line-actions">
          <button class="btn btn-secondary btn-sm rg-harvest-btn" data-line="<?= (int)$line['lineNumber'] ?>" style="border-color:var(--color-accent);color:var(--color-accent)">🌾 Harvest</button>
        </div>
        <?php endif; ?>
      </div>

      <!-- Stripe -->
      <div class="rg-stripe">
        <?php foreach ($segments as $s):
          $w = max(0.5, $s['pct'] * 100);
          $c = $s['crop'];
          $color = $c['color'];
        ?>
          <div class="rg-stripe-seg" style="width: <?= $w ?>%; background: linear-gradient(180deg, <?= e($color) ?>, <?= e($color) ?>dd);">
            <?php if ($s['pct'] > 0.10): ?>
            <span><?= e($c['emoji']) ?> <?= (int)$s['plants'] ?></span>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Dot grid -->
      <div class="rg-dotgrid <?= $totalSlots > 60 ? 'rg-dotgrid--dense' : '' ?>">
        <div class="rg-dots">
          <?php foreach ($slots as $i => $s):
            if ($s):
              $crop = $cropsById[$s['cropId']] ?? null;
              $color = $crop ? $crop['color'] : '#A66141';
              $head = !empty($s['head']) ? ' is-head' : '';
              echo '<div class="rg-dot rg-dot--filled' . $head . '" style="background:' . e($color) . ';border-color:' . e($color) . '" title="' . e($crop['name'] ?? '') . '"></div>';
            else:
              echo '<div class="rg-dot rg-dot--clickable" data-slot="' . (int)$i . '" title="tap to plant"></div>';
            endif;
          endforeach; ?>
        </div>
      </div>

      <!-- Stepper chips -->
      <?php if (!empty($line['plantings'])): ?>
      <div class="rg-steppers">
        <?php foreach ($line['plantings'] as $p):
          $c = $cropsById[$p['cropId']] ?? null;
          if (!$c) continue;
          $color = $c['color'];
        ?>
          <div class="rg-stepchip" style="background:<?= e($color) ?>15;border:1px solid <?= e($color) ?>55;color:<?= e($color) ?>">
            <span class="rg-stepchip-emoji"><?= e($c['emoji']) ?></span>
            <span><?= e($c['name']) ?></span>
            <div class="rg-stepper" data-planting-id="<?= (int)$p['id'] ?>">
              <button type="button" class="rg-step-minus" style="color:<?= e($color) ?>" aria-label="-1">−</button>
              <input type="number" class="rg-stepper-val" min="1" step="1" value="<?= (int)$p['plants'] ?>" inputmode="numeric" aria-label="Plant count">
              <button type="button" class="rg-step-plus"  style="color:<?= e($color) ?>" aria-label="+1">+</button>
            </div>
            <button type="button" class="rg-stepchip-remove" data-planting-id="<?= (int)$p['id'] ?>" title="Remove <?= e($c['name']) ?> from this line">✕</button>
          </div>
        <?php endforeach; ?>
        <button type="button" class="rg-clear-btn" data-line="<?= (int)$line['lineNumber'] ?>">Clear All</button>
      </div>
      <?php endif; ?>

      <!-- Suggestions -->
      <?php if ($fill['remaining'] > 0 && !empty($suggestions)): ?>
      <div class="rg-suggest-row">
        <span class="rg-suggest-row-label">✨ <?= (int)$fill['remaining'] ?>cm · try</span>
        <?php foreach (array_slice($suggestions, 0, 3) as $sc):
          $color = $sc['color'];
        ?>
          <button type="button" class="rg-suggest-chip rg-plant-action" data-line="<?= (int)$line['lineNumber'] ?>" data-crop-id="<?= (int)$sc['id'] ?>" data-spacing="<?= (int)$sc['spacing_cm'] ?>" style="border-color:<?= e($color) ?>">
            <span class="rg-suggest-chip-bullet" style="background:<?= e($color) ?>22"><?= e($sc['emoji']) ?></span>
            Try <?= e($sc['name']) ?>
            <span class="rg-mono" style="font-size:.6rem;color:var(--color-text-muted)">+<?= (int)$sc['spacing_cm'] ?>cm</span>
          </button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>

  <?php endif; ?>

  <?php if ($parentGarden && !empty($bed['lines'])): ?>
  <!-- Fixed crop palette -->
  <div class="rg-palette" id="rgPalette">
    <div id="rgPaletteLabel" style="font-size:.7rem;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--color-text-muted);margin-bottom:6px">
      Tap a line above to select it ↑
    </div>
    <div class="rg-palette-row">
      <?php foreach ($catalog as $c): ?>
      <button type="button" class="rg-palette-chip" draggable="true" data-crop-id="<?= (int)$c['id'] ?>" data-color="<?= e($c['color']) ?>" data-spacing="<?= (int)$c['spacing_cm'] ?>">
        <span class="rg-palette-chip-emoji"><?= e($c['emoji']) ?></span>
        <span><?= e($c['name']) ?></span>
        <span class="rg-palette-chip-spacing"><?= (int)$c['spacing_cm'] ?>cm</span>
      </button>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Harvest blackout modal -->
  <div class="rg-blackout" id="rgHarvestModal" style="display:none">
    <div class="rg-blackout-card">
      <div class="rg-blackout-head">
        <div style="flex:1">
          <div class="rg-label-tiny">Harvest</div>
          <div style="font-weight:800;font-size:1rem;margin-top:2px"><?= e($bed['name']) ?> · Line <span id="rgHarvestLine">—</span></div>
        </div>
        <button type="button" class="rg-blackout-close" id="rgHarvestClose">×</button>
      </div>
      <div class="rg-blackout-body" id="rgHarvestBody">
        <div style="font-size:.82rem;color:var(--color-text-muted);margin-bottom:14px">How much did you harvest from this line?</div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Quantity</label>
            <input type="number" step="0.1" class="form-input" id="rgHarvestQty" placeholder="0.0" />
          </div>
          <div class="form-group form-group--sm">
            <label class="form-label">Unit</label>
            <select class="form-input" id="rgHarvestUnit">
              <option>kg</option><option>g</option><option>L</option><option>bunch</option><option>items</option>
            </select>
          </div>
        </div>
        <div class="form-group" style="margin-top:8px">
          <label class="form-label">Quality</label>
          <div style="display:flex;gap:6px">
            <button type="button" class="btn btn-secondary btn-sm rg-q" data-q="3" style="flex:1">🤩 Excellent</button>
            <button type="button" class="btn btn-secondary btn-sm rg-q" data-q="2" style="flex:1">🙂 Good</button>
            <button type="button" class="btn btn-secondary btn-sm rg-q" data-q="1" style="flex:1">😕 Poor</button>
          </div>
        </div>
        <div style="display:flex;gap:8px;margin-top:18px">
          <button type="button" class="btn btn-ghost" id="rgHarvestCancel" style="flex:1">Cancel</button>
          <button type="button" class="btn btn-primary" id="rgHarvestConfirm" style="flex:2">Save & clear line ↻</button>
        </div>
      </div>
    </div>
  </div>

</div>

<!-- Toast notification (fixed above palette) -->
<div id="rgToast" style="
  display:none;position:fixed;bottom:90px;left:50%;transform:translateX(-50%);
  max-width:360px;width:calc(100% - 32px);
  padding:11px 16px;border-radius:10px;
  font-size:.84rem;font-weight:600;color:#fff;
  z-index:60;box-shadow:0 4px 16px rgba(0,0,0,.22);
  transition:opacity .25s;pointer-events:none;text-align:center
"></div>

<style>
@keyframes rg-toast-in {
  from { opacity:0; transform:translateX(-50%) translateY(8px); }
  to   { opacity:1; transform:translateX(-50%) translateY(0); }
}
#rgToast.is-visible { animation: rg-toast-in .2s ease forwards; }
</style>

<style>
/* Drag-and-drop states */
.rg-palette-chip[draggable] { cursor: grab; }
.rg-palette-chip.is-dragging { opacity: .45; cursor: grabbing; transform: scale(.96); }
.rg-line.is-drag-over {
  border: 2.5px dashed var(--color-primary) !important;
  background: rgba(22,101,52,.07) !important;
  box-shadow: inset 0 0 0 3px rgba(22,101,52,.12) !important;
}
.rg-line.is-planting { opacity: .6; pointer-events: none; }
</style>

<script>
(function () {
  var $page = $('#rgBedPage');
  var bedId = parseInt($page.data('item-id'), 10);
  var csrf  = <?= json_encode($csrf) ?>;
  var PLANT_URL = '<?= url('/items/' . $bedId . '/plant-tap') ?>';
  var LINE_KEY  = 'rooted.activeLine.' + bedId;
  var CROP_KEY  = 'rooted.activeCrop.' + bedId;

  // ── Toast ───────────────────────────────────────────────────────
  var _toastTimer = null;
  function showToast(msg, type) {
    var $t = $('#rgToast');
    if (_toastTimer) clearTimeout(_toastTimer);
    $t.text(msg)
      .css('background', type === 'error' ? '#dc2626' : type === 'warn' ? '#d97706' : '#16a34a')
      .css({display:'block', opacity:''})
      .addClass('is-visible');
    _toastTimer = setTimeout(function () {
      $t.css('opacity', 0);
      setTimeout(function () { $t.css({display:'none', opacity:''}); }, 260);
    }, type === 'error' ? 4000 : 2500);
  }
  function ajaxErr(xhr, fallback) {
    var msg = fallback;
    try { msg = JSON.parse(xhr.responseText).error || msg; } catch(e){}
    showToast(msg, 'error');
  }

  // ── Core plant action ────────────────────────────────────────────
  function plantOne(lineNum, cropId) {
    var $line = $page.find('.rg-line[data-line="' + lineNum + '"]');
    $line.addClass('is-planting');
    $.post(PLANT_URL, { _token: csrf, line_number: lineNum, crop_id: cropId, count: 1 })
      .done(function (data) {
        // Check success explicitly — server returns {success:false} with HTTP 200 on errors
        if (data && data.success === false) {
          $line.removeClass('is-planting');
          showToast(data.error || 'Could not plant — try again', 'error');
        } else {
          window.location.reload();
        }
      })
      .fail(function (xhr) {
        $line.removeClass('is-planting');
        ajaxErr(xhr, 'Could not plant — try again');
      });
  }

  // ── Active line ──────────────────────────────────────────────────
  var activeLineNum = parseInt(localStorage.getItem(LINE_KEY), 10) || 0;
  function setActiveLine(lineNum) {
    activeLineNum = parseInt(lineNum, 10) || 0;
    if (activeLineNum) localStorage.setItem(LINE_KEY, String(activeLineNum));
    $page.find('.rg-line').each(function () {
      var ln = parseInt($(this).data('line'), 10);
      if (ln === activeLineNum) {
        if (!$(this).hasClass('is-active')) {
          $(this).addClass('is-active');
          var el = this; el.style.animation = 'none'; el.offsetHeight; el.style.animation = '';
        }
      } else {
        $(this).removeClass('is-active');
      }
    });
    var $lbl = $('#rgPaletteLabel');
    if (activeLineNum) {
      $lbl.html('→ Drop or tap a crop to plant in <strong>Line ' + activeLineNum + '</strong>').css('color','var(--color-primary)');
    } else {
      $lbl.html('Drag a crop onto a line — or tap a line then tap a crop').css('color','');
    }
  }
  if (activeLineNum) setActiveLine(activeLineNum);

  // Tap line header/stripe to select it
  $page.on('click', '.rg-line', function (e) {
    if ($(e.target).closest('button, a, .rg-stepper').length) return;
    setActiveLine(parseInt($(this).data('line'), 10));
  });

  // ── Active crop ──────────────────────────────────────────────────
  var activeCropId = parseInt(localStorage.getItem(CROP_KEY), 10) || 0;
  if (!activeCropId) activeCropId = parseInt($('.rg-palette-chip').first().data('crop-id'), 10) || 0;
  function setActiveCrop(cropId) {
    activeCropId = parseInt(cropId, 10) || 0;
    if (activeCropId) localStorage.setItem(CROP_KEY, String(activeCropId));
    $('#rgPalette .rg-palette-chip').each(function () {
      if (parseInt($(this).data('crop-id'), 10) === activeCropId) {
        var col = $(this).data('color');
        $(this).addClass('is-active').css({background: col, 'border-color': col, color: '#fff'});
      } else {
        $(this).removeClass('is-active').removeAttr('style');
      }
    });
  }
  setActiveCrop(activeCropId);

  // ── Palette chip: tap to plant in selected line ──────────────────
  $('#rgPalette').on('click', '.rg-palette-chip', function () {
    var cropId = parseInt($(this).data('crop-id'), 10);
    setActiveCrop(cropId);
    if (activeLineNum) {
      plantOne(activeLineNum, cropId);
    } else {
      showToast('Drag onto a line — or tap a line first ↑', 'warn');
    }
  });

  // ── "Try this" suggestion chips ──────────────────────────────────
  $page.on('click', '.rg-plant-action', function (e) {
    e.stopPropagation();
    plantOne(parseInt($(this).data('line'), 10), parseInt($(this).data('crop-id'), 10));
  });

  // ── Tap a dot to plant ───────────────────────────────────────────
  $page.on('click', '.rg-dot--clickable', function (e) {
    e.stopPropagation();
    if (!activeCropId) { showToast('Select a crop from the palette first', 'warn'); return; }
    var lineNum = parseInt($(this).closest('.rg-line').data('line'), 10);
    setActiveLine(lineNum);
    plantOne(lineNum, activeCropId);
  });

  // ── HTML5 Drag-and-Drop ─────────────────────────────────────────
  // Drag start: store crop id
  $page.on('dragstart', '.rg-palette-chip', function (e) {
    var cropId = $(this).data('crop-id');
    e.originalEvent.dataTransfer.setData('text/plain', String(cropId));
    e.originalEvent.dataTransfer.effectAllowed = 'copy';
    $(this).addClass('is-dragging');
    setActiveCrop(cropId);
  });
  $page.on('dragend', '.rg-palette-chip', function () {
    $(this).removeClass('is-dragging');
    $page.find('.rg-line').removeClass('is-drag-over');
  });

  // Line as drop zone
  $page.on('dragover', '.rg-line', function (e) {
    e.preventDefault();
    e.originalEvent.dataTransfer.dropEffect = 'copy';
    $(this).addClass('is-drag-over');
  });
  $page.on('dragleave', '.rg-line', function (e) {
    // Only clear when actually leaving this element (not entering a child)
    if (!this.contains(e.originalEvent.relatedTarget)) {
      $(this).removeClass('is-drag-over');
    }
  });
  $page.on('drop', '.rg-line', function (e) {
    e.preventDefault();
    $(this).removeClass('is-drag-over');
    var cropId  = parseInt(e.originalEvent.dataTransfer.getData('text/plain'), 10);
    var lineNum = parseInt($(this).data('line'), 10);
    if (!cropId || !lineNum) return;
    setActiveLine(lineNum);
    plantOne(lineNum, cropId);
  });

  // ── Stepper +/− ─────────────────────────────────────────────────
  $page.on('click', '.rg-step-plus, .rg-step-minus', function (e) {
    e.stopPropagation();
    var pid   = parseInt($(this).closest('.rg-stepper').data('planting-id'), 10);
    var delta = $(this).hasClass('rg-step-plus') ? 1 : -1;
    $.post('<?= url('/garden/plantings/') ?>' + pid + '/adjust-qty', { _token: csrf, delta: delta })
      .done(function (data) {
        if (data && data.success === false) showToast(data.error || 'Could not adjust', 'error');
        else window.location.reload();
      })
      .fail(function (xhr) { ajaxErr(xhr, 'Could not adjust quantity'); });
  });

  // ── Stepper direct numeric entry ────────────────────────────────
  $page.on('click focus', '.rg-stepper-val', function () { this.select(); });
  $page.on('keydown', '.rg-stepper-val', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); this.blur(); }
    else if (e.key === 'Escape') { this.value = $(this).data('orig') || this.value; this.blur(); }
  });
  $page.on('focus', '.rg-stepper-val', function () { $(this).data('orig', this.value); });
  $page.on('change blur', '.rg-stepper-val', function () {
    var $input = $(this);
    var orig   = parseInt($input.data('orig'), 10);
    var count  = parseInt($input.val(), 10);
    if (!count || count < 1) count = 1;
    $input.val(count);
    if (count === orig) return;
    var pid = parseInt($input.closest('.rg-stepper').data('planting-id'), 10);
    $.post('<?= url('/garden/plantings/') ?>' + pid + '/adjust-qty', { _token: csrf, count: count })
      .done(function (data) {
        if (data && data.success === false) { $input.val(orig); showToast(data.error || 'Could not set', 'error'); }
        else window.location.reload();
      })
      .fail(function (xhr) { $input.val(orig); ajaxErr(xhr, 'Could not set quantity'); });
  });

  // ── Per-crop remove ──────────────────────────────────────────────
  $page.on('click', '.rg-stepchip-remove', function (e) {
    e.stopPropagation();
    var pid = parseInt($(this).data('planting-id'), 10);
    $.post('<?= url('/garden/plantings/') ?>' + pid + '/remove', { _token: csrf })
      .done(function (data) {
        if (data && data.success === false) showToast(data.error || 'Could not remove', 'error');
        else window.location.reload();
      })
      .fail(function (xhr) { ajaxErr(xhr, 'Could not remove crop'); });
  });

  // ── Clear all (double-tap confirm) ──────────────────────────────
  $page.on('click', '.rg-clear-btn', function (e) {
    e.stopPropagation();
    var $btn = $(this);
    if ($btn.data('confirm')) {
      $btn.removeData('confirm').text('Clear All');
      $.post('<?= url('/items/' . $bedId . '/clear-line') ?>', { _token: csrf, line_number: parseInt($btn.data('line'), 10) })
        .done(function (data) {
          if (data && data.success === false) showToast(data.error || 'Could not clear', 'error');
          else window.location.reload();
        })
        .fail(function (xhr) { ajaxErr(xhr, 'Could not clear line'); });
    } else {
      $btn.data('confirm', true).text('Tap again to confirm');
      setTimeout(function () { if ($btn.data('confirm')) $btn.removeData('confirm').text('Clear All'); }, 3000);
    }
  });

  // ── Harvest modal ────────────────────────────────────────────────
  var harvestLine = null;
  $page.on('click', '.rg-harvest-btn', function (e) {
    e.stopPropagation();
    harvestLine = parseInt($(this).data('line'), 10);
    $('#rgHarvestLine').text(harvestLine);
    $('#rgHarvestQty').val('');
    $('.rg-q').removeClass('btn-primary').addClass('btn-secondary');
    $('#rgHarvestModal').css('display', 'flex');
  });
  function closeHarvest() { $('#rgHarvestModal').hide(); harvestLine = null; }
  $('#rgHarvestClose, #rgHarvestCancel').on('click', closeHarvest);
  $page.on('click', '.rg-q', function () {
    $('.rg-q').removeClass('btn-primary').addClass('btn-secondary');
    $(this).removeClass('btn-secondary').addClass('btn-primary');
  });
  $('#rgHarvestConfirm').on('click', function () {
    if (harvestLine === null) return;
    $.post('<?= url('/items/' . $bedId . '/harvest-clear') ?>', {
      _token: csrf, line_number: harvestLine,
      qty: parseFloat($('#rgHarvestQty').val()) || 0, unit: $('#rgHarvestUnit').val()
    }).done(function (data) {
      if (data && data.success === false) { closeHarvest(); showToast(data.error || 'Could not save harvest', 'error'); }
      else window.location.reload();
    }).fail(function (xhr) { closeHarvest(); ajaxErr(xhr, 'Could not save harvest'); });
  });
})();
</script>
