<?php
$miniMapEnabled = !empty($item['gps_lat']) && !empty($item['gps_lng']);

$irrigIntervals  = [
    'twice_daily'   => 'Twice daily',
    'daily'         => 'Daily',
    'every_2_days'  => 'Every 2 days',
    'every_3_days'  => 'Every 3 days',
    'every_5_days'  => 'Every 5 days',
    'every_10_days' => 'Every 10 days',
    'every_20_days' => 'Every 20 days',
    'weekly'        => 'Weekly',
    'biweekly'      => 'Every 2 weeks',
    'monthly'       => 'Monthly',
];
$irrigHourPresets = [
    ''        => 'All-day (no time)',
    'sunrise' => 'Sunrise (~6:00 AM)',
    'midday'  => 'Midday (12:00 PM)',
    'sunset'  => 'Sunset (~7:00 PM)',
    'night'   => 'Night (9:00 PM)',
    'custom'  => 'Custom hour…',
];

// Pull emoji and color from the merged item types config (built-in + custom).
// $itemTypes is provided by ItemController.
$_typeCfg  = $itemTypes[$item['type']] ?? [];
$emoji     = $_typeCfg['emoji'] ?? '📦';
$color     = $_typeCfg['color'] ?? '#2d6a4f';
$typeLabel = ucwords(str_replace('_', ' ', $item['type']));

// Find identification photo for hero
$idPhoto = null;
foreach ($attachments as $att) {
    if ($att['category'] === 'identification_photo' && str_starts_with($att['mime_type'] ?? '', 'image/')) {
        $idPhoto = $att;
        break;
    }
}

// Photo preview: all image attachments, newest first, max 8
$imageAttachments = array_values(array_filter($attachments, fn($a) => str_starts_with($a['mime_type'] ?? '', 'image/')));
$previewPhotos    = array_slice($imageAttachments, 0, 8);
$totalPhotos      = count($imageAttachments);

// Gallery: find which index in $imageAttachments corresponds to $idPhoto
$idPhotoGalleryIndex = 0;
if ($idPhoto) {
    foreach ($imageAttachments as $_k => $_a) {
        if ((int)$_a['id'] === (int)$idPhoto['id']) { $idPhotoGalleryIndex = $_k; break; }
    }
}
?>

<!-- =========================================================
     HERO
     ========================================================= -->
<div class="show-hero" style="--item-color:<?= $color ?>">
    <?php if ($idPhoto): ?>
    <div class="show-hero-photo show-hero-photo--clickable" onclick="openGallery(<?= $idPhotoGalleryIndex ?>)" title="View photos" style="position:relative">
        <img src="<?= att_url((int)$idPhoto['id']) ?>"
             alt="<?= e($item['name']) ?>" loading="eager">
        <div class="show-hero-photo-overlay"></div>
        <div style="position:absolute;bottom:10px;right:10px;display:flex;gap:6px;z-index:3" onclick="event.stopPropagation()">
            <a href="<?= url('/items/' . (int)$item['id'] . '/edit') ?>" style="display:inline-flex;align-items:center;gap:5px;padding:6px 13px;background:rgba(0,0,0,.55);backdrop-filter:blur(4px);color:#fff;border-radius:20px;font-size:.78rem;font-weight:600;text-decoration:none">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>
                Edit
            </a>
            <?php if (in_array($item['type'], ['garden','bed','orchard','zone','prep_zone','mobile_coop','building'])): ?>
            <a href="<?= url('/items/' . (int)$item['id'] . '/edit#boundary') ?>" style="display:inline-flex;align-items:center;gap:5px;padding:6px 13px;background:#f4b324;color:#1a1a1a;border-radius:20px;font-size:.78rem;font-weight:700;text-decoration:none">
                📍 Position
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="show-hero-photo show-hero-photo--placeholder" style="position:relative">
        <span class="show-hero-placeholder-emoji"><?= $emoji ?></span>
        <div style="position:absolute;bottom:10px;right:10px;display:flex;gap:6px;z-index:3">
            <a href="<?= url('/items/' . (int)$item['id'] . '/edit') ?>" style="display:inline-flex;align-items:center;gap:5px;padding:6px 13px;background:rgba(0,0,0,.45);backdrop-filter:blur(4px);color:#fff;border-radius:20px;font-size:.78rem;font-weight:600;text-decoration:none">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4Z"/></svg>
                Edit
            </a>
            <?php if (in_array($item['type'], ['garden','bed','orchard','zone','prep_zone','mobile_coop','building'])): ?>
            <a href="<?= url('/items/' . (int)$item['id'] . '/edit#boundary') ?>" style="display:inline-flex;align-items:center;gap:5px;padding:6px 13px;background:#f4b324;color:#1a1a1a;border-radius:20px;font-size:.78rem;font-weight:700;text-decoration:none">
                📍 Position
            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="show-hero-content">
        <div class="show-hero-back">
            <a href="<?= url('/items') ?>" class="show-back-btn">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
                Items
            </a>
        </div>
        <?php if ($idPhoto): ?>
        <div class="show-hero-avatar">
            <img src="<?= att_url((int)$idPhoto['id']) ?>" alt="">
        </div>
        <?php endif; ?>
        <div class="show-hero-badge"><?= $emoji ?> <?= e($typeLabel) ?></div>
        <h1 class="show-hero-name"><?= e($item['name']) ?></h1>
        <?php if ($item['status'] !== 'active'): ?>
        <span class="show-hero-status"><?= e($item['status']) ?></span>
        <?php endif; ?>
    </div>
</div>

<?php if (in_array($item['type'], ['bed','garden']) && empty($boundaryGeojson)): ?>
<a href="<?= url('/items/' . (int)$item['id'] . '/edit#boundary') ?>"
   style="display:flex;align-items:center;gap:10px;background:#fff3cd;border-bottom:2px solid #ffc107;padding:12px 16px;text-decoration:none;color:#856404">
    <span style="font-size:1.4rem">📍</span>
    <div>
        <div style="font-weight:700;font-size:.95rem">Position this <?= e($item['type']) ?> on the map</div>
        <div style="font-size:.8rem;margin-top:1px">Tap to set the boundary and make it visible on your map →</div>
    </div>
</a>
<?php endif; ?>

<?php include BASE_PATH . '/resources/views/partials/flash.php'; ?>

<!-- =========================================================
     QUICK ACTIONS (add photo / reminder / note / ai)
     ========================================================= -->
<div class="show-quick-actions">
    <a href="<?= url('/items/' . (int)$item['id'] . '/photos') ?>" class="show-qa-btn">
        <span class="show-qa-icon">📷</span>
        <span class="show-qa-label">Add Photo</span>
    </a>
    <a href="#form-note" class="show-qa-btn" onclick="expandSection('note-section'); preCheckReminder()">
        <span class="show-qa-icon">🔔</span>
        <span class="show-qa-label">Reminder</span>
    </a>
    <a href="#form-note" class="show-qa-btn" onclick="expandSection('note-section')">
        <span class="show-qa-icon">✏️</span>
        <span class="show-qa-label">Log</span>
    </a>
    <button class="show-qa-btn" id="aiPromptBtn"
            data-url="<?= url('/items/' . (int)$item['id'] . '/ai-prompt') ?>">
        <span class="show-qa-icon" id="aiPromptIcon">🤖</span>
        <span class="show-qa-label" id="aiPromptLabel">Copy AI</span>
    </button>
    <a href="<?= url('/items/' . (int)$item['id'] . '/survey') ?>" class="show-qa-btn">
        <span class="show-qa-icon">🧭</span>
        <span class="show-qa-label">Survey</span>
    </a>
</div>

<?php
// ── Status bar chips ─────────────────────────────────────────────────────────
$_stChips = [];
if (!empty($harvests)) {
    $h = $harvests[0];
    $qty = (float)$h['quantity'];
    $qtyFmt = ($qty == floor($qty)) ? (string)(int)$qty : number_format($qty, 1);
    $_stChips[] = ['🌾', $qtyFmt . ' ' . $h['unit'], 'Harvest · ' . date('d M Y', strtotime($h['recorded_at']))];
}
$_svStatDefs   = ['budding'=>['🌸','Budding'],'fruits'=>['🍋','Fruits'],'health'=>['🏥','Health']];
$_surveyLatest = $surveyLatest ?? [];
foreach ($_svStatDefs as $_st => [$_ico, $_lb]) {
    if (!empty($_surveyLatest[$_st])) {
        $sd = $_surveyLatest[$_st];
        $_val = $sd['scale_value'] !== null ? $sd['scale_value'] . '/10' : date('M j', strtotime($sd['completed_at']));
        $_stChips[] = [$_ico, $_val, $_lb . ' · ' . date('d M Y', strtotime($sd['completed_at']))];
    }
}
// ── Survey row data ───────────────────────────────────────────────────────────
$_svOrder   = ['compass','budding','fruits','health'];
$_svEmojis  = ['compass'=>'🧭','budding'=>'🌸','fruits'=>'🍋','health'=>'🏥'];
$_svLabels  = ['compass'=>'Compass','budding'=>'Budding','fruits'=>'Fruits','health'=>'Health'];
$_svCount   = count($surveyStages ?? []);
$_svAllDone = ($_svCount === 4);
$_svData    = [];
foreach ($_svOrder as $_idx => $_st) {
    $sd = ($surveyStages ?? [])[$_st] ?? null;
    $_svData[] = [
        'idx'   => $_idx,  'stage' => $_st,
        'label' => $_svLabels[$_st], 'emoji' => $_svEmojis[$_st],
        'done'  => $sd !== null,
        'att_id'=> $sd ? $sd['att_id'] : null,
        'notes' => $sd ? ($sd['notes'] ?? '') : '',
        'scale' => $sd ? $sd['scale_value'] : null,
        'date'  => $sd ? date('M j, Y', strtotime($sd['completed_at'])) : '',
    ];
}
?>
<style>
/* ── Status bar ──────────────────────────────────────────────────────────── */
.si-statusbar{display:flex;gap:8px;overflow-x:auto;padding:0 0 4px;margin-bottom:14px;-webkit-overflow-scrolling:touch;scrollbar-width:none;}
.si-statusbar::-webkit-scrollbar{display:none;}
.si-chip{display:flex;align-items:center;gap:7px;background:var(--color-surface);border:1px solid var(--color-border);border-radius:10px;padding:7px 12px;white-space:nowrap;flex-shrink:0;}
.si-chip-ico{font-size:1.2rem;}
.si-chip-text{display:flex;flex-direction:column;gap:1px;}
.si-chip-val{font-size:.82rem;font-weight:700;color:var(--color-text);}
.si-chip-lbl{font-size:.68rem;color:var(--color-text-muted);}
/* ── Survey row ──────────────────────────────────────────────────────────── */
.svr{margin-bottom:16px;}
.svr-hdr{display:flex;align-items:center;gap:8px;margin-bottom:10px;}
.svr-hdr-title{font-size:.83rem;font-weight:700;flex:1;}
.svr-hdr-count{font-size:.72rem;font-weight:700;color:var(--color-primary);background:var(--color-primary-soft);padding:2px 9px;border-radius:999px;}
.svr-hdr-link{font-size:.75rem;color:var(--color-text-muted);text-decoration:none;}
.svr-hdr-link:hover{color:var(--color-primary);}
.svr-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;}
.svr-slot{aspect-ratio:1;border-radius:12px;overflow:hidden;position:relative;cursor:pointer;background:var(--color-bg);border:2px dashed var(--color-border);display:flex;align-items:center;justify-content:center;}
.svr-slot--done{border:2px solid var(--color-primary);}
.svr-slot--active{outline:3px solid var(--color-accent);outline-offset:-1px;}
.svr-slot img{width:100%;height:100%;object-fit:cover;position:absolute;inset:0;}
.svr-slot-ov{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:flex-end;padding:5px 7px;background:linear-gradient(to top,rgba(0,0,0,.72) 0%,transparent 60%);}
.svr-slot--missing .svr-slot-ov{background:rgba(0,0,0,.28);justify-content:center;align-items:center;gap:2px;}
.svr-slot-lbl{font-size:.58rem;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:.04em;line-height:1.2;}
.svr-slot-date{font-size:.55rem;color:rgba(255,255,255,.8);margin-top:1px;}
.svr-slot-check{position:absolute;top:5px;right:6px;font-size:.72rem;}
.svr-slot-emoji{font-size:1.9rem;position:relative;z-index:1;}
/* Detail panel */
.svr-detail{border:1px solid var(--color-border);border-radius:14px;overflow:hidden;margin-top:10px;display:flex;min-height:160px;}
.svr-detail-body{flex:1;padding:14px 16px;display:flex;flex-direction:column;min-width:0;}
.svr-detail-stage-lbl{font-size:.7rem;font-weight:700;color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.05em;}
.svr-detail-date{font-size:.8rem;color:var(--color-primary);font-weight:600;margin-top:2px;}
.svr-detail-scale{font-size:1rem;font-weight:800;margin-top:8px;color:var(--color-text);}
.svr-detail-notes{font-size:.85rem;color:var(--color-text-muted);margin-top:6px;line-height:1.5;flex:1;}
.svr-detail-nav{display:flex;gap:6px;margin-top:12px;}
.svr-detail-nav button{flex:1;border:1.5px solid var(--color-border);background:none;border-radius:8px;padding:7px;cursor:pointer;font-size:.8rem;color:var(--color-text);}
.svr-detail-nav button:disabled{opacity:.3;cursor:default;}
.svr-detail-img{width:40%;flex-shrink:0;}
.svr-detail-img img{width:100%;height:100%;object-fit:cover;display:block;}
.svr-detail-nophoto{width:40%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:3rem;background:var(--color-bg);}
@media(max-width:480px){.svr-detail{flex-direction:column-reverse;}.svr-detail-img,.svr-detail-nophoto{width:100%;height:160px;}}
</style>

<?php if (!empty($_stChips)): ?>
<div class="si-statusbar">
    <?php foreach ($_stChips as [$_ico, $_val, $_lbl]): ?>
    <div class="si-chip">
        <span class="si-chip-ico"><?= $_ico ?></span>
        <div class="si-chip-text">
            <span class="si-chip-val"><?= e($_val) ?></span>
            <span class="si-chip-lbl"><?= e($_lbl) ?></span>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- =========================================================
     SURVEY ROW
     ========================================================= -->
<div class="svr">
    <div class="svr-hdr">
        <span class="svr-hdr-title">📋 Annual Survey <?= $surveyYear ?></span>
        <?php if ($_svCount > 0): ?>
        <span class="svr-hdr-count"><?= $_svCount ?>/4</span>
        <?php endif; ?>
        <a href="<?= url('/items/' . (int)$item['id'] . '/survey') ?>" class="svr-hdr-link">
            <?= $_svAllDone ? 'View →' : ($_svCount > 0 ? 'Continue →' : 'Start →') ?>
        </a>
    </div>
    <div class="svr-grid">
        <?php foreach ($_svData as $sd): ?>
        <div class="svr-slot <?= $sd['done'] ? 'svr-slot--done' : 'svr-slot--missing' ?>"
             id="svrSlot_<?= $sd['stage'] ?>"
             onclick="<?= $sd['done'] ? 'svrOpenDetail(' . $sd['idx'] . ')' : 'location.href=\'' . url('/items/' . (int)$item['id'] . '/survey') . '\'' ?>">
            <?php if ($sd['att_id']): ?>
            <img src="<?= url('/attachments/' . (int)$sd['att_id'] . '/download') ?>" alt="">
            <?php else: ?>
            <span class="svr-slot-emoji"><?= $sd['emoji'] ?></span>
            <?php endif; ?>
            <div class="svr-slot-ov">
                <?php if ($sd['done']): ?>
                <span class="svr-slot-lbl"><?= e($sd['label']) ?></span>
                <span class="svr-slot-date"><?= e($sd['date']) ?></span>
                <?php else: ?>
                <span class="svr-slot-lbl" style="color:rgba(255,255,255,.6)"><?= e($sd['label']) ?></span>
                <?php endif; ?>
            </div>
            <?php if ($sd['done']): ?><span class="svr-slot-check">✅</span><?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <div id="svrDetail" class="svr-detail" <?= $_svAllDone ? '' : 'style="display:none"' ?>>
        <div class="svr-detail-body">
            <span class="svr-detail-stage-lbl" id="svrDetailStage"></span>
            <span class="svr-detail-date"       id="svrDetailDate"></span>
            <div  class="svr-detail-scale"       id="svrDetailScale"></div>
            <div  class="svr-detail-notes"       id="svrDetailNotes"></div>
            <div class="svr-detail-nav">
                <button id="svrPrev" onclick="svrDetailNav(-1)">&#8592; Prev</button>
                <button id="svrNext" onclick="svrDetailNav(1)">Next &#8594;</button>
            </div>
        </div>
        <div id="svrDetailMedia" class="svr-detail-nophoto"></div>
    </div>
</div>
<script>
(function(){
    var DATA  = <?= json_encode($_svData) ?>;
    var BASE  = window.APP_BASE || '';
    var cur   = 0;
    var SCALE = {1:'Almost none',2:'Very sparse',3:'Low',4:'Below avg',5:'Moderate',
                 6:'Above avg',7:'Good',8:'Very good',9:'Excellent',10:'Exceptional'};
    function render(idx) {
        cur = idx;
        var d = DATA[idx]; if (!d || !d.done) return;
        var g = function(id){ return document.getElementById(id); };
        if (g('svrDetailStage')) g('svrDetailStage').textContent = d.label;
        if (g('svrDetailDate'))  g('svrDetailDate').textContent  = d.date;
        if (g('svrDetailScale')) g('svrDetailScale').textContent = d.scale ? 'Scale ' + d.scale + '/10 — ' + (SCALE[d.scale]||'') : '';
        if (g('svrDetailNotes')) g('svrDetailNotes').textContent = d.notes || '';
        var media = g('svrDetailMedia');
        if (media) {
            if (d.att_id) {
                media.className = 'svr-detail-img';
                media.innerHTML = '<img src="' + BASE + '/attachments/' + d.att_id + '/download" alt="">';
            } else {
                media.className = 'svr-detail-nophoto';
                media.innerHTML = d.emoji;
            }
        }
        DATA.forEach(function(s,i){
            var slot = document.getElementById('svrSlot_' + s.stage);
            if (slot) slot.classList.toggle('svr-slot--active', i === idx);
        });
        var prev = g('svrPrev'), next = g('svrNext');
        var pi = -1, ni = -1;
        for (var i = idx-1; i >= 0; i--)              { if (DATA[i].done){pi=i;break;} }
        for (var i = idx+1; i < DATA.length; i++)     { if (DATA[i].done){ni=i;break;} }
        if (prev){ prev.disabled=(pi<0); prev._t=pi; }
        if (next){ next.disabled=(ni<0); next._t=ni; }
    }
    window.svrOpenDetail = function(idx) {
        var p = document.getElementById('svrDetail');
        if (!p) return;
        p.style.display = 'flex';
        render(idx);
        setTimeout(function(){ p.scrollIntoView({behavior:'smooth',block:'nearest'}); }, 50);
    };
    window.svrDetailNav = function(dir) {
        var btn = document.getElementById(dir < 0 ? 'svrPrev' : 'svrNext');
        if (btn && btn._t >= 0) render(btn._t);
    };
    <?php if ($_svAllDone): ?>
    (function(){ var f = DATA.findIndex(function(d){return d.done;}); if (f>=0) render(f); })();
    <?php endif; ?>
})();
</script>

<!-- =========================================================
     REMINDERS — TOP SECTION
     ========================================================= -->
<?php if (!empty($reminders)): ?>
<div class="show-section" id="itemRemSection">
    <div class="show-section-head">
        <span class="show-section-title">🔔 Reminders</span>
        <a href="<?= url('/reminders') ?>" class="show-section-link">All reminders →</a>
    </div>
    <?php $_iremCsrf = \App\Support\CSRF::getToken(); ?>
    <div class="irem-list">
    <?php foreach ($reminders as $r):
        $iremOD = strtotime($r['due_at']) < time();
        $iremId = (int)$r['id'];
    ?>
    <div class="irem-row <?= $iremOD ? 'irem-row--overdue' : '' ?>" id="irem-<?= $iremId ?>">
        <div class="irem-body">
            <div class="irem-title"><?= e($r['title']) ?></div>
            <div class="irem-meta">
                <?php if ($iremOD): ?>
                <span style="color:#c0392b;font-weight:700">⚠ Overdue · <?= e(date('d M Y', strtotime($r['due_at']))) ?></span>
                <?php else: ?>
                <?= e(date('d M Y', strtotime($r['due_at']))) ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="irem-actions">
            <button class="irem-btn irem-btn--done"   title="Done"    onclick="iremAction(<?= $iremId ?>,'complete','<?= e($_iremCsrf) ?>')">✓ Done</button>
            <button class="irem-btn irem-btn--snooze" title="+1 Day"  onclick="iremAction(<?= $iremId ?>,'snooze1','<?= e($_iremCsrf) ?>')">+1d</button>
            <button class="irem-btn irem-btn--snooze" title="+1 Week" onclick="iremAction(<?= $iremId ?>,'snooze7','<?= e($_iremCsrf) ?>')">+1w</button>
            <button class="irem-btn irem-btn--dismiss" title="Dismiss" onclick="iremAction(<?= $iremId ?>,'dismiss','<?= e($_iremCsrf) ?>')">✕</button>
        </div>
    </div>
    <?php endforeach; ?>
    </div>
</div>
<script>
function iremAction(id, action, token) {
    var url, body;
    if (action === 'snooze1' || action === 'snooze7') {
        url  = '<?= url('/reminders/') ?>' + id + '/snooze';
        body = '_token=' + encodeURIComponent(token) + '&days=' + (action === 'snooze7' ? 7 : 1) + '&_ajax=1';
    } else {
        url  = '<?= url('/reminders/') ?>' + id + '/' + action;
        body = '_token=' + encodeURIComponent(token) + '&_ajax=1';
    }
    fetch(url, { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'}, body:body })
        .then(function(r){ return r.json(); })
        .then(function(data) {
            if (!data.success) return;
            var row = document.getElementById('irem-' + id);
            if (!row) return;
            if (action === 'snooze1' || action === 'snooze7') {
                if (data.due_at) {
                    var d = new Date(data.due_at.replace(' ','T'));
                    var label = d.toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'});
                    var meta = row.querySelector('.irem-meta');
                    if (meta) meta.innerHTML = label;
                }
                row.classList.remove('irem-row--overdue');
            } else {
                row.style.transition = 'opacity .3s';
                row.style.opacity = '0';
                setTimeout(function(){ row.remove(); }, 300);
            }
        });
}
</script>
<style>
.irem-list { display:flex;flex-direction:column;gap:2px; }
.irem-row {
    display:flex;align-items:center;gap:8px;
    padding:9px 12px;background:var(--color-surface-raised);
    border:1px solid var(--color-border);border-radius:var(--radius);
}
.irem-row--overdue { background:#fff5f5;border-left:3px solid #c0392b; }
.irem-body { flex:1;min-width:0; }
.irem-title { font-size:.875rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis; }
.irem-meta { font-size:.7rem;color:var(--color-text-muted);margin-top:1px; }
.irem-actions { display:flex;gap:3px;flex-shrink:0; }
.irem-btn {
    height:26px;border:none;border-radius:5px;cursor:pointer;font-size:.72rem;font-weight:700;
    padding:0 7px;line-height:26px;transition:opacity .15s;white-space:nowrap;
}
.irem-btn--done    { background:var(--color-primary-soft);color:var(--color-primary); }
.irem-btn--done:hover { background:var(--color-primary);color:#fff; }
.irem-btn--snooze  { background:rgba(0,0,0,.06);color:var(--color-text-muted); }
.irem-btn--snooze:hover { background:rgba(0,0,0,.13); }
.irem-btn--dismiss { background:rgba(0,0,0,.06);color:#c0392b; }
.irem-btn--dismiss:hover { background:#ffd5d5; }
</style>
<?php endif; ?>

<?php
/* Active irrigation: plan where today is within [start_date, end_date] (or no end_date) */
$_activeIrr = null;
$_today = date('Y-m-d');
foreach (($irrigationPlans ?? []) as $_ip) {
    if ($_ip['start_date'] <= $_today && (empty($_ip['end_date']) || $_ip['end_date'] >= $_today)) {
        $_activeIrr = $_ip;
        break;
    }
}
?>
<?php if ($_activeIrr): ?>
<style>
.irr-snip{display:flex;align-items:center;gap:10px;background:var(--color-surface);border:1px solid var(--color-border);border-radius:12px;padding:10px 14px;margin-bottom:12px;font-size:.82rem;}
.irr-snip-icon{font-size:1.3rem;flex-shrink:0;}
.irr-snip-body{flex:1;min-width:0;}
.irr-snip-label{font-weight:700;color:var(--color-text);}
.irr-snip-sub{color:var(--color-text-muted);font-size:.76rem;margin-top:1px;}
.irr-snip-btn{font-size:.75rem;font-weight:600;color:var(--color-primary);text-decoration:none;white-space:nowrap;border:1px solid var(--color-primary);border-radius:8px;padding:4px 10px;}
.irr-snip-btn:hover{background:var(--color-primary);color:#fff;}
</style>
<div class="irr-snip">
    <span class="irr-snip-icon">💧</span>
    <div class="irr-snip-body">
        <div class="irr-snip-label">
            <?= e($irrigIntervals[$_activeIrr['interval_type']] ?? $_activeIrr['interval_type']) ?>
            <?php if (!empty($_activeIrr['quantity_liters'])): ?>
            · <?= (float)$_activeIrr['quantity_liters'] ?>L
            <?php endif; ?>
            <?php if (!empty($_activeIrr['hour_preset'])): ?>
            · <?= e($irrigHourPresets[$_activeIrr['hour_preset']] ?? $_activeIrr['hour_preset']) ?>
            <?php endif; ?>
        </div>
        <div class="irr-snip-sub">
            Active from <?= e(date('d M Y', strtotime($_activeIrr['start_date']))) ?>
            <?php if (!empty($_activeIrr['end_date'])): ?>
            → <?= e(date('d M Y', strtotime($_activeIrr['end_date']))) ?>
            <?php endif; ?>
        </div>
    </div>
    <a href="#irrigation-section" class="irr-snip-btn">Irrigation plan →</a>
</div>
<?php endif; ?>

<!-- =========================================================
     PHOTO PREVIEW STRIP
     ========================================================= -->
<?php if (!empty($previewPhotos)): ?>
<div class="show-section">
    <div class="show-section-head">
        <span class="show-section-title">📷 Photos</span>
        <a href="<?= url('/items/' . (int)$item['id'] . '/photos') ?>" class="show-section-link">
            <?= $totalPhotos ?> photo<?= $totalPhotos !== 1 ? 's' : '' ?> — See all →
        </a>
    </div>
    <?php $_pgCls = count($previewPhotos) >= 5 ? 'dense' : min(count($previewPhotos), 4); ?>
    <div class="show-photo-grid show-photo-grid--<?= $_pgCls ?>">
        <?php foreach ($previewPhotos as $i => $att): ?>
        <div class="show-photo-thumb" onclick="openGallery(<?= $i ?>)" role="button" tabindex="0"
             onkeydown="if(event.key==='Enter'||event.key===' ')openGallery(<?= $i ?>)">
            <img src="<?= att_url((int)$att['id']) ?>"
                 alt="" loading="lazy">
            <?php if ($i === 7 && $totalPhotos > 8): ?>
            <div class="show-photo-more">+<?= $totalPhotos - 8 ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>


<!-- =========================================================
     DETAILS
     ========================================================= -->
<div class="show-section">
    <div class="show-section-head">
        <span class="show-section-title">ℹ️ Details</span>
        <?php if (!empty($item['gps_lat'])): ?>
        <a href="<?= url('/dashboard/map') ?>" class="show-section-link">📍 View on map →</a>
        <?php endif; ?>
    </div>
    <div class="item-detail-card">
        <dl class="item-dl">
            <div class="item-dl-row">
                <dt>Type</dt>
                <dd><?= e($typeLabel) ?></dd>
            </div>
            <?php if ($item['gps_lat'] && $item['gps_lng']): ?>
            <div class="item-dl-row">
                <dt>GPS</dt>
                <dd class="text-sm"><?= number_format((float)$item['gps_lat'], 6) ?>, <?= number_format((float)$item['gps_lng'], 6) ?><?= $item['gps_source'] ? ' <span class="text-muted">(' . e($item['gps_source']) . ')</span>' : '' ?></dd>
            </div>
            <?php endif; ?>
            <?php if (!empty($boundaryGeojson)): ?>
            <div class="item-dl-row">
                <dt>Boundary</dt>
                <dd>
                    <a href="<?= url('/dashboard/map') ?>" class="text-sm">View on map →</a>
                    <details style="margin-top:4px">
                        <summary class="text-sm text-muted" style="cursor:pointer">Show GPS polygon JSON</summary>
                        <pre class="item-dl-geojson"><?= e($boundaryGeojson) ?></pre>
                    </details>
                </dd>
            </div>
            <?php endif; ?>
            <?php if ($item['parent_id']): ?>
            <div class="item-dl-row">
                <dt>Part of</dt>
                <dd><a href="<?= url('/items/' . (int)$item['parent_id']) ?>">View parent →</a></dd>
            </div>
            <?php endif; ?>
            <div class="item-dl-row">
                <dt>Status</dt>
                <dd><?= e($item['status']) ?></dd>
            </div>
            <div class="item-dl-row">
                <dt>Created</dt>
                <dd><?= e(date('d M Y', strtotime($item['created_at']))) ?></dd>
            </div>
            <?php foreach ($meta as $key => $value): ?>
            <div class="item-dl-row">
                <dt><?= e(ucwords(str_replace('_', ' ', $key))) ?></dt>
                <dd><?= e($value) ?></dd>
            </div>
            <?php endforeach; ?>
        </dl>
    </div>
</div>

<!-- =========================================================
     LOCATION MAP
     ========================================================= -->
<?php if ($miniMapEnabled): ?>
<div class="show-section">
    <div class="show-section-head">
        <span class="show-section-title">📍 Location</span>
    </div>
    <div id="miniMap" style="height:200px;border-radius:var(--radius-lg);overflow:hidden;border:1px solid var(--color-border);isolation:isolate;position:relative;z-index:0"></div>
</div>
<script>
window.MINI_MAP_LAT = <?= (float)$item['gps_lat'] ?>;
window.MINI_MAP_LNG = <?= (float)$item['gps_lng'] ?>;
window.MINI_MAP_READONLY = true;
</script>
<?php endif; ?>

<!-- =========================================================
     LOG ACTION + OPTIONAL REMINDER (fused form)
     ========================================================= -->
<div class="show-section" id="note-section">
    <div class="show-section-head">
        <span class="show-section-title">✏️ Log Action</span>
    </div>
    <div class="item-detail-card" id="form-note">
        <form method="POST" action="<?= url('/items/' . (int)$item['id'] . '/actions') ?>" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?= e(\App\Support\CSRF::getToken()) ?>">

            <!-- Action type -->
            <div class="log-field-row">
                <select name="action_type" class="form-input form-input--touch" id="logActionType">
                    <option value="note">Note</option>
                    <option value="pruning">Pruning</option>
                    <option value="treatment">Treatment</option>
                    <option value="amendment">Amendment</option>
                    <option value="harvest">Harvest</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="observation">Observation</option>
                    <option value="other">Other…</option>
                </select>
            </div>
            <div id="logCustomLabelWrap" style="display:none;margin-top:var(--spacing-2)">
                <input type="text" name="custom_action_label" id="logCustomLabel"
                       class="form-input form-input--touch" placeholder="Describe the action type…" maxlength="80">
            </div>

            <!-- Description (bigger textarea) -->
            <div class="log-field-row">
                <textarea name="description" class="form-input form-input--touch log-textarea"
                          placeholder="What happened? Add your notes here…"
                          rows="3" required></textarea>
            </div>

            <!-- Reminder toggle -->
            <div class="log-reminder-row">
                <label class="log-reminder-check">
                    <input type="checkbox" id="setReminderCb" name="set_reminder" value="1">
                    <span class="log-reminder-check-text">Set a reminder for this log</span>
                </label>
            </div>

            <!-- Photo toggle -->
            <div class="log-reminder-row">
                <label class="log-reminder-check">
                    <input type="checkbox" id="setPhotoCb" name="attach_photo" value="1">
                    <span class="log-reminder-check-text">📷 Attach photos to this log</span>
                </label>
            </div>

            <!-- Photo upload panel (hidden until checkbox checked) -->
            <div id="logPhotoPanel" class="log-cal-panel" style="display:none">
                <input type="file" name="log_photos[]" id="logPhotoInput"
                       accept="image/jpeg,image/png,image/webp,image/gif,image/*"
                       multiple
                       style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0;pointer-events:none">
                <button type="button" id="logPhotoPickerBtn" class="log-photo-btn">📂 Choose Photos</button>
                <div id="logPhotoPreview" class="log-photo-preview"></div>
            </div>

            <!-- Inline calendar picker (hidden until checkbox checked) -->
            <div id="reminderPickerPanel" class="log-cal-panel" style="display:none">
                <input type="hidden" name="reminder_due_at" id="reminderDueAt">
                <div class="cal-widget">
                    <div class="cal-hdr">
                        <button type="button" id="calPrevBtn" class="cal-nav-btn">&#8249;</button>
                        <span id="calMonthLabel" class="cal-month-label"></span>
                        <button type="button" id="calNextBtn" class="cal-nav-btn">&#8250;</button>
                    </div>
                    <div class="cal-dow">
                        <span>Mo</span><span>Tu</span><span>We</span><span>Th</span>
                        <span>Fr</span><span>Sa</span><span>Su</span>
                    </div>
                    <div class="cal-grid" id="calGrid"></div>
                    <div id="calSelectedLabel" class="cal-selected-label" style="display:none"></div>
                </div>
            </div>

            <!-- Submit -->
            <div class="log-submit-row">
                <button type="submit" class="btn btn-primary btn-block-mobile">Log</button>
            </div>
        </form>
    </div>
</div>

<!-- =========================================================
     HARVESTS (if any)
     ========================================================= -->
<?php if (!empty($harvests)): ?>
<div class="show-section">
    <div class="show-section-head">
        <span class="show-section-title">🌾 Harvests</span>
    </div>
    <div class="item-detail-card">
        <?php
        $harvestTotals = [];
        foreach ($harvests as $h) {
            $u = $h['unit'] ?? 'units';
            $harvestTotals[$u] = ($harvestTotals[$u] ?? 0) + (float)$h['quantity'];
        }
        ?>
        <div style="margin-bottom:var(--spacing-3);font-size:.85rem;color:var(--color-text-muted)">
            Total: <strong><?= implode(', ', array_map(fn($u,$q)=>number_format($q,2).' '.$u, array_keys($harvestTotals), $harvestTotals)) ?></strong>
        </div>
        <form method="POST" action="<?= url('/items/' . (int)$item['id'] . '/harvests') ?>" class="show-form-row" style="margin-bottom:var(--spacing-3)">
            <input type="hidden" name="_token" value="<?= e(\App\Support\CSRF::getToken()) ?>">
            <input type="number" step="0.001" name="quantity" class="form-input form-input--sm" placeholder="Qty" required style="width:80px">
            <input type="text" name="unit" class="form-input form-input--sm" placeholder="Unit" required style="width:80px">
            <input type="datetime-local" name="recorded_at" class="form-input form-input--sm" required style="flex:1">
            <button type="submit" class="btn btn-primary btn-sm">Record</button>
        </form>
        <table class="table" style="font-size:.82rem">
            <thead><tr><th>Date</th><th>Qty</th><th>Unit</th><th>Grade</th></tr></thead>
            <tbody>
                <?php foreach ($harvests as $h): ?>
                <tr>
                    <td><?= e(date('d M Y', strtotime($h['recorded_at']))) ?></td>
                    <td><?= number_format((float)$h['quantity'], 2) ?></td>
                    <td><?= e($h['unit']) ?></td>
                    <td><?= e($h['quality_grade'] ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- =========================================================
     IRRIGATION PLANS
     ========================================================= -->
<?php
$irrigationTypes = ['tree','olive_tree','almond_tree','vine','garden','bed'];
?>
<?php if (in_array($item['type'], $irrigationTypes)): ?>
<div class="show-section" id="irrigation-section">
    <div class="show-section-head">
        <span class="show-section-title">💧 Irrigation Plans</span>
    </div>
    <div class="item-detail-card">

    <?php foreach ($irrigationPlans as $irrigPlan): ?>
    <!-- ── Existing plan ── -->
    <div style="border:1px solid var(--color-border);border-radius:var(--radius);padding:12px;margin-bottom:12px">
        <div id="irrView<?= $irrigPlan['id'] ?>">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px">
                <div>
                    <div style="font-weight:700;font-size:.95rem">
                        <?= e($irrigIntervals[$irrigPlan['interval_type']] ?? $irrigPlan['interval_type']) ?>
                        <?php if (!empty($irrigPlan['quantity_liters'])): ?>
                        <span style="font-weight:400;color:var(--color-primary)"> · <?= (float)$irrigPlan['quantity_liters'] ?>L</span>
                        <?php endif; ?>
                    </div>
                    <div style="font-size:0.82rem;color:var(--color-text-muted);margin-top:3px">
                        <?= e(date('d M Y', strtotime($irrigPlan['start_date']))) ?>
                        <?php if (!empty($irrigPlan['end_date'])): ?>
                        → <?= e(date('d M Y', strtotime($irrigPlan['end_date']))) ?>
                        <?php endif; ?>
                        <?php if (!empty($irrigPlan['hour_preset'])): ?>
                        · <?= e($irrigHourPresets[$irrigPlan['hour_preset']] ?? $irrigPlan['hour_preset']) ?>
                        <?php if ($irrigPlan['hour_preset'] === 'custom' && !empty($irrigPlan['custom_hour'])): ?>
                        (<?= e(substr($irrigPlan['custom_hour'], 0, 5)) ?>)
                        <?php endif; ?>
                        <?php endif; ?>
                        <?php if (!empty($irrigPlan['google_event_id'])): ?>
                        · <span style="color:#2d8a27">📅 Calendar</span>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($irrigPlan['notes'])): ?>
                    <div style="font-size:0.8rem;margin-top:5px;color:var(--color-text-muted)"><?= nl2br(e($irrigPlan['notes'])) ?></div>
                    <?php endif; ?>
                </div>
                <div style="display:flex;gap:6px;flex-shrink:0">
                    <button type="button" class="btn btn-ghost btn-sm" onclick="irrEdit(<?= $irrigPlan['id'] ?>,true)">✏️</button>
                    <button type="button" class="btn btn-ghost btn-sm" style="color:#dc3545" onclick="irrDel(<?= $irrigPlan['id'] ?>,true)">✕</button>
                </div>
            </div>
            <div id="irrDelConfirm<?= $irrigPlan['id'] ?>" style="display:none;margin-top:10px;padding:10px;background:#fff5f5;border-radius:8px;border:1px solid #fcc">
                <div style="font-size:0.85rem;margin-bottom:8px">Remove this plan and delete Google Calendar events?</div>
                <div style="display:flex;gap:8px">
                    <form method="POST" action="<?= url('/irrigation/' . (int)$irrigPlan['id'] . '/delete') ?>">
                        <input type="hidden" name="_token" value="<?= e(\App\Support\CSRF::getToken()) ?>">
                        <button type="submit" class="btn btn-sm" style="background:#dc3545;color:#fff">Yes, remove</button>
                    </form>
                    <button type="button" class="btn btn-ghost btn-sm" onclick="irrDel(<?= $irrigPlan['id'] ?>,false)">Cancel</button>
                </div>
            </div>
        </div>

        <!-- ── Edit form ── -->
        <div id="irrEditForm<?= $irrigPlan['id'] ?>" style="display:none;margin-top:var(--spacing-3);border-top:1px solid var(--color-border);padding-top:var(--spacing-3)">
            <form method="POST" action="<?= url('/irrigation/' . (int)$irrigPlan['id'] . '/update') ?>" class="form">
                <input type="hidden" name="_token" value="<?= e(\App\Support\CSRF::getToken()) ?>">
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Interval</label>
                        <select name="interval_type" class="form-input">
                            <?php foreach ($irrigIntervals as $v => $l): ?>
                            <option value="<?= $v ?>" <?= $irrigPlan['interval_type'] === $v ? 'selected' : '' ?>><?= $l ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Quantity (liters)</label>
                        <input type="number" step="0.5" min="0" name="quantity_liters" class="form-input" value="<?= e($irrigPlan['quantity_liters'] ?? '') ?>" placeholder="e.g. 20">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Start date</label>
                        <input type="date" name="start_date" class="form-input" value="<?= e($irrigPlan['start_date']) ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">End date</label>
                        <input type="date" name="end_date" class="form-input" value="<?= e($irrigPlan['end_date'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Time preset</label>
                        <select name="hour_preset" class="form-input" onchange="irrPresetToggle(this,'irrCustomHour<?= $irrigPlan['id'] ?>')">
                            <?php foreach ($irrigHourPresets as $v => $l): ?>
                            <option value="<?= $v ?>" <?= ($irrigPlan['hour_preset'] ?? '') === $v ? 'selected' : '' ?>><?= $l ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group" id="irrCustomHour<?= $irrigPlan['id'] ?>" style="<?= ($irrigPlan['hour_preset'] ?? '') === 'custom' ? '' : 'display:none' ?>">
                        <label class="form-label">Custom time</label>
                        <input type="time" name="custom_hour" class="form-input" value="<?= e(substr($irrigPlan['custom_hour'] ?? '07:00', 0, 5)) ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Notes</label>
                    <textarea name="notes" class="form-input" rows="2"><?= e($irrigPlan['notes'] ?? '') ?></textarea>
                </div>
                <div style="display:flex;gap:8px">
                    <button type="submit" class="btn btn-primary btn-sm">Save</button>
                    <button type="button" class="btn btn-ghost btn-sm" onclick="irrEdit(<?= $irrigPlan['id'] ?>,false)">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    <?php endforeach; ?>

    <!-- ── Add new plan ── -->
    <?php if (empty($irrigationPlans)): ?>
    <div id="irrAddWrap">
    <?php else: ?>
    <div id="irrAddWrap" style="display:none">
    <?php endif; ?>
        <form method="POST" action="<?= url('/items/' . (int)$item['id'] . '/irrigation') ?>" class="form">
            <input type="hidden" name="_token" value="<?= e(\App\Support\CSRF::getToken()) ?>">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Interval</label>
                    <select name="interval_type" class="form-input">
                        <?php foreach ($irrigIntervals as $v => $l): ?>
                        <option value="<?= $v ?>" <?= $v === 'daily' ? 'selected' : '' ?>><?= $l ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Quantity (liters)</label>
                    <input type="number" step="0.5" min="0" name="quantity_liters" class="form-input" placeholder="e.g. 20">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Start date</label>
                    <input type="date" name="start_date" class="form-input" value="<?= date('Y-m-d') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">End date <small class="text-muted">(optional)</small></label>
                    <input type="date" name="end_date" class="form-input">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Time preset</label>
                    <select name="hour_preset" class="form-input" onchange="irrPresetToggle(this,'irrCustomHourNew')">
                        <?php foreach ($irrigHourPresets as $v => $l): ?>
                        <option value="<?= $v ?>"><?= $l ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" id="irrCustomHourNew" style="display:none">
                    <label class="form-label">Custom time</label>
                    <input type="time" name="custom_hour" class="form-input" value="07:00">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Notes <small class="text-muted">(optional)</small></label>
                <textarea name="notes" class="form-input" rows="2" placeholder="e.g. 15 min drip irrigation"></textarea>
            </div>
            <div style="display:flex;gap:8px">
                <button type="submit" class="btn btn-primary btn-sm">💧 Add Plan</button>
                <?php if (!empty($irrigationPlans)): ?>
                <button type="button" class="btn btn-ghost btn-sm" onclick="document.getElementById('irrAddWrap').style.display='none'">Cancel</button>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <?php if (!empty($irrigationPlans)): ?>
    <button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px" onclick="document.getElementById('irrAddWrap').style.display=document.getElementById('irrAddWrap').style.display==='none'?'block':'none'">+ Add another plan</button>
    <?php endif; ?>

    </div>
</div>
<script>
function irrEdit(id, open) {
    document.getElementById('irrView' + id).style.display     = open ? 'none' : '';
    document.getElementById('irrEditForm' + id).style.display = open ? 'block' : 'none';
}
function irrDel(id, open) {
    document.getElementById('irrDelConfirm' + id).style.display = open ? 'block' : 'none';
}
function irrPresetToggle(sel, targetId) {
    var el = document.getElementById(targetId);
    if (el) el.style.display = sel.value === 'custom' ? '' : 'none';
}
</script>
<?php endif; ?>

<!-- =========================================================
     FINANCE (if any)
     ========================================================= -->
<?php if (!empty($finances)): ?>
<div class="show-section">
    <div class="show-section-head">
        <span class="show-section-title">💰 Finance</span>
        <a href="<?= url('/items/' . (int)$item['id'] . '/finance') ?>" class="show-section-link">Full view →</a>
    </div>
    <div class="item-detail-card">
        <table class="table" style="font-size:.82rem">
            <thead><tr><th>Date</th><th>Type</th><th>Label</th><th>Amount</th></tr></thead>
            <tbody>
                <?php foreach ($finances as $f): ?>
                <tr>
                    <td><?= e($f['entry_date']) ?></td>
                    <td><span class="badge badge-<?= $f['entry_type'] === 'revenue' ? 'success' : 'warning' ?>"><?= e($f['entry_type']) ?></span></td>
                    <td><?= e($f['label']) ?></td>
                    <td><?= number_format((float)$f['amount'], 2) ?> <?= e($f['currency']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- =========================================================
     FULL ACTIVITY LOG
     ========================================================= -->
<div class="show-section" id="log-section">
    <div class="show-section-head">
        <span class="show-section-title" id="full-log">📋 Activity Log</span>
    </div>
    <div class="item-detail-card">
        <?php if (empty($activityLog)): ?>
        <p class="text-muted">No activity recorded yet.</p>
        <?php else: ?>
        <?php $logCsrf = e(\App\Support\CSRF::getToken()); ?>
        <table class="table show-log-table">
            <thead><tr><th>Date</th><th>Action</th><th>Description</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($activityLog as $a):
                    $logId   = (int)$a['id'];
                    $logData = json_encode([
                        'date'        => date('d M Y, H:i', strtotime($a['performed_at'])),
                        'action'      => $a['action_label'] ?? '',
                        'action_type' => $a['action_type'] ?? '',
                        'description' => $a['description'] ?? '',
                        'att_id'      => $a['att_id'] ?? null,
                        'att_mime'    => $a['att_mime'] ?? null,
                        'att_url'     => !empty($a['att_id']) ? att_url((int)$a['att_id']) : null,
                        'log_id'      => $logId,
                    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
                ?>
                <tr id="logrow_<?= $logId ?>" class="show-log-row" data-log='<?= $logData ?>' style="cursor:pointer" title="Click for details">
                    <td class="text-sm text-muted" style="white-space:nowrap"><?= e(date('d M Y', strtotime($a['performed_at']))) ?></td>
                    <td><span class="badge"><?= e($a['action_label']) ?></span></td>
                    <td class="show-log-desc">
                        <?= e(mb_strimwidth($a['description'] ?? '', 0, 60, '…')) ?>
                        <?php if (!empty($a['att_id'])): ?>
                        <span class="text-muted" style="font-size:.75rem"> 📷</span>
                        <?php endif; ?>
                    </td>
                    <td class="show-log-del-cell" onclick="event.stopPropagation()">
                        <button type="button" class="show-log-del-btn" data-log-id="<?= $logId ?>" title="Delete">✕</button>
                        <span class="show-log-del-confirm" id="logdel_<?= $logId ?>" style="display:none">
                            <form method="POST" action="<?= url('/activity-log/' . $logId . '/trash') ?>" style="display:inline">
                                <input type="hidden" name="_token" value="<?= $logCsrf ?>">
                                <button type="submit" class="show-log-del-yes">✓</button>
                            </form>
                            <button type="button" class="show-log-del-no" data-log-id="<?= $logId ?>">✕</button>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<style>
/* ── Fused log form ─────────────────────────── */
.log-field-row { padding: var(--spacing-3) var(--spacing-3) 0; }
.log-textarea {
    width: 100%; min-height: 90px; resize: vertical;
    font-family: inherit; line-height: 1.5;
}
.log-reminder-row {
    padding: var(--spacing-3) var(--spacing-3) 0;
    border-top: 1px solid var(--color-border);
    margin-top: var(--spacing-3);
}
.log-reminder-check {
    display: inline-flex; align-items: center; gap: 10px;
    cursor: pointer; font-size: .88rem; color: var(--color-text-muted);
    font-weight: 500;
}
.log-reminder-check input[type="checkbox"] {
    width: 18px; height: 18px; accent-color: var(--color-primary);
    cursor: pointer; flex-shrink: 0;
}
.log-reminder-check:has(input:checked) .log-reminder-check-text {
    color: var(--color-primary); font-weight: 600;
}
.log-submit-row {
    padding: var(--spacing-3);
}
.btn-block-mobile { width: 100%; justify-content: center; }

/* ── Inline calendar widget ─────────────────── */
.log-cal-panel {
    padding: var(--spacing-2) var(--spacing-3) var(--spacing-3);
    border-top: 1px solid var(--color-border);
}
.cal-widget {
    background: var(--color-surface);
    border: 1.5px solid var(--color-border);
    border-radius: 14px;
    overflow: hidden;
    max-width: 320px;
}
.cal-hdr {
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 14px 8px;
    background: var(--color-primary);
}
.cal-month-label {
    font-size: .9rem; font-weight: 700; color: #fff;
    letter-spacing: .01em;
}
.cal-nav-btn {
    background: rgba(255,255,255,.18); border: none; color: #fff;
    width: 30px; height: 30px; border-radius: 8px; font-size: 1.2rem;
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    transition: background .15s; line-height: 1;
}
.cal-nav-btn:hover { background: rgba(255,255,255,.32); }
.cal-dow {
    display: grid; grid-template-columns: repeat(7, 1fr);
    padding: 6px 8px 0;
}
.cal-dow span {
    text-align: center; font-size: .65rem; font-weight: 700;
    text-transform: uppercase; color: var(--color-text-muted); letter-spacing: .05em;
}
.cal-grid {
    display: grid; grid-template-columns: repeat(7, 1fr);
    gap: 2px; padding: 4px 8px 8px;
}
.cal-day-blank { /* empty placeholder */ }
.cal-day-btn {
    aspect-ratio: 1; border: none; background: none;
    border-radius: 8px; font-size: .82rem; font-weight: 500;
    cursor: pointer; color: var(--color-text);
    transition: background .12s, color .12s;
    display: flex; align-items: center; justify-content: center;
}
.cal-day-btn:hover { background: var(--color-primary-soft); color: var(--color-primary); }
.cal-day-btn.cal-day--today { font-weight: 800; color: var(--color-primary); }
.cal-day-btn.cal-day--selected {
    background: var(--color-primary); color: #fff; font-weight: 700;
}
.cal-day-btn.cal-day--past { opacity: .35; cursor: default; }
.cal-day-btn.cal-day--past:hover { background: none; color: var(--color-text); }
.cal-selected-label {
    padding: 8px 14px 10px;
    font-size: .82rem; font-weight: 600;
    color: var(--color-primary);
    border-top: 1px solid var(--color-border);
}

/* ── Log photo attach ───────────────────────── */
.log-photo-btn {
    display: inline-block; padding: 8px 16px; border-radius: 8px;
    background: var(--color-surface); border: 1.5px dashed var(--color-border);
    font-size: .82rem; color: var(--color-text-muted); cursor: pointer;
    transition: border-color .15s, color .15s; font-family: inherit;
    width: 100%; text-align: left; box-sizing: border-box;
}
.log-photo-btn:hover, .log-photo-btn:focus { border-color: var(--color-primary); color: var(--color-primary); outline: none; }
.log-photo-preview { display: none; }
.log-photo-thumbs { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
.log-photo-thumb-img { width: 72px; height: 72px; object-fit: cover; border-radius: 8px; border: 1.5px solid var(--color-border); }
/* ── Log thumbnails in table ────────────────── */
.show-log-thumb-link { display: block; margin-top: 5px; }
.show-log-thumb { width: 60px; height: 44px; object-fit: cover; border-radius: 6px; border: 1.5px solid var(--color-border); }
/* ── Feed item thumb ────────────────────────── */
.show-feed-thumb-link { flex-shrink: 0; }
.show-feed-thumb { width: 44px; height: 44px; object-fit: cover; border-radius: 8px; border: 1.5px solid var(--color-border); }

.item-dl-geojson {
    font-size:.68rem; line-height:1.4; overflow-x:auto; white-space:pre-wrap; word-break:break-all;
    background:var(--color-surface); border:1px solid var(--color-border);
    border-radius:6px; padding:6px 8px; margin-top:4px; max-height:120px;
    color:var(--color-text-muted);
}
.show-log-table { font-size:.82rem; width:100%; }
.show-log-desc { word-break:break-word; overflow-wrap:anywhere; max-width:180px; }
.show-log-del-cell { white-space:nowrap; text-align:right; padding-right:4px; }
.show-log-del-btn { background:none;border:none;cursor:pointer;color:var(--color-text-muted);font-size:.8rem;padding:2px 6px;border-radius:4px;opacity:.5;transition:opacity .15s,color .15s; }
.show-log-del-btn:hover { opacity:1;color:var(--color-danger,#c0392b); }
.show-log-del-confirm { display:inline-flex;align-items:center;gap:3px; }
.show-log-del-yes { background:var(--color-danger,#c0392b);color:#fff;border:none;border-radius:4px;font-size:.72rem;font-weight:700;padding:2px 7px;cursor:pointer; }
.show-log-del-no  { background:var(--color-border);color:var(--color-text-muted);border:none;border-radius:4px;font-size:.72rem;font-weight:700;padding:2px 7px;cursor:pointer; }

/* AI prompt modal */
.ai-modal-backdrop {
    display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);
    z-index:2000;align-items:flex-end;justify-content:center;
}
.ai-modal-sheet {
    background:var(--color-surface);border-radius:20px 20px 0 0;
    width:100%;max-width:640px;padding:var(--spacing-4);
    box-shadow:0 -4px 32px rgba(0,0,0,.2);
}
.ai-modal-header {
    display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--spacing-2);
}
.ai-modal-close {
    background:none;border:none;font-size:1.3rem;cursor:pointer;
    color:var(--color-text-muted);padding:4px 8px;border-radius:6px;
}
.ai-modal-textarea {
    width:100%;height:200px;font-size:.8rem;line-height:1.5;
    border:1.5px solid var(--color-border);border-radius:var(--radius-lg);
    padding:10px 12px;resize:none;font-family:inherit;box-sizing:border-box;
    background:var(--color-surface);color:var(--color-text);
}
.ai-modal-actions {
    display:flex;gap:var(--spacing-2);margin-top:var(--spacing-3);
}
</style>

<!-- AI Prompt modal sheet — must be before the <script> block so getElementById works -->
<div class="ai-modal-backdrop" id="aiModalBackdrop">
    <div class="ai-modal-sheet">
        <div class="ai-modal-header">
            <strong>🤖 AI Prompt</strong>
            <button type="button" class="ai-modal-close" id="aiModalCloseX">✕</button>
        </div>
        <p style="font-size:.8rem;color:var(--color-text-muted);margin:0 0 var(--spacing-2)">Paste this into Claude, ChatGPT, or any AI assistant.</p>
        <textarea class="ai-modal-textarea" id="aiModalText" readonly></textarea>
        <div class="ai-modal-actions">
            <button type="button" class="btn btn-primary" id="aiModalCopyBtn" style="flex:1">📋 Copy to Clipboard</button>
            <button type="button" class="btn btn-secondary" id="aiModalCloseBtn">Close</button>
        </div>
    </div>
</div>

<script>
// Log delete inline confirm
document.querySelectorAll('.show-log-del-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var id = btn.dataset.logId;
        btn.style.display = 'none';
        document.getElementById('logdel_' + id).style.display = 'inline-flex';
    });
});
document.querySelectorAll('.show-log-del-no').forEach(function(btn) {
    btn.addEventListener('click', function() {
        var id = btn.dataset.logId;
        document.getElementById('logdel_' + id).style.display = 'none';
        document.querySelector('.show-log-del-btn[data-log-id="' + id + '"]').style.display = '';
    });
});

// Log entry detail popup — modal HTML lives below this script, use DOMContentLoaded
document.addEventListener('DOMContentLoaded', function () {
    var backdrop  = document.getElementById('logDetailBackdrop');
    var closeBtn  = document.getElementById('logModalClose');
    var titleEl   = document.getElementById('logModalTitle');
    var badgeEl   = document.getElementById('logModalBadge');
    var dateEl    = document.getElementById('logModalDate');
    var descEl    = document.getElementById('logModalDesc');
    var photoWrap = document.getElementById('logModalPhoto');
    var photoImg  = document.getElementById('logModalPhotoImg');
    var photoLink = document.getElementById('logModalPhotoLink');

    if (!backdrop || !closeBtn) return;

    function openLogModal(data) {
        titleEl.textContent  = data.action || 'Log Entry';
        badgeEl.textContent  = data.action || '';
        dateEl.textContent   = data.date   || '';
        descEl.textContent   = data.description || '—';
        if (data.att_url && data.att_mime && data.att_mime.indexOf('image/') === 0) {
            photoImg.src            = data.att_url;
            photoLink.href          = data.att_url;
            photoWrap.style.display = '';
        } else {
            photoWrap.style.display = 'none';
            photoImg.src = '';
        }
        backdrop.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    function closeLogModal() {
        backdrop.style.display = 'none';
        document.body.style.overflow = '';
    }

    document.querySelectorAll('.show-log-row').forEach(function (row) {
        row.addEventListener('click', function () {
            try {
                var data = JSON.parse(row.getAttribute('data-log'));
                openLogModal(data);
            } catch(e) {}
        });
    });

    closeBtn.addEventListener('click', closeLogModal);
    backdrop.addEventListener('click', function (e) {
        if (e.target === backdrop) closeLogModal();
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && backdrop.style.display !== 'none') closeLogModal();
    });
});

// AI Prompt — shows text in a modal so clipboard copy is a direct user gesture (iOS-safe)
(function() {
    var btn      = document.getElementById('aiPromptBtn');
    if (!btn) return;
    var icon     = document.getElementById('aiPromptIcon');
    var label    = document.getElementById('aiPromptLabel');
    var backdrop = document.getElementById('aiModalBackdrop');
    var textarea = document.getElementById('aiModalText');
    var copyBtn  = document.getElementById('aiModalCopyBtn');
    var closeX   = document.getElementById('aiModalCloseX');
    var closeBtn = document.getElementById('aiModalCloseBtn');

    if (!backdrop) return;

    function openModal(text) {
        textarea.value = text;
        backdrop.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        setTimeout(function() { textarea.focus(); textarea.select(); }, 80);
    }
    function closeModal() {
        backdrop.style.display = 'none';
        document.body.style.overflow = '';
        copyBtn.textContent = '📋 Copy to Clipboard';
    }

    btn.addEventListener('click', function() {
        icon.textContent = '⏳'; label.textContent = 'Building…';
        fetch(btn.dataset.url)
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (!data.prompt) throw new Error('empty');
                icon.textContent = '🤖'; label.textContent = 'Copy AI';
                openModal(data.prompt);
            })
            .catch(function() {
                icon.textContent = '❌'; label.textContent = 'Error';
                setTimeout(function() { icon.textContent = '🤖'; label.textContent = 'Copy AI'; }, 2000);
            });
    });

    copyBtn.addEventListener('click', function() {
        var text = textarea.value;
        function fallback() {
            textarea.select();
            try { document.execCommand('copy'); copyBtn.textContent = '✅ Copied!'; }
            catch(e) { copyBtn.textContent = '⚠️ Select text above and copy'; }
        }
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text)
                .then(function() { copyBtn.textContent = '✅ Copied!'; })
                .catch(fallback);
        } else { fallback(); }
    });

    closeX.addEventListener('click', closeModal);
    closeBtn.addEventListener('click', closeModal);
    backdrop.addEventListener('click', function(e) { if (e.target === backdrop) closeModal(); });
    document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeModal(); });
}());

// Scroll to anchor sections
function expandSection(id) {
    setTimeout(function() {
        var el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
}

// ── Action type "Other" toggle ───────────────────────────────────────────────
(function(){
    var sel  = document.getElementById('logActionType');
    var wrap = document.getElementById('logCustomLabelWrap');
    if (!sel || !wrap) return;
    sel.addEventListener('change', function() {
        wrap.style.display = sel.value === 'other' ? '' : 'none';
        if (sel.value === 'other') {
            document.getElementById('logCustomLabel').focus();
        }
    });
}());

// Pre-check reminder checkbox (called from "Reminder" quick action)
function preCheckReminder() {
    var cb = document.getElementById('setReminderCb');
    if (cb && !cb.checked) { cb.checked = true; cb.dispatchEvent(new Event('change')); }
}

// ── Log photo attach toggle ──────────────────────────────────────────────────
(function() {
    var cb      = document.getElementById('setPhotoCb');
    var panel   = document.getElementById('logPhotoPanel');
    var input   = document.getElementById('logPhotoInput');
    var pickerBtn = document.getElementById('logPhotoPickerBtn');
    var preview = document.getElementById('logPhotoPreview');
    if (!cb || !panel) return;

    cb.addEventListener('change', function() {
        panel.style.display = cb.checked ? '' : 'none';
        if (cb.checked && pickerBtn) {
            // Small delay so the panel is rendered before programmatic click
            setTimeout(function() { input && input.click(); }, 80);
        }
    });

    // Programmatic click — reliable on iOS PWA where label+display:none fails
    if (pickerBtn) {
        pickerBtn.addEventListener('click', function() {
            input && input.click();
        });
    }

    if (input) {
        input.addEventListener('change', function() {
            if (!input.files || !input.files.length) return;
            var files = Array.from(input.files);
            var html = '<div class="log-photo-thumbs">';
            var remaining = files.length;
            files.forEach(function(file, i) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    html += '<img src="' + e.target.result + '" class="log-photo-thumb-img" alt="Photo ' + (i+1) + '">';
                    remaining--;
                    if (remaining === 0) {
                        preview.innerHTML = html + '</div>';
                        preview.style.display = '';
                    }
                };
                reader.readAsDataURL(file);
            });
            pickerBtn.textContent = '📷 ' + files.length + ' photo' + (files.length !== 1 ? 's' : '') + ' selected — tap to change';
        });
    }
}());

// ── Inline calendar picker ───────────────────────────────────────────────────
(function () {
    var cb         = document.getElementById('setReminderCb');
    var panel      = document.getElementById('reminderPickerPanel');
    var hiddenInput= document.getElementById('reminderDueAt');
    var calGrid    = document.getElementById('calGrid');
    var calLabel   = document.getElementById('calMonthLabel');
    var calSelected= document.getElementById('calSelectedLabel');
    var prevBtn    = document.getElementById('calPrevBtn');
    var nextBtn    = document.getElementById('calNextBtn');
    if (!cb || !panel) return;

    // Default date = today + 7 days
    var today    = new Date();
    today.setHours(0,0,0,0);
    var defDate  = new Date(today);
    defDate.setDate(defDate.getDate() + 7);

    var viewYear  = defDate.getFullYear();
    var viewMonth = defDate.getMonth(); // 0-indexed
    var selected  = new Date(defDate);

    var MONTHS = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];
    var DAYS   = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

    function isoDate(d) {
        var y = d.getFullYear();
        var m = String(d.getMonth()+1).padStart(2,'0');
        var day = String(d.getDate()).padStart(2,'0');
        return y+'-'+m+'-'+day+' 09:00:00';
    }
    function formatDisplay(d) {
        return DAYS[(d.getDay()+6)%7] + ', ' + d.getDate() + ' ' + MONTHS[d.getMonth()] + ' ' + d.getFullYear();
    }

    function renderCalendar() {
        calLabel.textContent = MONTHS[viewMonth] + ' ' + viewYear;
        calGrid.innerHTML = '';

        // First day of month (0=Sun…6=Sat) → convert to Mo-based (0=Mo…6=Su)
        var firstDay = new Date(viewYear, viewMonth, 1).getDay();
        var offset   = (firstDay + 6) % 7; // blanks before day 1
        var daysInMonth = new Date(viewYear, viewMonth+1, 0).getDate();

        for (var i = 0; i < offset; i++) {
            var blank = document.createElement('span');
            blank.className = 'cal-day-blank';
            calGrid.appendChild(blank);
        }

        for (var d = 1; d <= daysInMonth; d++) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'cal-day-btn';
            btn.textContent = d;

            var thisDate = new Date(viewYear, viewMonth, d);
            if (thisDate.toDateString() === today.toDateString()) btn.classList.add('cal-day--today');
            if (selected && thisDate.toDateString() === selected.toDateString()) btn.classList.add('cal-day--selected');
            if (thisDate < today) btn.classList.add('cal-day--past');

            btn.addEventListener('click', (function(date) {
                return function() {
                    selected = date;
                    hiddenInput.value = isoDate(date);
                    calSelected.textContent = '📅 ' + formatDisplay(date);
                    calSelected.style.display = 'block';
                    renderCalendar();
                };
            })(new Date(viewYear, viewMonth, d)));

            calGrid.appendChild(btn);
        }
    }

    function show() {
        panel.style.display = 'block';
        // Set default immediately
        hiddenInput.value = isoDate(defDate);
        calSelected.textContent = '📅 ' + formatDisplay(defDate);
        calSelected.style.display = 'block';
        renderCalendar();
    }
    function hide() {
        panel.style.display = 'none';
        hiddenInput.value = '';
    }

    cb.addEventListener('change', function() {
        if (cb.checked) show(); else hide();
    });

    prevBtn.addEventListener('click', function() {
        viewMonth--; if (viewMonth < 0) { viewMonth = 11; viewYear--; } renderCalendar();
    });
    nextBtn.addEventListener('click', function() {
        viewMonth++; if (viewMonth > 11) { viewMonth = 0; viewYear++; } renderCalendar();
    });
}());

// ── Log action form — compress photos then AJAX submit ────────────────────────
(function() {
    var form = document.querySelector('#note-section form');
    if (!form) return;

    // Compress a single image file to max 1600px / 80% JPEG (~300–800 KB).
    function compressPhoto(file, cb) {
        if (!file.type || file.type.indexOf('image/') !== 0) { cb(file); return; }
        var reader = new FileReader();
        reader.onload = function(ev) {
            var img = new Image();
            img.onload = function() {
                var MAX = 1600, w = img.width, h = img.height;
                var ratio = Math.min(MAX / w, MAX / h, 1);
                var canvas = document.createElement('canvas');
                canvas.width  = Math.round(w * ratio);
                canvas.height = Math.round(h * ratio);
                canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(function(blob) {
                    if (!blob) { cb(file); return; }
                    cb(new File([blob],
                        file.name.replace(/\.[^.]+$/, '') + '.jpg',
                        { type: 'image/jpeg', lastModified: Date.now() }));
                }, 'image/jpeg', 0.80);
            };
            img.onerror  = function() { cb(file); };
            img.src      = ev.target.result;
        };
        reader.onerror = function() { cb(file); };
        reader.readAsDataURL(file);
    }

    function compressAll(files, cb) {
        var out = [], remaining = files.length;
        if (!remaining) { cb(out); return; }
        files.forEach(function(file, i) {
            compressPhoto(file, function(compressed) {
                out[i] = compressed;
                if (--remaining === 0) cb(out);
            });
        });
    }

    form.addEventListener('submit', function(e) {
        e.preventDefault();

        var btn  = form.querySelector('[type="submit"]');
        var orig = btn.textContent;
        btn.disabled    = true;

        var fileInput = document.getElementById('logPhotoInput');
        var files     = fileInput && fileInput.files ? Array.from(fileInput.files) : [];

        function doUpload(compressedFiles) {
            btn.textContent = 'Logging…';

            var fd;
            if (!compressedFiles.length) {
                fd = new FormData(form);
            } else {
                // Build FormData manually so we can swap in compressed blobs.
                fd = new FormData();
                Array.from(form.elements).forEach(function(el) {
                    if (!el.name || el.disabled || el.type === 'file') return;
                    if ((el.type === 'checkbox' || el.type === 'radio') && !el.checked) return;
                    fd.append(el.name, el.value);
                });
                compressedFiles.forEach(function(f) {
                    fd.append('log_photos[]', f, f.name);
                });
            }

            var ctrl  = typeof AbortController !== 'undefined' ? new AbortController() : null;
            var timer = ctrl ? setTimeout(function() { ctrl.abort(); }, 60000) : null;

            fetch(form.action, {
                method:  'POST',
                body:    fd,
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                signal:  ctrl ? ctrl.signal : undefined,
            })
            .then(function(r) {
                if (timer) clearTimeout(timer);
                return r.json().catch(function() { throw new Error('status:' + r.status); });
            })
            .then(function(data) {
                if (data.success) {
                    window.location.reload();
                } else {
                    btn.disabled    = false;
                    btn.textContent = orig;
                    alert(data.error || 'Could not log action. Please try again.');
                }
            })
            .catch(function(err) {
                if (timer) clearTimeout(timer);
                btn.disabled    = false;
                btn.textContent = orig;
                var msg = (err && err.name === 'AbortError')
                    ? 'Upload timed out. Check your connection and try again.'
                    : 'Something went wrong. Please try again.';
                alert(msg);
            });
        }

        if (files.length) {
            btn.textContent = 'Compressing…';
            compressAll(files, doUpload);
        } else {
            doUpload([]);
        }
    });
}());
</script>

<style>
/* =========================================================
   Item Show — v1.4.15
   ========================================================= */

/* Hero */
.show-hero {
    position: relative;
    border-radius: 20px;
    overflow: hidden;
    margin-bottom: var(--spacing-4);
    box-shadow: 0 4px 32px rgba(0,0,0,0.14), 0 1px 4px rgba(0,0,0,0.08);
}
.show-hero-photo {
    width: 100%; height: 300px;
    position: relative; overflow: hidden;
    background: #111;
}
.show-hero-photo img { width:100%;height:100%;display:block;object-fit:cover;object-position:center; }
.show-hero-photo-overlay { position:absolute;inset:0;background:linear-gradient(to bottom,rgba(0,0,0,.05) 0%,rgba(0,0,0,.60) 100%); }
.show-hero-avatar { width:52px;height:52px;border-radius:50%;overflow:hidden;border:2.5px solid rgba(255,255,255,0.75);margin-bottom:8px;box-shadow:0 2px 8px rgba(0,0,0,0.35);flex-shrink:0; }
.show-hero-avatar img { width:100%;height:100%;object-fit:cover;display:block; }
.show-hero-photo--placeholder { height:200px;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--item-color,#2d6a4f),color-mix(in srgb,var(--item-color,#2d6a4f) 60%,#000)); }
.show-hero-placeholder-emoji { font-size:5rem;opacity:.45; }

.show-hero-content { position:absolute;bottom:0;left:0;right:0;padding:var(--spacing-3) var(--spacing-4) var(--spacing-4);color:#fff; }
.show-hero-back { display:flex;align-items:center;justify-content:space-between;margin-bottom:var(--spacing-3); }
.show-back-btn {
    display:inline-flex;align-items:center;gap:4px;color:rgba(255,255,255,.85);
    font-size:.78rem;font-weight:600;text-decoration:none;
    background:rgba(0,0,0,.25);padding:4px 10px;border-radius:var(--radius-pill);
    backdrop-filter:blur(8px);
}
.show-back-btn:hover{color:#fff;text-decoration:none;}
.show-edit-btn {
    display:inline-flex;align-items:center;gap:4px;color:rgba(255,255,255,.85);
    font-size:.78rem;font-weight:600;text-decoration:none;
    background:rgba(0,0,0,.25);padding:4px 10px;border-radius:var(--radius-pill);
    backdrop-filter:blur(8px);
}
.show-edit-btn:hover{color:#fff;text-decoration:none;}
.show-hero-badge {
    display:inline-flex;align-items:center;font-size:.7rem;font-weight:800;
    text-transform:uppercase;letter-spacing:.08em;background:rgba(255,255,255,.2);
    backdrop-filter:blur(8px);padding:3px 10px;border-radius:var(--radius-pill);
    margin-bottom:5px;color:#fff;
}
.show-hero-name {
    font-size:1.8rem;font-weight:900;color:#fff;margin:0;
    letter-spacing:-.03em;line-height:1.1;text-shadow:0 1px 8px rgba(0,0,0,.3);
}
@media(max-width:380px){.show-hero-name{font-size:1.4rem;}}
.show-hero-status {
    display:inline-block;background:rgba(220,38,38,.85);color:#fff;
    font-size:.7rem;font-weight:700;padding:3px 10px;border-radius:var(--radius-pill);
    text-transform:uppercase;letter-spacing:.05em;margin-top:4px;
}

/* Quick actions */
.show-quick-actions {
    display:flex;gap:8px;overflow-x:auto;-webkit-overflow-scrolling:touch;
    scrollbar-width:none;padding-bottom:4px;margin-bottom:var(--spacing-4);
}
.show-quick-actions::-webkit-scrollbar{display:none;}
.show-qa-btn {
    display:inline-flex;flex-direction:row;align-items:center;gap:7px;
    padding:9px 16px;border-radius:999px;white-space:nowrap;flex-shrink:0;
    background:var(--color-surface-raised);border:1.5px solid var(--color-border);
    color:var(--color-text);text-decoration:none;cursor:pointer;
    font-size:.82rem;font-weight:600;
    transition:border-color .15s,background .15s,color .15s;
    box-shadow:var(--shadow-sm);font-family:inherit;
}
.show-qa-btn:hover{border-color:var(--color-primary);background:var(--color-primary-soft);color:var(--color-primary);text-decoration:none;}
.show-qa-icon{font-size:1.1rem;line-height:1;}

/* Sections */
.show-section { margin-bottom:var(--spacing-4); }
.show-section-head {
    display:flex;align-items:center;justify-content:space-between;
    margin-bottom:var(--spacing-2);
}
.show-section-title { font-size:.82rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:var(--color-text-muted); }
.show-section-link { font-size:.78rem;font-weight:700;color:var(--color-primary);text-decoration:none; }
.show-section-link:hover{text-decoration:underline;}

/* Photo grid */
.show-photo-grid {
    display:grid;gap:4px;border-radius:var(--radius-lg);overflow:hidden;
}
.show-photo-grid--1{grid-template-columns:1fr;}
.show-photo-grid--2{grid-template-columns:repeat(2,1fr);}
.show-photo-grid--3{grid-template-columns:repeat(2,1fr);grid-template-rows:auto auto;}
.show-photo-grid--3 .show-photo-thumb:first-child{grid-column:1/-1;}
.show-photo-grid--4{grid-template-columns:repeat(2,1fr);}
.show-photo-grid--dense{grid-template-columns:repeat(4,1fr);}
.show-photo-thumb {
    position:relative;aspect-ratio:1;overflow:hidden;display:block;
    background:var(--color-surface);
}
.show-photo-thumb img { width:100%;height:100%;object-fit:cover;display:block;transition:transform .3s; }
.show-photo-thumb:hover img { transform:scale(1.04); }
.show-photo-more {
    position:absolute;inset:0;background:rgba(0,0,0,.55);
    display:flex;align-items:center;justify-content:center;
    color:#fff;font-size:1.4rem;font-weight:800;
}

/* Activity feed */
.show-activity-feed { display:flex;flex-direction:column;gap:2px; }
.show-feed-item {
    display:flex;align-items:center;gap:var(--spacing-3);
    padding:var(--spacing-2) var(--spacing-3);
    background:var(--color-surface-raised);border-radius:var(--radius);
    border:1px solid var(--color-border);
}
.show-feed-item--reminder { border-left:3px solid var(--color-primary); }
.show-feed-item--overdue  { border-left:3px solid var(--color-danger,#c0392b);background:#fff8f8; }
.show-feed-icon { font-size:1.2rem;flex-shrink:0; }
.show-feed-body { flex:1;min-width:0; }
.show-feed-text { font-size:.85rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis; }
.show-feed-date { font-size:.72rem;color:var(--color-text-muted);margin-top:1px; }
.show-feed-action { flex-shrink:0; }
.show-feed-done {
    width:28px;height:28px;border-radius:50%;background:var(--color-primary-soft);
    border:1.5px solid var(--color-primary);color:var(--color-primary);
    cursor:pointer;font-size:.9rem;font-weight:800;
    display:flex;align-items:center;justify-content:center;
    transition:background .15s;
}
.show-feed-done:hover{background:var(--color-primary);color:#fff;}

/* Detail card */
.item-detail-card {
    background:var(--color-surface-raised);border-radius:var(--radius-lg);
    padding:var(--spacing-3) var(--spacing-4);box-shadow:var(--shadow-card);
}
.item-dl { margin:0; }
.item-dl-row {
    display:flex;gap:var(--spacing-3);padding:8px 0;
    border-bottom:1px solid var(--color-border);
    font-size:.875rem;align-items:baseline;
}
.item-dl-row:last-child{border-bottom:none;}
.item-dl-row dt{width:90px;flex-shrink:0;color:var(--color-text-muted);font-weight:600;font-size:.78rem;}
.item-dl-row dd{flex:1;min-width:0;font-weight:500;}

/* Inline forms */
.show-form-row { display:flex;gap:var(--spacing-2);flex-wrap:wrap;align-items:center; }
.show-reminder-for-badge {
    display:inline-flex;align-items:center;gap:6px;
    padding:5px 12px;border-radius:var(--radius-pill);
    background:var(--color-primary-soft);color:var(--color-primary);
    font-size:.78rem;font-weight:700;margin-bottom:var(--spacing-2);
}

/* ── Hero clickable ─────────────────────────── */
.show-hero-photo--clickable { cursor: zoom-in; }

/* ── Gallery lightbox ───────────────────────── */
.gallery-overlay {
    position: fixed; inset: 0; z-index: 9999;
    background: rgba(0,0,0,0.93);
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    touch-action: pan-y;
}
.gallery-close {
    position: absolute; top: 14px; right: 14px;
    background: rgba(255,255,255,.18); border: none;
    color: #fff; font-size: 1.2rem;
    width: 42px; height: 42px; border-radius: 50%;
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    z-index: 10; transition: background .15s; line-height: 1;
}
.gallery-close:hover { background: rgba(255,255,255,.32); }
.gallery-prev, .gallery-next {
    position: absolute; top: 50%; transform: translateY(-50%);
    background: rgba(255,255,255,.15); border: none;
    color: #fff; font-size: 1.9rem; font-weight: 300;
    width: 50px; height: 50px; border-radius: 50%;
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    z-index: 10; transition: background .15s; line-height: 1;
}
.gallery-prev { left: 14px; }
.gallery-next { right: 14px; }
.gallery-prev:hover, .gallery-next:hover { background: rgba(255,255,255,.32); }
@media(max-width:600px) {
    .gallery-prev, .gallery-next { width:38px;height:38px;font-size:1.5rem; }
    .gallery-prev { left:6px; }
    .gallery-next { right:6px; }
}
.gallery-img-wrap {
    max-width: calc(100vw - 120px);
    max-height: calc(100vh - 110px);
    display: flex; align-items: center; justify-content: center;
    flex: 1;
}
@media(max-width:600px) {
    .gallery-img-wrap { max-width: calc(100vw - 80px); }
}
.gallery-img-wrap img {
    max-width: 100%;
    max-height: calc(100vh - 110px);
    object-fit: contain; border-radius: 4px;
    display: block; user-select: none;
    transition: opacity .12s ease;
}
.gallery-footer {
    position: absolute; bottom: 0; left: 0; right: 0;
    padding: 14px 20px 20px;
    background: linear-gradient(to top, rgba(0,0,0,.7) 0%, transparent 100%);
    text-align: center; pointer-events: none;
}
.gallery-counter {
    color: rgba(255,255,255,.75); font-size: .82rem; font-weight: 600;
    letter-spacing: .03em;
}
.gallery-caption {
    color: rgba(255,255,255,.88); font-size: .88rem; margin-top: 4px;
    padding: 0 60px; line-height: 1.4;
}
.show-photo-thumb { cursor: pointer; }

/* ── Log detail modal ───────────────────────────────────────────── */
.log-modal-backdrop {
    position: fixed; inset: 0; z-index: 4000;
    background: rgba(0,0,0,.72);
    display: flex; align-items: center; justify-content: center;
    padding: 16px;
    animation: logFadeIn .18s ease;
}
@keyframes logFadeIn { from { opacity:0 } to { opacity:1 } }
.log-modal {
    background: var(--color-surface);
    border-radius: 18px;
    width: 100%; max-width: 480px;
    max-height: 90vh; overflow-y: auto;
    box-shadow: 0 24px 64px rgba(0,0,0,.45);
    animation: logSlideUp .22s cubic-bezier(.25,.8,.25,1);
    position: relative;
}
@keyframes logSlideUp { from { transform:translateY(24px);opacity:0 } to { transform:translateY(0);opacity:1 } }
.log-modal-header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 18px 20px 12px;
    border-bottom: 1px solid var(--color-border);
}
.log-modal-title { font-weight: 700; font-size: 1rem; }
.log-modal-close {
    background: none; border: none; font-size: 1.2rem; cursor: pointer;
    color: var(--color-text-muted); padding: 4px 8px; border-radius: 6px;
    transition: background .12s;
}
.log-modal-close:hover { background: var(--color-border); }
.log-modal-body { padding: 16px 20px 20px; }
.log-modal-badge { display: inline-block; margin-bottom: 12px; }
.log-modal-date { font-size: .82rem; color: var(--color-text-muted); margin-bottom: 10px; }
.log-modal-desc {
    font-size: .93rem; line-height: 1.6;
    word-break: break-word; white-space: pre-wrap;
    color: var(--color-text);
    background: var(--color-bg);
    border: 1px solid var(--color-border);
    border-radius: 8px; padding: 12px 14px;
}
.log-modal-photo { margin-top: 12px; }
.log-modal-photo img { max-width: 100%; border-radius: 10px; border: 1px solid var(--color-border); }
.log-row-hint { font-size: .72rem; color: var(--color-text-muted); margin-top: 2px; opacity:.7 }
</style>

<!-- ── Log detail modal ─────────────────────────────────────────── -->
<div id="logDetailBackdrop" class="log-modal-backdrop" style="display:none" role="dialog" aria-modal="true" aria-label="Log entry detail">
    <div class="log-modal" id="logDetailModal">
        <div class="log-modal-header">
            <span class="log-modal-title" id="logModalTitle">Log Entry</span>
            <button class="log-modal-close" id="logModalClose" aria-label="Close">&#10005;</button>
        </div>
        <div class="log-modal-body">
            <div class="log-modal-badge"><span class="badge" id="logModalBadge"></span></div>
            <div class="log-modal-date" id="logModalDate"></div>
            <div class="log-modal-desc" id="logModalDesc"></div>
            <div class="log-modal-photo" id="logModalPhoto" style="display:none">
                <a id="logModalPhotoLink" href="#" target="_blank">
                    <img id="logModalPhotoImg" src="" alt="Log photo">
                </a>
            </div>
        </div>
    </div>
</div>


<!-- ── Gallery overlay ─────────────────────────────────────────── -->
<div id="galleryOverlay" class="gallery-overlay" style="display:none" role="dialog" aria-modal="true" aria-label="Photo gallery">
    <button class="gallery-close" id="galleryClose" aria-label="Close gallery">&#10005;</button>
    <button class="gallery-prev" id="galleryPrev" aria-label="Previous photo">&#8249;</button>
    <div class="gallery-img-wrap">
        <img id="galleryImg" src="" alt="">
    </div>
    <button class="gallery-next" id="galleryNext" aria-label="Next photo">&#8250;</button>
    <div class="gallery-footer">
        <div class="gallery-counter" id="galleryCounter"></div>
        <div class="gallery-caption" id="galleryCaption"></div>
    </div>
</div>

<script>
(function () {
    var items = <?php
        $galleryData = [];
        foreach ($imageAttachments as $att) {
            $galleryData[] = [
                'src'     => att_url((int)$att['id']),
                'caption' => $att['caption'] ?? ($att['original_name'] ?? ''),
            ];
        }
        echo json_encode($galleryData, JSON_HEX_TAG | JSON_HEX_AMP);
    ?>;

    // Declare all DOM refs at the top — before any early return — so the
    // closure assigned to window.openGallery can reference them safely.
    var overlay   = document.getElementById('galleryOverlay');
    var imgEl     = document.getElementById('galleryImg');
    var counter   = document.getElementById('galleryCounter');
    var captionEl = document.getElementById('galleryCaption');
    var closeBtn  = document.getElementById('galleryClose');
    var prevBtn   = document.getElementById('galleryPrev');
    var nextBtn   = document.getElementById('galleryNext');
    var current   = 0;
    var total     = items.length;

    function galleryShow(idx) {
        current = ((idx % total) + total) % total;
        imgEl.style.opacity = '0.4';
        imgEl.src = items[current].src;
        imgEl.onload = function () { imgEl.style.opacity = '1'; };
        counter.textContent = (current + 1) + ' / ' + total;
        captionEl.textContent = items[current].caption || '';
    }

    function galleryOpen(idx) {
        if (!items.length || !overlay) return;
        galleryShow(idx);
        overlay.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    function galleryClose() {
        if (!overlay) return;
        overlay.style.display = 'none';
        document.body.style.overflow = '';
        imgEl.src = '';
    }

    // Direct reference — no wrapper, no name collision with window.open
    window.openGallery = galleryOpen;

    // Skip event listener setup when there are no images or overlay is missing
    if (!items.length || !overlay) return;

    closeBtn.addEventListener('click', galleryClose);
    prevBtn.addEventListener('click', function () { galleryShow(current - 1); });
    nextBtn.addEventListener('click', function () { galleryShow(current + 1); });

    // Click on backdrop (not on img/buttons) closes gallery
    overlay.addEventListener('click', function (e) {
        if (e.target === overlay) galleryClose();
    });

    // Keyboard navigation
    document.addEventListener('keydown', function (e) {
        if (overlay.style.display === 'none') return;
        if (e.key === 'ArrowLeft'  || e.key === 'ArrowUp')   { galleryShow(current - 1); e.preventDefault(); }
        else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { galleryShow(current + 1); e.preventDefault(); }
        else if (e.key === 'Escape') galleryClose();
    });

    // Touch swipe
    var touchStartX = 0;
    var touchStartY = 0;
    overlay.addEventListener('touchstart', function (e) {
        touchStartX = e.changedTouches[0].clientX;
        touchStartY = e.changedTouches[0].clientY;
    }, { passive: true });
    overlay.addEventListener('touchend', function (e) {
        var dx = e.changedTouches[0].clientX - touchStartX;
        var dy = e.changedTouches[0].clientY - touchStartY;
        if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
            if (dx < 0) galleryShow(current + 1);
            else        galleryShow(current - 1);
        }
    }, { passive: true });
}());
</script>
