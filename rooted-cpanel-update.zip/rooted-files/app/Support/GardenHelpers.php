<?php

namespace App\Support;

/**
 * Pure PHP helpers for the Garden Redesign — port of the JSX prototype's data.jsx.
 * No DB calls in this class; callers fetch data, then run helpers on arrays.
 *
 * Conventions:
 *   $crop      = ['id'=>int, 'name'=>str, 'emoji'=>str, 'color'=>'#RRGGBB',
 *                 'spacing_cm'=>int, 'family'=>str, 'season'=>str,
 *                 'days_to_maturity'=>int]
 *   $planting  = ['cropId'=>int, 'plants'=>int, 'sown_at'=>'YYYY-MM-DD']
 *   $line      = ['id'=>int, 'lineNumber'=>int, 'lengthCm'=>int,
 *                 'plantings'=>[$planting,...], 'status'=>str,
 *                 'sown_at'=>str|null, 'empty_since'=>str|null,
 *                 'last_watered_at'=>str|null,
 *                 'succession'=>['cropId'=>int,'startsOn'=>str]|null,
 *                 'rotation_history'=>[{year,season,cropId},...]]
 */
class GardenHelpers
{
    /** Fallback color palette by family (when seed has no color). */
    public const FAMILY_COLORS = [
        'root'   => '#E07A3C',
        'leaf'   => '#5A8C3F',
        'fruit'  => '#C0413A',
        'herb'   => '#7BA84A',
        'allium' => '#B89A6A',
        'legume' => '#9C8049',
        'other'  => '#A66141',
    ];

    /**
     * Distinct color palette used when no explicit color and no family color
     * is set — picked deterministically per seed so each one gets a unique hue.
     */
    public const CATALOG_COLORS = [
        '#E76F51', '#F4A261', '#E9C46A', '#2A9D8F', '#264653',
        '#8AB17D', '#B5838D', '#6D597A', '#355070', '#E07A5F',
        '#81B29A', '#F2CC8F', '#D62828', '#F77F00', '#588157',
        '#9D4EDD', '#6A994E', '#BC4749', '#386641', '#A7C957',
    ];

    /**
     * Pick a color from CATALOG_COLORS deterministically based on a seed's
     * identifier (id or name). Same key → same color across the app.
     */
    public static function defaultCatalogColor(int|string $key): string
    {
        $hash = is_int($key) ? $key : crc32((string)$key);
        return self::CATALOG_COLORS[abs($hash) % count(self::CATALOG_COLORS)];
    }

    /** Fallback emoji by family. */
    public const FAMILY_EMOJI = [
        'root'   => '🥕',
        'leaf'   => '🥬',
        'fruit'  => '🍅',
        'herb'   => '🌿',
        'allium' => '🧅',
        'legume' => '🫘',
        'other'  => '🌱',
    ];

    public static function todayIso(): string
    {
        return (new \DateTime('today'))->format('Y-m-d');
    }

    /**
     * A crop record's display color.
     * Priority:
     *  1. explicit color field on the seed (#RRGGBB)
     *  2. deterministic per-seed pick from CATALOG_COLORS (so each seed in
     *     the same family is still visually distinct in the planting view).
     */
    public static function cropColor(array $crop): string
    {
        $c = $crop['color'] ?? null;
        if ($c && preg_match('/^#[0-9a-f]{6}$/i', $c)) return $c;
        $key = (int)($crop['id'] ?? 0);
        if ($key === 0) $key = $crop['name'] ?? 'other';
        return self::defaultCatalogColor($key);
    }

    /** A crop record's display emoji, with family fallback. */
    public static function cropEmoji(array $crop): string
    {
        $e = $crop['emoji'] ?? null;
        if ($e !== null && $e !== '') return $e;
        $fam = $crop['family'] ?? 'other';
        return self::FAMILY_EMOJI[$fam] ?? '🌱';
    }

    /** Days between two ISO dates (b - a). */
    public static function daysBetween(string $a, string $b): int
    {
        $da = new \DateTime($a);
        $db = new \DateTime($b);
        $diff = $db->getTimestamp() - $da->getTimestamp();
        return (int)round($diff / 86400);
    }

    /** Add N days (may be negative) to an ISO date, return ISO date. */
    public static function addDays(string $iso, int $n): string
    {
        $d = new \DateTime($iso);
        $d->modify(($n >= 0 ? '+' : '') . $n . ' days');
        return $d->format('Y-m-d');
    }

    /** Short display date "Apr 28". Empty string for nulls. */
    public static function fmtDate(?string $iso): string
    {
        if (!$iso) return '';
        try {
            return (new \DateTime($iso))->format('M j');
        } catch (\Throwable $e) {
            return '';
        }
    }

    /** Year for a given ISO date (or current year). */
    public static function yearOf(?string $iso = null): int
    {
        return (int)(new \DateTime($iso ?: 'today'))->format('Y');
    }

    /** Season for a given month (cool/warm). */
    public static function seasonOfMonth(int $month): string
    {
        // Northern-hemisphere defaults: Apr–Sep = warm, else cool.
        return ($month >= 4 && $month <= 9) ? 'warm' : 'cool';
    }

    /** Used cm summed across plantings, given a $cropsById map keyed by cropId => crop[]. */
    public static function computeFill(array $line, array $cropsById): array
    {
        $used = 0;
        foreach (($line['plantings'] ?? []) as $p) {
            $c = $cropsById[$p['cropId'] ?? 0] ?? null;
            if (!$c) continue;
            $used += (int)($c['spacing_cm'] ?? 0) * (int)($p['plants'] ?? 0);
        }
        $length = (int)($line['lengthCm'] ?? 0);
        $remaining = max(0, $length - $used);
        return [
            'used'      => $used,
            'remaining' => $remaining,
            'pct'       => $length > 0 ? min(1.0, $used / $length) : 0,
        ];
    }

    /** Stripe segments for rendering. */
    public static function computeSegments(array $line, array $cropsById): array
    {
        $length = max(1, (int)($line['lengthCm'] ?? 0));
        $out = [];
        foreach (($line['plantings'] ?? []) as $p) {
            $c = $cropsById[$p['cropId'] ?? 0] ?? null;
            if (!$c) continue;
            $cm = (int)($c['spacing_cm'] ?? 0) * (int)($p['plants'] ?? 0);
            $out[] = [
                'plantingId' => (int)($p['id'] ?? 0),
                'cropId' => (int)$p['cropId'],
                'crop'   => $c,
                'plants' => (int)$p['plants'],
                'cm'     => $cm,
                'pct'    => $cm / $length,
                'sown_at'=> $p['sown_at'] ?? ($line['sown_at'] ?? null),
            ];
        }
        return $out;
    }

    /** Earliest planting harvest date for a line (last crop to mature). Null if no plantings. */
    public static function lineHarvestDate(array $line, array $cropsById): ?string
    {
        $plantings = $line['plantings'] ?? [];
        if (empty($plantings)) return null;
        $dates = [];
        foreach ($plantings as $p) {
            $c = $cropsById[$p['cropId'] ?? 0] ?? null;
            if (!$c) continue;
            $sownAt = $p['sown_at'] ?? ($line['sown_at'] ?? null);
            if (!$sownAt) continue;
            $dth = (int)($c['days_to_maturity'] ?? 60);
            $dates[] = self::addDays($sownAt, $dth);
        }
        if (empty($dates)) return null;
        sort($dates);
        return end($dates);
    }

    public static function lineSownDate(array $line): ?string
    {
        $plantings = $line['plantings'] ?? [];
        if (empty($plantings)) return $line['sown_at'] ?? null;
        $dates = [];
        foreach ($plantings as $p) {
            $d = $p['sown_at'] ?? ($line['sown_at'] ?? null);
            if ($d) $dates[] = $d;
        }
        if (empty($dates)) return null;
        sort($dates);
        return $dates[0];
    }

    /** Days until the line's last planting matures. Negative = overdue. Null = no plantings. */
    public static function daysToLineHarvest(array $line, array $cropsById, ?string $today = null): ?int
    {
        $h = self::lineHarvestDate($line, $cropsById);
        if (!$h) return null;
        return self::daysBetween($today ?: self::todayIso(), $h);
    }

    /** Maturity 0..1 for one planting. */
    public static function maturity(array $planting, array $line, array $crop, ?string $today = null): float
    {
        $sown = $planting['sown_at'] ?? ($line['sown_at'] ?? null);
        if (!$sown) return 0.0;
        $dth = max(1, (int)($crop['days_to_maturity'] ?? 60));
        $elapsed = self::daysBetween($sown, $today ?: self::todayIso());
        return max(0.0, min(1.0, $elapsed / $dth));
    }

    /**
     * Rotation warning. If $candidateCrop's family matches a recent rotation_history entry
     * (within 2 calendar years), return a string for the UI; else null.
     */
    public static function rotationWarning(array $line, array $candidateCrop, array $cropsById, ?string $today = null): ?string
    {
        $hist = $line['rotation_history'] ?? [];
        if (empty($hist)) return null;
        $cutoffYear = self::yearOf($today) - 2;
        $candFam = $candidateCrop['family'] ?? null;
        if (!$candFam) return null;
        foreach ($hist as $h) {
            $year = (int)($h['year'] ?? 0);
            if ($year < $cutoffYear) continue;
            $hCrop = $cropsById[$h['cropId'] ?? 0] ?? null;
            if (!$hCrop) continue;
            if (($hCrop['family'] ?? null) === $candFam) {
                $name = $hCrop['name'] ?? 'previous crop';
                return "Last grown here: " . $name . " (" . $year . ") — same family. Rotate to rest soil.";
            }
        }
        return null;
    }

    /**
     * Suggestions for an empty/partly-empty line — top 3 crops to try.
     * Ranks: not yet planted on this line, complementary family, fits in remaining space.
     * Returns array of crops (full records).
     */
    public static function getSuggestions(array $line, array $catalog, array $cropsById): array
    {
        $planted = [];
        foreach (($line['plantings'] ?? []) as $p) {
            $planted[(int)$p['cropId']] = true;
        }
        $families = [];
        foreach (($line['plantings'] ?? []) as $p) {
            $c = $cropsById[$p['cropId']] ?? null;
            if ($c && !empty($c['family'])) $families[$c['family']] = true;
        }
        $fill = self::computeFill($line, $cropsById);
        $remaining = $fill['remaining'];

        $ranked = [];
        foreach ($catalog as $c) {
            if (isset($planted[(int)$c['id']])) continue;
            // skip rotation-warned (avoid suggesting clashes)
            if (self::rotationWarning($line, $c, $cropsById)) continue;
            $score = 0;
            $fam = $c['family'] ?? 'other';
            if (isset($families['root'])  && $fam === 'leaf')   $score += 3;
            if (isset($families['leaf'])  && $fam === 'root')   $score += 3;
            if (isset($families['fruit']) && $fam === 'herb')   $score += 3;
            if (isset($families['herb'])  && $fam === 'fruit')  $score += 2;
            if (isset($families['legume']) && $fam !== 'legume') $score += 2;
            if (empty($families))                                $score += 1; // bare line: anything OK
            if ((int)($c['spacing_cm'] ?? 0) <= 15)              $score += 1;
            // require it to fit
            $sp = (int)($c['spacing_cm'] ?? 999);
            if ($sp > $remaining)                                $score -= 5;
            $ranked[] = ['crop' => $c, 'score' => $score];
        }
        usort($ranked, fn($a, $b) => $b['score'] <=> $a['score']);
        $top = array_slice($ranked, 0, 3);
        return array_map(fn($r) => $r['crop'], $top);
    }

    /**
     * Default plant count when accepting a suggestion / tap-to-plant.
     * 1 if spacing >= 25cm, else floor(remaining / spacing / 4), min 1.
     */
    public static function defaultPlantCount(array $crop, int $remainingCm): int
    {
        $sp = max(1, (int)($crop['spacing_cm'] ?? 5));
        if ($sp >= 25) return 1;
        $n = (int)floor(max(0, $remainingCm) / $sp / 4);
        return max(1, $n);
    }

    /**
     * Compute the highest-priority Action for one bed.
     *
     * $bed = ['status'=>str, 'lines'=>[$line,...], 'last_watered_at'=>?str, ...]
     * Each line carries 'plantings', 'status', 'last_watered_at'.
     * Returns array of actions; consumer should pick the first (highest urgency).
     */
    public static function bedActions(array $bed, array $cropsById, ?string $today = null): array
    {
        $today = $today ?: self::todayIso();
        $actions = [];

        $bedStatus = $bed['status'] ?? null;

        // Pre-compute aggregate status across lines
        $hasGrowing = false; $hasEmpty = false; $hasPlanned = false; $hasHarvested = false;
        foreach (($bed['lines'] ?? []) as $line) {
            $st = $line['status'] ?? 'empty';
            if ($st === 'growing')   $hasGrowing = true;
            if ($st === 'empty')     $hasEmpty = true;
            if ($st === 'planned')   $hasPlanned = true;
            if ($st === 'harvested') $hasHarvested = true;

            if ($st === 'growing') {
                $watered = $line['last_watered_at'] ?? ($bed['last_watered_at'] ?? null);
                if ($watered) {
                    $dry = self::daysBetween(substr($watered, 0, 10), $today);
                    if ($dry >= 4) {
                        $actions[] = ['kind'=>'water','urgency'=>'high','icon'=>'💧','label'=>"Dry {$dry}d · water today"];
                    }
                }
                $dth = self::daysToLineHarvest($line, $cropsById, $today);
                if ($dth !== null) {
                    if ($dth <= 3 && $dth >= -2) {
                        $actions[] = ['kind'=>'harvest','urgency'=>'high','icon'=>'🌾','label'=>'Ready to harvest'];
                    } elseif ($dth > 3 && $dth <= 10) {
                        $actions[] = ['kind'=>'harvestSoon','urgency'=>'med','icon'=>'⏳','label'=>"Harvest soon · {$dth}d"];
                    }
                }
                // Thin seedlings if any planting is < 20% mature
                foreach (($line['plantings'] ?? []) as $p) {
                    $c = $cropsById[$p['cropId']] ?? null;
                    if (!$c) continue;
                    $m = self::maturity($p, $line, $c, $today);
                    if ($m > 0 && $m < 0.2) {
                        $actions[] = ['kind'=>'thin','urgency'=>'low','icon'=>'✂','label'=>'Thin seedlings'];
                        break;
                    }
                }
            }
            if ($st === 'planned' && !empty($line['succession_starts_on'])) {
                $actions[] = ['kind'=>'sow','urgency'=>'high','icon'=>'🌱','label'=>'Sow scheduled · ' . self::fmtDate($line['succession_starts_on'])];
            } elseif ($st === 'empty') {
                $actions[] = ['kind'=>'plan','urgency'=>'med','icon'=>'🪴','label'=>'Empty · plan a crop'];
            } elseif ($st === 'harvested') {
                $actions[] = ['kind'=>'reset','urgency'=>'low','icon'=>'🔄','label'=>'Reset bed'];
            }
        }

        // Bed-level fallbacks if we have no lines at all
        if (empty($bed['lines'])) {
            if ($bedStatus === 'planned') {
                $actions[] = ['kind'=>'sow','urgency'=>'high','icon'=>'🌱','label'=>'Sow scheduled'];
            } elseif ($bedStatus === 'harvested') {
                $actions[] = ['kind'=>'reset','urgency'=>'low','icon'=>'🔄','label'=>'Reset bed'];
            } else {
                $actions[] = ['kind'=>'plan','urgency'=>'med','icon'=>'🪴','label'=>'Empty · plan a crop'];
            }
        }

        // Sort by urgency rank
        $rank = ['high'=>0, 'med'=>1, 'water'=>2, 'sow'=>3, 'low'=>4];
        usort($actions, fn($a, $b) => ($rank[$a['urgency']] ?? 99) <=> ($rank[$b['urgency']] ?? 99));
        return $actions;
    }

    /**
     * Compass direction (N/NE/E/SE/S/SW/W/NW) of a bed relative to the centroid of
     * its garden's beds. Returns null if at centroid or no GPS.
     */
    public static function bedOrientation(array $bed, array $gardenBeds, ?string $lineDir = null): ?string
    {
        if (empty($bed['gps_lat']) || empty($bed['gps_lng'])) {
            return ($lineDir && in_array($lineDir, ['NS', 'EW'], true)) ? $lineDir : null;
        }
        $lats = []; $lngs = [];
        foreach ($gardenBeds as $b) {
            if (!empty($b['gps_lat']) && !empty($b['gps_lng'])) {
                $lats[] = (float)$b['gps_lat'];
                $lngs[] = (float)$b['gps_lng'];
            }
        }
        if (count($lats) < 2) return null;
        $meanLat = array_sum($lats) / count($lats);
        $meanLng = array_sum($lngs) / count($lngs);
        $dLat = (float)$bed['gps_lat'] - $meanLat;
        $dLng = (float)$bed['gps_lng'] - $meanLng;
        $dist = sqrt($dLat * $dLat + $dLng * $dLng);
        if ($dist < 1e-6) return null;
        // atan2(dLng, dLat) → 0=N, +90=E (clockwise from north)
        $angle = atan2($dLng, $dLat) * 180 / M_PI;
        $idx = ((int)round((($angle + 360) % 360) / 45)) % 8;
        $dirs = ['N','NE','E','SE','S','SW','W','NW'];
        return $dirs[$idx];
    }

    /**
     * Compute the 'startsOn' date for a new succession.
     * If the line has plantings, harvestDate + 3 days; else today + 7.
     */
    public static function nextSuccessionStart(array $line, array $cropsById, ?string $today = null): string
    {
        $today = $today ?: self::todayIso();
        $h = self::lineHarvestDate($line, $cropsById);
        if ($h) {
            return self::addDays($h, 3);
        }
        return self::addDays($today, 7);
    }

    /**
     * Property-level summary counts for the Garden hub "This week" strip.
     * Returns array with keys: harvest, water, sow, plan, thin
     */
    public static function propertySummary(array $beds, array $cropsById, ?string $today = null): array
    {
        $sum = ['harvest'=>0, 'water'=>0, 'sow'=>0, 'plan'=>0, 'thin'=>0];
        foreach ($beds as $bed) {
            $actions = self::bedActions($bed, $cropsById, $today);
            $kinds = array_unique(array_map(fn($a) => $a['kind'], $actions));
            foreach ($kinds as $k) {
                if ($k === 'harvest')                                  $sum['harvest']++;
                if ($k === 'water')                                    $sum['water']++;
                if ($k === 'sow')                                      $sum['sow']++;
                if ($k === 'plan')                                     $sum['plan']++;
                if ($k === 'thin')                                     $sum['thin']++;
            }
        }
        return $sum;
    }

    /**
     * Ground stats for one seed across ALL beds and gardens.
     * Fetches all garden_plantings for the given seed_id, computes harvest dates
     * in PHP (no correlated subqueries), sorts ascending, returns soonest upcoming first.
     *
     * Returns:
     *   plants_in_ground    — total plant count with status growing|sown
     *   plants_planned      — total plant count with status planned
     *   harvest_est_ground  — soonest upcoming harvest date for in-ground rows (ISO string or null)
     *   harvest_est_planned — soonest upcoming harvest date for planned rows (ISO string or null)
     */
    public static function seedGroundStats(DB $db, int $seedId): array
    {
        $empty = ['plants_in_ground'=>0,'plants_planned'=>0,'harvest_est_ground'=>null,'harvest_est_planned'=>null];
        if ($seedId <= 0) return $empty;
        $today = self::todayIso();
        try {
            // Join item_meta to only count lines within the bed's current bed_rows setting.
            // Without this, reducing a bed from 3→1 lines leaves phantom growing records on
            // lines 2 and 3 that inflate the count.
            $rows = $db->fetchAll(
                "SELECT gp.plant_count, gp.status, gp.expected_harvest_at, gp.sown_at, gp.planted_at, s.days_to_maturity
                 FROM garden_plantings gp
                 LEFT JOIN seeds s ON s.id = gp.seed_id
                 LEFT JOIN item_meta im ON im.item_id = gp.item_id AND im.meta_key = 'bed_rows'
                 WHERE gp.seed_id = ?
                   AND gp.status IN ('growing','sown','planned')
                   AND gp.line_number <= CAST(COALESCE(im.meta_value_text, '9999') AS UNSIGNED)",
                [$seedId]
            );
        } catch (\Throwable $e) {
            // Fallback for older installs missing optional columns
            try {
                $rows = $db->fetchAll(
                    "SELECT plant_count, status FROM garden_plantings WHERE seed_id = ? AND status IN ('growing','planned')",
                    [$seedId]
                );
                foreach ($rows as &$r) {
                    $r += ['expected_harvest_at' => null, 'sown_at' => null, 'planted_at' => null, 'days_to_maturity' => null];
                }
                unset($r);
            } catch (\Throwable $e2) {
                return $empty;
            }
        }
        $inGround = 0; $planned = 0; $groundDates = []; $plannedDates = [];
        foreach ($rows as $r) {
            $count = max(1, (int)($r['plant_count'] ?? 1));
            $mat   = (int)($r['days_to_maturity'] ?? 60) ?: 60;
            $harvest = null;
            if (!empty($r['expected_harvest_at']))  $harvest = $r['expected_harvest_at'];
            elseif (!empty($r['sown_at']))           $harvest = date('Y-m-d', strtotime($r['sown_at']." +{$mat} days"));
            elseif (!empty($r['planted_at']))        $harvest = date('Y-m-d', strtotime($r['planted_at']." +{$mat} days"));
            if (in_array($r['status'], ['growing','sown'])) {
                $inGround += $count;
                if ($harvest) $groundDates[] = $harvest;
            } else {
                $planned += $count;
                if ($harvest) $plannedDates[] = $harvest;
            }
        }
        sort($groundDates); sort($plannedDates);
        $upcoming = fn($dates) => array_values(array_filter($dates, fn($d) => $d >= $today));
        $ug = $upcoming($groundDates); $up = $upcoming($plannedDates);
        return [
            'plants_in_ground'    => $inGround,
            'plants_planned'      => $planned,
            'harvest_est_ground'  => $ug[0]  ?? ($groundDates[0]  ?? null),
            'harvest_est_planned' => $up[0]  ?? ($plannedDates[0] ?? null),
        ];
    }

    /**
     * Recalculate seeds.projected_seed_prod_count for the given seed IDs.
     * Projected = sum of plant_count where the planting is currently in the
     * ground OR has a planned date that has already arrived. Excludes phantom
     * lines (line_number > bed_rows). Silent fail.
     *
     * Replaces the old seed_ground_cache table (v3.1.74).
     */
    public static function recalcSeedsProjected(DB $db, array $seedIds): void
    {
        $seedIds = array_values(array_unique(array_filter(array_map('intval', $seedIds), fn($v) => $v > 0)));
        if (empty($seedIds)) return;
        try {
            $ph   = implode(',', array_fill(0, count($seedIds), '?'));
            // Projected = SUM(plants_in_ground × yield_per_plant_kg).
            // Seeds with no yield_per_plant_kg set contribute 0 — nothing can be estimated.
            $rows = $db->fetchAll(
                "SELECT gp.seed_id,
                        SUM(COALESCE(gp.plant_count, 1) * COALESCE(s.yield_per_plant_kg, 0)) AS total
                 FROM garden_plantings gp
                 LEFT JOIN seeds s ON s.id = gp.seed_id
                 LEFT JOIN item_meta im ON im.item_id = gp.item_id AND im.meta_key = 'bed_rows'
                 WHERE gp.seed_id IN ($ph)
                   AND (gp.status IN ('growing','sown')
                        OR (gp.status = 'planned' AND gp.planted_at IS NOT NULL AND gp.planted_at <= CURDATE()))
                   AND gp.line_number <= CAST(COALESCE(im.meta_value_text, '9999') AS UNSIGNED)
                 GROUP BY gp.seed_id",
                $seedIds
            );
            $totals = [];
            foreach ($rows as $r) $totals[(int)$r['seed_id']] = round((float)$r['total'], 3);
            foreach ($seedIds as $sid) {
                $db->execute(
                    "UPDATE seeds SET projected_seed_prod_count = ? WHERE id = ?",
                    [$totals[$sid] ?? 0.0, $sid]
                );
            }
        } catch (\Throwable $e) {
            Logger::error('recalcSeedsProjected failed — ' . $e->getMessage());
        }
    }

    /**
     * Recalculate projected counts for every seed. Used by the daily cron.
     * Returns the number of seeds processed.
     */
    public static function recalcAllSeedsProjected(DB $db): int
    {
        try {
            $seedIds = array_column($db->fetchAll("SELECT id FROM seeds"), 'id');
            if (empty($seedIds)) return 0;
            self::recalcSeedsProjected($db, $seedIds);
            return count($seedIds);
        } catch (\Throwable $e) {
            Logger::error('recalcAllSeedsProjected failed — ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Increment seeds.harvested_seed_prod_count by plantCount × yield_per_plant_kg (lifetime cumulative kg).
     * Called from the harvest flow alongside the seed_harvest_log INSERT.
     * Seeds with no yield_per_plant_kg set are silently skipped — nothing to add.
     */
    public static function addToSeedHarvested(DB $db, int $seedId, int $plantCount): void
    {
        if ($seedId <= 0 || $plantCount <= 0) return;
        try {
            $seed   = $db->fetchOne("SELECT yield_per_plant_kg FROM seeds WHERE id = ?", [$seedId]);
            $yieldKg = ($seed && $seed['yield_per_plant_kg'] !== null) ? (float)$seed['yield_per_plant_kg'] : 0.0;
            $amount  = round($plantCount * $yieldKg, 3);
            if ($amount <= 0) return;
            $db->execute(
                "UPDATE seeds SET harvested_seed_prod_count = harvested_seed_prod_count + ? WHERE id = ?",
                [$amount, $seedId]
            );
        } catch (\Throwable $e) {}
    }

    /**
     * Recalculate projected counts for every seed currently linked to a bed,
     * plus any extra seed IDs (e.g. just-deleted plantings whose seed_id was
     * captured before the row was removed).
     */
    public static function triggerBedRecalc(DB $db, int $bedId, array $extraSeedIds = []): void
    {
        try {
            $rows = $db->fetchAll(
                "SELECT DISTINCT seed_id FROM garden_plantings WHERE item_id = ? AND seed_id IS NOT NULL",
                [$bedId]
            );
            $seedIds = array_column($rows, 'seed_id');
            $merged  = array_values(array_unique(array_merge(
                array_map('intval', $seedIds),
                array_filter(array_map('intval', $extraSeedIds))
            )));
            self::recalcSeedsProjected($db, $merged);
        } catch (\Throwable $e) {}
    }

    /**
     * Return all active garden beds (items with type='bed').
     * Each entry: id, name, garden_name, num_lines.
     */
    public static function getGardenBeds(DB $db): array
    {
        try {
            $beds = $db->fetchAll(
                "SELECT i.id, i.name, p.name AS garden_name,
                        COALESCE(m.meta_value_text, '1') AS bed_rows
                   FROM items i
                   LEFT JOIN items p ON p.id = i.parent_id
                   LEFT JOIN item_meta m ON m.item_id = i.id AND m.meta_key = 'bed_rows'
                  WHERE i.type = 'bed' AND i.deleted_at IS NULL AND i.status = 'active'
                  ORDER BY p.name ASC, i.name ASC"
            );
            foreach ($beds as &$b) {
                $b['num_lines'] = max(1, (int)$b['bed_rows']);
                unset($b['bed_rows']);
            }
            unset($b);
            return $beds;
        } catch (\Throwable $e) {
            return [];
        }
    }

    /**
     * Return line summaries for a bed suitable for the "Add to bed" modal.
     * Each entry: line_number, status, fill_pct (0–100), plants_summary (string).
     */
    public static function getBedLinesForModal(DB $db, int $bedId): array
    {
        try {
            $metaRows = $db->fetchAll(
                "SELECT meta_key, meta_value_text FROM item_meta WHERE item_id = ?",
                [$bedId]
            );
            $meta = [];
            foreach ($metaRows as $r) { $meta[$r['meta_key']] = $r['meta_value_text']; }
            $bedRows  = max(1, (int)($meta['bed_rows'] ?? 1));
            $lengthM  = (float)($meta['bed_length_m'] ?? 0);
            $lengthCm = (int)round($lengthM * 100);
            if ($lengthCm <= 0) $lengthCm = 400;

            $lineRows = $db->fetchAll(
                "SELECT line_number, sown_at, empty_since FROM garden_bed_lines WHERE item_id = ? ORDER BY line_number ASC",
                [$bedId]
            );
            $lineMap = [];
            foreach ($lineRows as $l) { $lineMap[(int)$l['line_number']] = $l; }

            $plantings = $db->fetchAll(
                "SELECT gp.line_number, gp.plant_count, gp.status, gp.seed_id,
                        COALESCE(gp.crop_name, s.name) AS crop_name,
                        COALESCE(s.spacing_cm, 20) AS spacing_cm
                   FROM garden_plantings gp
                   LEFT JOIN seeds s ON s.id = gp.seed_id
                  WHERE gp.item_id = ? AND gp.status IN ('growing','sown','planned')
                  ORDER BY gp.line_number ASC, gp.id ASC",
                [$bedId]
            );
            $plantMap = [];
            foreach ($plantings as $p) {
                $plantMap[(int)$p['line_number']][] = $p;
            }

            $lines = [];
            for ($n = 1; $n <= $bedRows; $n++) {
                $lstate = $lineMap[$n] ?? null;
                $lPlantings = $plantMap[$n] ?? [];
                $usedCm = 0;
                $names  = [];
                foreach ($lPlantings as $p) {
                    $cnt = max(1, (int)($p['plant_count'] ?? 1));
                    $sp  = max(1, (int)($p['spacing_cm'] ?? 20));
                    $usedCm += $cnt * $sp;
                    $names[] = trim(($p['crop_name'] ?? '')) . ($cnt > 1 ? " ×{$cnt}" : '');
                }
                $fillPct = $lengthCm > 0 ? min(100, (int)round($usedCm / $lengthCm * 100)) : 0;

                $status = 'empty';
                if (!empty($lPlantings))                $status = 'growing';
                elseif (!empty($lstate['empty_since'])) $status = 'resting';

                $lines[] = [
                    'line_number'    => $n,
                    'status'         => $status,
                    'fill_pct'       => $fillPct,
                    'plants_summary' => $names ? implode(', ', $names) : '',
                    'sow_date'       => $lstate['sown_at'] ?? null,
                ];
            }
            return $lines;
        } catch (\Throwable $e) {
            return [];
        }
    }
}
