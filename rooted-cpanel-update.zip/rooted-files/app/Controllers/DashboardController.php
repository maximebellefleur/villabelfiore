<?php

namespace App\Controllers;

use App\Support\Request;
use App\Support\Response;
use App\Support\DB;

class DashboardController
{
    private function requireAuth(): void
    {
        if (empty($_SESSION['user_id'])) {
            Response::redirect('/login');
        }
    }

    public function index(Request $request, array $params = []): void
    {
        $this->requireAuth();

        $db = DB::getInstance();

        $itemCounts = $db->fetchAll(
            'SELECT type, COUNT(*) AS cnt FROM items WHERE status = ? AND deleted_at IS NULL GROUP BY type',
            ['active']
        );

        $recentActivity = $db->fetchAll(
            'SELECT * FROM activity_log ORDER BY performed_at DESC LIMIT 10'
        );

        $upcomingReminders = $db->fetchAll(
            "SELECT * FROM reminders WHERE status = 'pending' AND due_at >= NOW() ORDER BY due_at ASC LIMIT 5"
        );

        $overdueReminders = $db->fetchAll(
            "SELECT * FROM reminders WHERE status = 'pending' AND due_at < NOW() ORDER BY due_at ASC LIMIT 5"
        );

        // Harvest totals grouped by item type (current year)
        $harvestByType = $db->fetchAll(
            "SELECT i.type, h.unit, SUM(h.quantity) AS total
             FROM harvest_entries h
             JOIN items i ON i.id = h.item_id
             WHERE YEAR(h.recorded_at) = YEAR(NOW())
             GROUP BY i.type, h.unit
             ORDER BY i.type, h.unit"
        );
        // Reindex: ['olive_tree' => ['kg' => 120.5, ...], ...]
        $harvestByTypeMap = [];
        foreach ($harvestByType as $row) {
            $harvestByTypeMap[$row['type']][$row['unit']] = (float)$row['total'];
        }

        $monthlyHarvest = $db->fetchAll(
            "SELECT MONTH(h.recorded_at) AS mo, SUM(h.quantity) AS total, h.unit
             FROM harvest_entries h
             WHERE YEAR(h.recorded_at) = YEAR(NOW())
             GROUP BY MONTH(h.recorded_at), h.unit
             ORDER BY mo",
            []
        );

        $gpsItems = $db->fetchAll(
            "SELECT i.id, i.name, i.type, i.gps_lat, i.gps_lng,
                    (SELECT a.id FROM attachments a
                     WHERE a.item_id = i.id AND a.category = 'identification_photo'
                     AND (a.status = 'active' OR a.status IS NULL) AND a.mime_type LIKE 'image/%'
                     ORDER BY a.id DESC LIMIT 1) AS photo_id
             FROM items i
             WHERE i.gps_lat IS NOT NULL AND i.gps_lng IS NOT NULL
             AND i.status = 'active' AND i.deleted_at IS NULL
             ORDER BY i.name"
        );

        Response::render('dashboard/index', [
            'title'             => 'Dashboard',
            'itemCounts'        => $itemCounts,
            'recentActivity'    => $recentActivity,
            'upcomingReminders' => $upcomingReminders,
            'overdueReminders'  => $overdueReminders,
            'harvestByTypeMap'  => $harvestByTypeMap,
            'monthlyHarvest'    => $monthlyHarvest,
            'gpsItems'          => $gpsItems,
            'weather'           => $this->fetchWeather($db),
            'forecastUrl'       => $this->getSetting($db, 'weather.forecast_url', 'https://www.ilmeteo.it/meteo/rosolini'),
        ]);
    }

    // ── Weather helpers ──────────────────────────────────────────────────────

    private function getSetting(\App\Support\DB $db, string $key, string $default = ''): string {
        $row = $db->fetchOne("SELECT setting_value_text FROM settings WHERE setting_key = ?", [$key]);
        return $row['setting_value_text'] ?? $default;
    }

    private function fetchWeather(\App\Support\DB $db): ?array {
        if ($this->getSetting($db, 'weather.enabled') !== '1') return null;

        // 30-min cache
        $cache = $db->fetchOne("SELECT setting_value_json, updated_at FROM settings WHERE setting_key = 'weather.cache'");
        if ($cache && !empty($cache['setting_value_json'])) {
            $age = time() - (int)strtotime($cache['updated_at'] . ' UTC');
            if ($age < 1800) {
                $d = json_decode($cache['setting_value_json'], true);
                if ($d) return $d;
            }
        }

        $stationUrl = $this->getSetting($db, 'weather.station_url');
        if ($stationUrl) {
            $json = $this->httpGet($stationUrl);
            if ($json) {
                $raw = json_decode($json, true);
                if ($raw) { $parsed = $this->parseStationData($raw); $this->cacheWeather($db, $parsed); return $parsed; }
            }
            return null;
        }

        $lat = $this->getSetting($db, 'weather.lat', '36.82');
        $lng = $this->getSetting($db, 'weather.lng', '14.95');
        $url = "https://api.open-meteo.com/v1/forecast?latitude={$lat}&longitude={$lng}"
             . "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,surface_pressure,wind_speed_10m"
             . "&hourly=temperature_2m,weather_code"
             . "&daily=sunrise,sunset&timezone=Europe%2FRome&forecast_days=1";

        $json = $this->httpGet($url);
        if (!$json) return null;
        $raw = json_decode($json, true);
        if (!$raw || empty($raw['current'])) return null;

        $parsed = $this->parseOpenMeteo($raw);
        $this->cacheWeather($db, $parsed);
        return $parsed;
    }

    private function parseOpenMeteo(array $raw): array {
        $cur  = $raw['current'];
        $code = (int)($cur['weather_code'] ?? 0);
        [$icon, $desc] = $this->weatherCode($code);

        $nowH   = (int)date('G');
        $times  = $raw['hourly']['time'] ?? [];
        $temps  = $raw['hourly']['temperature_2m'] ?? [];
        $codes  = $raw['hourly']['weather_code'] ?? [];
        $hours  = [];
        foreach ($times as $i => $t) {
            $h = (int)substr($t, 11, 2);
            if ($h > $nowH && count($hours) < 4) {
                [$hi] = $this->weatherCode((int)($codes[$i] ?? 0));
                $hours[] = ['time' => substr($t, 11, 5), 'temp' => round($temps[$i] ?? 0), 'icon' => $hi];
            }
        }
        return [
            'temp'    => round((float)($cur['temperature_2m'] ?? 0)),
            'feels'   => round((float)($cur['apparent_temperature'] ?? 0)),
            'humidity'=> (int)($cur['relative_humidity_2m'] ?? 0),
            'pressure'=> round((float)($cur['surface_pressure'] ?? 0)),
            'wind'    => round((float)($cur['wind_speed_10m'] ?? 0)),
            'icon'    => $icon, 'desc' => $desc,
            'sunset'  => substr($raw['daily']['sunset'][0] ?? '', 11, 5),
            'hours'   => $hours, 'source' => 'open-meteo',
        ];
    }

    private function parseStationData(array $raw): array {
        $temp = (float)($raw['temp'] ?? $raw['temperature'] ?? $raw['outdoor']['temperature']['value'] ?? 0);
        $code = (int)($raw['weather_code'] ?? 0);
        [$icon, $desc] = $this->weatherCode($code);
        return [
            'temp'    => round($temp), 'feels' => round($temp),
            'humidity'=> (int)($raw['humidity'] ?? $raw['outdoor']['humidity']['value'] ?? 0),
            'pressure'=> round((float)($raw['pressure'] ?? $raw['baromabs'] ?? 0)),
            'wind'    => round((float)($raw['windspeed'] ?? $raw['wind_speed'] ?? 0)),
            'icon'    => $icon, 'desc' => $desc,
            'sunset'  => '', 'hours' => [], 'source' => 'station',
        ];
    }

    private function weatherCode(int $code): array {
        return match(true) {
            $code === 0  => ['☀️', 'Clear sky'],
            $code <= 2   => ['🌤️', 'Partly cloudy'],
            $code === 3  => ['☁️', 'Overcast'],
            $code <= 48  => ['🌫️', 'Foggy'],
            $code <= 55  => ['🌦️', 'Drizzle'],
            $code <= 65  => ['🌧️', 'Rain'],
            $code <= 75  => ['🌨️', 'Snow'],
            $code <= 82  => ['🌦️', 'Showers'],
            $code <= 86  => ['❄️', 'Snow showers'],
            $code <= 99  => ['⛈️', 'Thunderstorm'],
            default      => ['🌡️', 'N/A'],
        };
    }

    private function cacheWeather(\App\Support\DB $db, array $data): void {
        $db->execute(
            "INSERT INTO settings (setting_key, setting_value_json, value_type, autoload, updated_at)
             VALUES ('weather.cache',?,'json',0,NOW())
             ON DUPLICATE KEY UPDATE setting_value_json=VALUES(setting_value_json),updated_at=NOW()",
            [json_encode($data)]
        );
    }

    private function httpGet(string $url, int $timeout = 5): ?string {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>$timeout,
                CURLOPT_USERAGENT=>'Rooted/1.5',CURLOPT_SSL_VERIFYPEER=>false]);
            $r = curl_exec($ch); curl_close($ch);
            return $r ?: null;
        }
        $ctx = stream_context_create(['http'=>['timeout'=>$timeout,'user_agent'=>'Rooted/1.5']]);
        return @file_get_contents($url, false, $ctx) ?: null;
    }

    public function overview(Request $request, array $params = []): void
    {
        $this->requireAuth();
        $db = DB::getInstance();
        $itemCounts = $db->fetchAll(
            'SELECT type, COUNT(*) AS cnt FROM items WHERE status = ? AND deleted_at IS NULL GROUP BY type',
            ['active']
        );
        Response::render('dashboard/overview', ['title' => 'Overview', 'itemCounts' => $itemCounts]);
    }

    public function map(Request $request, array $params = []): void
    {
        $this->requireAuth();

        $db = DB::getInstance();

        $gpsCount = $db->fetchOne(
            "SELECT COUNT(*) AS cnt FROM items WHERE gps_lat IS NOT NULL AND gps_lng IS NOT NULL
             AND status != 'trashed' AND deleted_at IS NULL"
        );

        $center = $db->fetchOne(
            "SELECT AVG(gps_lat) AS lat, AVG(gps_lng) AS lng FROM items
             WHERE gps_lat IS NOT NULL AND gps_lng IS NOT NULL
             AND status != 'trashed' AND deleted_at IS NULL"
        );

        // Load land boundary and name from settings
        $landBoundarySetting = $db->fetchOne(
            "SELECT setting_value_text FROM settings WHERE setting_key = 'land.boundary_geojson'"
        );
        $landNameSetting = $db->fetchOne(
            "SELECT setting_value_text FROM settings WHERE setting_key = 'app.name'"
        );

        $landBoundaryJson = $landBoundarySetting['setting_value_text'] ?? null;
        $hasLandBoundary  = !empty($landBoundaryJson);

        // If we have a boundary, derive the map center from it instead of item average
        $defaultLat = (float)($center['lat'] ?? 41.9);
        $defaultLng = (float)($center['lng'] ?? 12.5);
        if ($hasLandBoundary) {
            $decoded = json_decode($landBoundaryJson, true);
            $coords  = $decoded['coordinates'][0] ?? [];
            if ($coords) {
                $lats = array_column($coords, 1);
                $lngs = array_column($coords, 0);
                $defaultLat = (array_sum($lats) / count($lats));
                $defaultLng = (array_sum($lngs) / count($lngs));
            }
        }

        $itemTypes = require BASE_PATH . '/config/item_types.php';

        Response::render('dashboard/map', [
            'title'            => 'Land Map',
            'mapEnabled'       => true,
            'gpsCount'         => (int)($gpsCount['cnt'] ?? 0),
            'defaultLat'       => $defaultLat,
            'defaultLng'       => $defaultLng,
            'hasLandBoundary'  => $hasLandBoundary,
            'landBoundaryJson' => $hasLandBoundary ? $landBoundaryJson : 'null',
            'landName'         => $landNameSetting['setting_value_text'] ?? 'My Land',
            'itemTypes'        => $itemTypes,
        ]);
    }

    public function nearby(Request $request, array $params = []): void
    {
        $this->requireAuth();
        Response::render('dashboard/nearby', ['title' => 'Nearby Items']);
    }

    public function reports(Request $request, array $params = []): void
    {
        $this->requireAuth();
        Response::render('dashboard/reports', ['title' => 'Reports — ' . date('Y')]);
    }

    public function apiSummary(Request $request, array $params = []): void
    {
        if (empty($_SESSION['user_id'])) {
            Response::json(['success' => false, 'message' => 'Unauthenticated'], 401);
        }

        $db = DB::getInstance();

        $totalItems = $db->fetchOne('SELECT COUNT(*) AS cnt FROM items WHERE deleted_at IS NULL AND status != ?', ['trashed']);
        $overdueCount = $db->fetchOne("SELECT COUNT(*) AS cnt FROM reminders WHERE status = 'pending' AND due_at < NOW()");

        Response::json([
            'success' => true,
            'data' => [
                'total_items'    => (int) ($totalItems['cnt'] ?? 0),
                'overdue_reminders' => (int) ($overdueCount['cnt'] ?? 0),
            ],
        ]);
    }
}
