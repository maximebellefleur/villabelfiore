/* Rooted — Land Map (Leaflet) */
(function () {
    'use strict';

    // -------------------------------------------------------------------------
    // Type configuration: colors and icons
    // -------------------------------------------------------------------------
    var TYPE_CONFIG = {
        olive_tree:  { color: '#4a7c59', label: 'Olive Tree',   icon: '🫒' },
        almond_tree: { color: '#a0785a', label: 'Almond Tree',  icon: '🌰' },
        vine:        { color: '#7c4fa0', label: 'Vine',         icon: '🍇' },
        tree:        { color: '#2d5a27', label: 'Tree',         icon: '🌳' },
        garden:      { color: '#6abf69', label: 'Garden',       icon: '🥦' },
        bed:         { color: '#c5e1a5', label: 'Garden Bed',   icon: '🌿' },
        orchard:     { color: '#ef8c2f', label: 'Orchard',      icon: '🍊' },
        zone:        { color: '#3c8dbc', label: 'Zone',         icon: '📐' },
        prep_zone:   { color: '#00bcd4', label: 'Prep Zone',    icon: '🔧' },
        water_point: { color: '#2196f3', label: 'Water Point',  icon: '💧' },
        tool:        { color: '#9e9e9e', label: 'Tool',         icon: '🔨' },
        mobile_coop: { color: '#795548', label: 'Mobile Coop',  icon: '🐔' },
        building:    { color: '#607d8b', label: 'Building',     icon: '🏠' },
    };

    var BOUNDARY_TYPES = (typeof MAP_BOUNDARY_TYPES !== 'undefined' && Array.isArray(MAP_BOUNDARY_TYPES))
        ? MAP_BOUNDARY_TYPES
        : ['garden', 'bed', 'orchard', 'zone', 'prep_zone', 'mobile_coop', 'building'];
    var LINE_TYPES = ['line']; // types that draw LineString (rows) not Polygon
    var ALL_DRAWABLE = BOUNDARY_TYPES.concat(LINE_TYPES);

    function typeColor(type) { return (TYPE_CONFIG[type] || { color: '#888' }).color; }
    function typeLabel(type) { return (TYPE_CONFIG[type] || { label: type }).label; }
    function typeIcon(type)  { return (TYPE_CONFIG[type] || { icon: '📍' }).icon; }

    // -------------------------------------------------------------------------
    // Build map
    // -------------------------------------------------------------------------
    var map = L.map('map', { zoomControl: true, maxZoom: 22 }).setView(
        [MAP_DEFAULT_LAT || 41.9, MAP_DEFAULT_LNG || 12.5],
        15
    );

    // Satellite on by default — Google Maps satellite (zoom 21, best rural/agricultural coverage)
    var satelliteLayer = L.tileLayer(
        'https://mt{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',
        { subdomains: ['0','1','2','3'], maxZoom: 22, maxNativeZoom: 21, attribution: 'Map data &copy; Google' }
    ).addTo(map);

    // OSM road overlay (labels on top of satellite)
    var osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 22,
        maxNativeZoom: 19,
        opacity: 0.35,
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    }).addTo(map);

    // Plain OSM base — used when satellite is off
    var plainOsmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 22,
        maxNativeZoom: 19,
        attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    });

    var useSatellite = true;

    // Layer groups
    var layerGroups = {};
    var allItems    = [];
    var markerMap   = {};
    var polygonMap  = {};

    // -------------------------------------------------------------------------
    // Custom marker icon — div-based (reliable emoji on iOS/Android, no SVG text)
    // -------------------------------------------------------------------------
    function makeIcon(type, size) {
        size = size || 28;
        var color = typeColor(type);
        var emoji = typeIcon(type);
        var fs    = Math.round(size * 0.48);
        // Subtle drop-shadow, slightly smaller border, 90% opacity so clusters look lighter
        var html  = '<div style="' +
            'width:' + size + 'px;height:' + size + 'px;' +
            'background:' + color + ';' +
            'border-radius:50%;border:2px solid rgba(255,255,255,0.9);' +
            'box-shadow:0 1px 4px rgba(0,0,0,.28);' +
            'display:flex;align-items:center;justify-content:center;' +
            'font-size:' + fs + 'px;line-height:1;cursor:pointer;opacity:0.92;' +
            '">' + emoji + '</div>';
        return L.divIcon({
            html: html,
            className: '',
            iconSize:     [size, size],
            iconAnchor:   [size / 2, size],
            popupAnchor:  [0, -(size + 2)],
        });
    }

    // -------------------------------------------------------------------------
    // Load items from API
    // -------------------------------------------------------------------------
    function loadItems() {
        fetch(MAP_ITEMS_URL, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (!res.success) return;
                allItems = res.data;
                renderItems(allItems);
                populateBoundarySelect(allItems);
                document.getElementById('mapItemCount').textContent =
                    allItems.filter(function (i) { return i.lat; }).length + ' items on map';
            })
            .catch(function () {
                document.getElementById('mapItemCount').textContent = 'Could not load items';
            });
    }

    function renderItems(items) {
        Object.keys(layerGroups).forEach(function (t) { map.removeLayer(layerGroups[t]); });
        layerGroups = {};
        markerMap   = {};
        polygonMap  = {};

        items.forEach(function (item) {
            if (!layerGroups[item.type]) {
                layerGroups[item.type] = L.layerGroup().addTo(map);
            }
            // Polygon takes priority: if an item has a boundary, the polygon IS its position.
            // Don't double-render a pin marker on top of it.
            if (item.boundary) {
                renderBoundary(item);
            } else if (item.lat && item.lng) {
                var marker = L.marker([item.lat, item.lng], { icon: makeIcon(item.type) });
                marker.bindPopup(buildPopup(item));
                marker.on('click', function () { showItemInfo(item); });
                marker.addTo(layerGroups[item.type]);
                markerMap[item.id] = marker;

                if (item.gps_accuracy && BOUNDARY_TYPES.indexOf(item.type) === -1) {
                    L.circle([item.lat, item.lng], {
                        radius: item.gps_accuracy,
                        color: typeColor(item.type),
                        fillColor: typeColor(item.type),
                        fillOpacity: 0.04,
                        weight: 1,
                        opacity: 0.25,
                        interactive: false,
                    }).addTo(layerGroups[item.type]);
                }
            }
        });

        buildLayerToggles();
    }

    function buildPopup(item) {
        var isDrawable  = ALL_DRAWABLE.indexOf(item.type) >= 0;
        var isLine      = LINE_TYPES.indexOf(item.type) >= 0;
        var hasBoundary = !!item.boundary;
        var polyBtn = isDrawable
            ? '<button class="btn btn-secondary btn-xs" onclick="window.mapDrawForItem(' + item.id + ')">' +
              (hasBoundary ? (isLine ? '✏️ Row' : '✏️ Polygon') : (isLine ? '➕ Row' : '➕ Polygon')) +
              '</button>'
            : '';
        return [
            '<div class="map-popup">',
            '<strong>' + typeIcon(item.type) + ' ' + escHtml(item.name) + '</strong>',
            '<div class="map-popup-type">' + typeLabel(item.type) + '</div>',
            item.gps_accuracy ? '<div class="map-popup-acc">GPS ±' + Math.round(item.gps_accuracy) + 'm</div>' : '',
            '<div class="map-popup-actions">',
            '<a href="' + MAP_ITEM_URL + item.id + '" class="btn btn-secondary btn-xs">View</a>',
            polyBtn,
            '</div>',
            '</div>',
        ].join('');
    }

    function showItemInfo(item) {
        var panel       = document.getElementById('itemInfoPanel');
        var content     = document.getElementById('itemInfoContent');
        var isDrawable  = ALL_DRAWABLE.indexOf(item.type) >= 0;
        var isLine      = LINE_TYPES.indexOf(item.type) >= 0;
        var hasBoundary = !!item.boundary;

        var polyHtml = '';
        if (isDrawable) {
            var statusTxt   = hasBoundary
                ? (isLine ? '〰️ Row saved' : '⬡ Polygon saved')
                : (isLine ? 'No row yet'   : 'No polygon yet');
            var statusCls   = hasBoundary ? 'map-info-poly-status--ok' : 'map-info-poly-status--none';
            var btnLabel    = hasBoundary
                ? (isLine ? '✏️ Edit row' : '✏️ Edit polygon')
                : (isLine ? '➕ Draw row' : '➕ Draw polygon');
            polyHtml = '<div class="map-info-poly-row">' +
                '<span class="map-info-poly-status ' + statusCls + '">' + statusTxt + '</span>' +
                '<button class="btn btn-secondary btn-sm" id="infoDrawBtn">' + btnLabel + '</button>' +
                '</div>';
        }

        content.innerHTML = [
            '<p><strong>' + escHtml(item.name) + '</strong></p>',
            '<p class="text-muted text-sm">' + typeLabel(item.type) + '</p>',
            item.lat ? '<p class="text-sm">📍 ' + item.lat.toFixed(6) + ', ' + item.lng.toFixed(6) + '</p>' : '',
            item.gps_accuracy ? '<p class="text-sm">GPS ±' + Math.round(item.gps_accuracy) + 'm</p>' : '',
            polyHtml,
            '<div style="margin-top:10px">',
            '<a href="' + MAP_ITEM_URL + item.id + '" class="btn btn-primary btn-sm">Open item</a>',
            '</div>',
        ].join('');

        panel.style.display = 'block';

        // On mobile, open the sidebar so the info panel is visible
        var sidebar = document.getElementById('mapSidebar');
        if (sidebar && sidebar.classList.contains('map-sidebar--hidden')) {
            sidebar.classList.remove('map-sidebar--hidden');
            var layersBtn = document.getElementById('mapLayersToggle');
            if (layersBtn) layersBtn.classList.remove('map-layers-toggle--active');
            setTimeout(function () { if (window.map && map.invalidateSize) map.invalidateSize(); }, 320);
        }

        var drawBtn = document.getElementById('infoDrawBtn');
        if (drawBtn) {
            drawBtn.addEventListener('click', function () { window.mapDrawForItem(item.id); });
        }
    }

    function renderBoundary(item) {
        var isLine = item.boundary && item.boundary.type === 'LineString';
        var gj = L.geoJSON(item.boundary, {
            style: {
                color: typeColor(item.type),
                weight: isLine ? 5 : 2,
                opacity: isLine ? 0.85 : 0.8,
                fillColor: typeColor(item.type),
                fillOpacity: isLine ? 0 : 0.15,
                lineCap: isLine ? 'round' : 'butt',
            },
        });
        gj.bindTooltip(escHtml(item.name), { sticky: true });
        gj.on('click', function () { showItemInfo(item); });
        gj.addTo(layerGroups[item.type] || map);
        polygonMap[item.id] = gj;

        if (!isLine && item.bed_rows > 0 && item.boundary.type === 'Polygon') {
            renderBedRows(item);
        }
    }

    function renderBedRows(item) {
        var coords = item.boundary.coordinates[0];
        if (!coords || coords.length < 4) return;
        var lats = coords.map(function (c) { return c[1]; });
        var lngs = coords.map(function (c) { return c[0]; });
        var minLat = Math.min.apply(null, lats), maxLat = Math.max.apply(null, lats);
        var minLng = Math.min.apply(null, lngs), maxLng = Math.max.apply(null, lngs);
        var rows = item.bed_rows;
        var step = (maxLat - minLat) / (rows + 1);
        var color = typeColor(item.type);
        var lg = layerGroups[item.type] || map;
        for (var i = 1; i <= rows; i++) {
            var lat = minLat + i * step;
            L.polyline([[lat, minLng], [lat, maxLng]], {
                color: color, weight: 1, opacity: 0.55,
                dashArray: '5 5', interactive: false,
            }).addTo(lg);
        }
    }

    // -------------------------------------------------------------------------
    // Layer toggles
    // -------------------------------------------------------------------------
    function buildLayerToggles() {
        var container = document.getElementById('layerToggles');
        container.innerHTML = '';

        // "Show / Hide all" toggle (re-created each load so it's always inside the container)
        var allLabel = document.createElement('label');
        allLabel.className = 'map-layer-toggle map-layer-toggle--all';
        allLabel.innerHTML = '<input type="checkbox" class="layer-toggle" data-type="all" checked> <strong>Show all</strong>';
        container.appendChild(allLabel);

        Object.keys(layerGroups).sort().forEach(function (type) {
            var count = allItems.filter(function (i) { return i.type === type; }).length;
            var label = document.createElement('label');
            label.className = 'map-layer-toggle';
            var dotClass = LINE_TYPES.indexOf(type) >= 0 ? 'layer-dot layer-dot--line' : 'layer-dot';
            label.innerHTML =
                '<input type="checkbox" class="layer-toggle" data-type="' + type + '" checked> ' +
                '<span class="' + dotClass + '" style="background:' + typeColor(type) + '"></span>' +
                typeLabel(type) + ' <span class="layer-count">(' + count + ')</span>';
            container.appendChild(label);
        });

        // Remove the old static "Show all" label from HTML if it still exists
        var staticAll = document.querySelector('.map-sidebar-section > .map-layer-toggle > input[data-type="all"]');
        if (staticAll) staticAll.closest('label').remove();

        container.addEventListener('change', function (e) {
            if (!e.target.classList.contains('layer-toggle')) return;
            var type = e.target.dataset.type;
            if (type === 'all') {
                var checked = e.target.checked;
                container.querySelectorAll('.layer-toggle:not([data-type="all"])').forEach(function (cb) {
                    cb.checked = checked;
                    toggleLayer(cb.dataset.type, checked);
                });
            } else {
                toggleLayer(type, e.target.checked);
                // Update "all" checkbox state
                var allCb = container.querySelector('.layer-toggle[data-type="all"]');
                var indiv = container.querySelectorAll('.layer-toggle:not([data-type="all"])');
                var allChecked = Array.from(indiv).every(function (cb) { return cb.checked; });
                if (allCb) allCb.checked = allChecked;
            }
        });
    }

    function toggleLayer(type, visible) {
        if (!layerGroups[type]) return;
        if (visible) { map.addLayer(layerGroups[type]); } else { map.removeLayer(layerGroups[type]); }
    }

    // -------------------------------------------------------------------------
    // Add Item — slide-up sheet
    // -------------------------------------------------------------------------
    var addItemMode     = false;
    var addItemMarker   = null;
    var addItemLat      = null;
    var addItemLng      = null;

    var addBtn          = document.getElementById('mapAddItem');
    var addSheet        = document.getElementById('mapAddSheet');
    var addSheetClose   = document.getElementById('mapAddSheetClose');
    var addSheetBackdrop= document.getElementById('mapAddSheetBackdrop');
    var addCoordsText   = document.getElementById('mapAddCoordsText');
    var addTypeSelect   = document.getElementById('mapAddType');
    var addNameInput    = document.getElementById('mapAddName');
    var addErrorDiv     = document.getElementById('mapAddError');
    var addSubmitBtn    = document.getElementById('mapAddSubmit');
    var addOpenFull     = document.getElementById('mapAddOpenFull');

    // -------------------------------------------------------------------------
    // Shared GPS helper — delegates to the unified RootedGPS service
    // -------------------------------------------------------------------------
    function detectGps(onSuccess, statusEl, btn) {
        // Use cached position immediately — never make the user wait if we already have a fix
        var cached = RootedGPS.last();
        if (cached) {
            hideGpsStatus(statusEl);
            onSuccess(cached.lat, cached.lng, cached.accuracy);
            return;
        }
        // No cached fix yet — wait for one
        if (!navigator.geolocation) {
            showGpsStatus(statusEl, '⚠️ Geolocation not supported by your browser.', 'error');
            return;
        }
        // Store innerHTML so SVG icons are preserved after restore
        var origHTML = btn ? btn.innerHTML : '';
        if (btn) { btn.disabled = true; btn.textContent = '⏳'; }
        showGpsStatus(statusEl, '📡 Locating…', 'info');

        RootedGPS.get(function (pos) {
            if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
            if (!pos) {
                showGpsStatus(statusEl, '🔒 Location unavailable — check browser permissions.', 'error');
                return;
            }
            hideGpsStatus(statusEl);
            onSuccess(pos.lat, pos.lng, pos.accuracy);
        }, 0); // wait for any fresh fix from watchPosition
    }

    function showGpsStatus(el, msg, type) {
        if (!el) return;
        el.textContent = msg;
        el.className = 'map-gps-status map-gps-status--' + (type || 'info');
        el.style.display = 'block';
    }

    function hideGpsStatus(el) {
        if (!el) return;
        el.style.display = 'none';
    }

    // -------------------------------------------------------------------------
    // Floating "Locate Me" button — always visible on map
    // -------------------------------------------------------------------------
    (function addLocateMeBtn() {
        var locateBtn = document.createElement('button');
        locateBtn.className = 'map-locate-btn';
        locateBtn.title = 'Locate me';
        locateBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/><circle cx="12" cy="12" r="8" stroke-opacity=".4"/></svg>';

        var locateStatusEl = document.createElement('div');
        locateStatusEl.id = 'locateMeStatus';
        locateStatusEl.style.cssText = 'position:absolute;bottom:80px;left:50%;transform:translateX(-50%);z-index:500;display:none;white-space:nowrap;pointer-events:none;';

        map.getContainer().appendChild(locateBtn);
        map.getContainer().appendChild(locateStatusEl);

        var locateMarker  = null;
        var locateCircle  = null;
        var locatePulse   = null;

        locateBtn.addEventListener('click', function () {
            locateBtn.classList.add('map-locate-btn--active');
            detectGps(function (lat, lng, accuracy) {
                locateBtn.classList.remove('map-locate-btn--active');

                // Remove previous
                if (locateMarker) map.removeLayer(locateMarker);
                if (locateCircle) map.removeLayer(locateCircle);
                if (locatePulse)  map.removeLayer(locatePulse);

                // Accuracy halo
                if (accuracy) {
                    locateCircle = L.circle([lat, lng], {
                        radius: accuracy, color: '#2d6a4f', fillColor: '#2d6a4f',
                        fillOpacity: 0.08, weight: 1.5, dashArray: '4 4',
                    }).addTo(map);
                }

                // Pulsing blue dot
                locateMarker = L.circleMarker([lat, lng], {
                    radius: 9, color: '#fff', weight: 3,
                    fillColor: '#2d6a4f', fillOpacity: 1,
                }).addTo(map);

                map.setView([lat, lng], Math.max(map.getZoom(), 17));
            }, locateStatusEl, locateBtn);
        });
    })();

    // GPS for Add Item sheet
    document.getElementById('mapAddGpsBtn').addEventListener('click', function () {
        var btn = this;
        var statusEl = document.getElementById('mapAddGpsStatus');
        detectGps(function (lat, lng, accuracy) {
            // Place / move the pin
            if (addItemMarker) map.removeLayer(addItemMarker);
            addItemMarker = L.marker([lat, lng], { icon: makeIcon('zone', 36), draggable: true }).addTo(map);
            addItemMarker.on('dragend', function (ev) {
                var ll = ev.target.getLatLng();
                addItemLat = ll.lat; addItemLng = ll.lng;
                addCoordsText.textContent = ll.lat.toFixed(6) + ', ' + ll.lng.toFixed(6);
            });
            addItemLat = lat; addItemLng = lng;
            addCoordsText.textContent = lat.toFixed(6) + ', ' + lng.toFixed(6) +
                (accuracy ? '  ±' + Math.round(accuracy) + 'm' : '');
            map.setView([lat, lng], Math.max(map.getZoom(), 18));
            // Open sheet if it's not already open
            if (!addSheet.classList.contains('open')) {
                openAddSheet(lat, lng);
            }
            // Cancel pin-placement cursor mode — we already have a location
            if (addItemMode) {
                addItemMode = false;
                addBtn.textContent = '✕ Cancel';
                map.getContainer().style.cursor = '';
            }
        }, statusEl, btn);
    });

    // -------------------------------------------------------------------------
    // Precise GPS sampler — collects multiple readings, averages the best ones
    // Stops early once accuracy ≤ goodAccuracy, or after maxDurationMs.
    // onResult(lat, lng, accuracyMetres)
    // -------------------------------------------------------------------------
    function preciseSample(onResult, statusEl, btn, options) {
        options       = options || {};
        var maxMs     = options.maxMs        || 6000;  // max collection window (ms)
        var maxReads  = options.maxReads     || 12;    // hard cap on readings
        var minReads  = options.minReads     || 3;     // collect at least this many
        var goodAcc   = options.goodAcc      || 5;     // stop early if ≤ this accurate (m)

        var readings  = [];
        var watchId   = null;
        var timer     = null;
        var finished  = false;
        var origHTML  = btn ? btn.innerHTML : '';

        if (btn) { btn.disabled = true; btn.textContent = '📡 …'; }
        showGpsStatus(statusEl, '📡 Getting fix…', 'info');

        if (!navigator.geolocation) {
            if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
            showGpsStatus(statusEl, '⚠️ Geolocation not supported.', 'error');
            return;
        }

        function done() {
            if (finished) return;
            finished = true;
            if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
            clearTimeout(timer);
            if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }

            if (!readings.length) {
                showGpsStatus(statusEl, '⚠️ No GPS fix — move to open sky and retry.', 'error');
                return;
            }

            // Sort by accuracy (best = lowest value first), average top half
            readings.sort(function (a, b) { return a.acc - b.acc; });
            var keep = Math.max(1, Math.ceil(readings.length / 2));
            var best = readings.slice(0, keep);
            var latSum = 0, lngSum = 0;
            best.forEach(function (r) { latSum += r.lat; lngSum += r.lng; });
            var avgLat  = latSum  / best.length;
            var avgLng  = lngSum  / best.length;
            var bestAcc = best[0].acc;

            onResult(avgLat, avgLng, bestAcc);
        }

        watchId = navigator.geolocation.watchPosition(
            function (pos) {
                if (finished) return;
                var r = { lat: pos.coords.latitude, lng: pos.coords.longitude, acc: pos.coords.accuracy };
                readings.push(r);
                var accDot  = r.acc <= 5 ? '🟢' : r.acc <= 20 ? '🟡' : '🔴';
                var accType = r.acc <= 5 ? 'success' : r.acc <= 20 ? 'warning' : 'error';
                showGpsStatus(statusEl,
                    accDot + ' ' + readings.length + ' fix' + (readings.length > 1 ? 'es' : '') +
                    ' · ±' + Math.round(r.acc) + ' m', accType);
                // Stop early if we have minimum readings AND a good fix
                if (readings.length >= minReads && r.acc <= goodAcc) { done(); return; }
                if (readings.length >= maxReads) { done(); }
            },
            function (err) {
                if (readings.length >= minReads) { done(); return; }
                finished = true;
                if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
                clearTimeout(timer);
                if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
                showGpsStatus(statusEl, '🔒 GPS unavailable — check browser permissions.', 'error');
            },
            { enableHighAccuracy: true, maximumAge: 0, timeout: 25000 }
        );

        // Bail-out timer
        timer = setTimeout(function () {
            if (readings.length > 0) { done(); }
            else {
                finished = true;
                if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
                if (btn) { btn.disabled = false; btn.innerHTML = origHTML; }
                showGpsStatus(statusEl, '⚠️ GPS timeout — move to open sky and retry.', 'error');
            }
        }, maxMs);
    }

    // -------------------------------------------------------------------------
    // GPS for Land boundary panel — adds a point at current position
    // -------------------------------------------------------------------------
    document.getElementById('landGpsBtn').addEventListener('click', function () {
        if (landDrawFinished) return;
        var btn = this;
        var statusEl = document.getElementById('landGpsStatus');
        preciseSample(function (lat, lng, acc) {
            var landIdx = landDrawPoints.length;
            landDrawPoints.push([lat, lng]);
            // Accuracy ring (semi-transparent) shows GPS confidence radius
            var accCircle = L.circle([lat, lng], {
                radius: acc, color: '#2d5a27', fillColor: '#2d5a27',
                fillOpacity: 0.08, weight: 1, dashArray: '3 3', interactive: false,
            }).addTo(map);
            var landDot = L.circleMarker([lat, lng], {
                radius: 7, color: '#2d5a27', fillColor: '#2d5a27', fillOpacity: 1, weight: 2,
            }).addTo(map);
            (function (pIdx, pMarker, pCircle) {
                pMarker.on('click', function (ev) {
                    if (landDrawFinished) return;
                    L.DomEvent.stop(ev);
                    var removed = landTempMarkers.splice(pIdx, landTempMarkers.length - pIdx);
                    removed.forEach(function (m) { map.removeLayer(m); });
                    landDrawPoints.splice(pIdx, landDrawPoints.length - pIdx);
                    if (pCircle) { map.removeLayer(pCircle); }
                    if (landTempPoly) { map.removeLayer(landTempPoly); landTempPoly = null; }
                    updateLandTempLines();
                });
            })(landIdx, landDot, accCircle);
            landTempMarkers.push(landDot);
            updateLandTempLines();
            map.setView([lat, lng], Math.max(map.getZoom(), 18));
            showGpsStatus(statusEl, '✅ Point ' + landDrawPoints.length + ' added · ±' + Math.round(acc) + ' m', 'success');
            showToast('📍 Point ' + landDrawPoints.length + ' saved · ±' + Math.round(acc) + ' m');
            setTimeout(function () { hideGpsStatus(statusEl); }, 3000);
        }, statusEl, btn);
    });

    // GPS for Zone boundary panel
    document.getElementById('zoneGpsBtn').addEventListener('click', function () {
        if (drawingFinished) return; // polygon already closed
        var btn = this;
        var statusEl = document.getElementById('zoneGpsStatus');
        preciseSample(function (lat, lng, acc) {
            var idx = drawnPoints.length;
            drawnPoints.push([lat, lng]);
            var accCircle = L.circle([lat, lng], {
                radius: acc, color: '#e74c3c', fillColor: '#e74c3c',
                fillOpacity: 0.08, weight: 1, dashArray: '3 3', interactive: false,
            }).addTo(map);
            var dot = L.circleMarker([lat, lng], {
                radius: 7, color: '#e74c3c', fillColor: '#e74c3c', fillOpacity: 1, weight: 2,
            }).addTo(map);
            (function (pointIdx, dotMarker, dotCircle) {
                dotMarker.on('click', function (ev) {
                    if (drawingFinished) return;
                    L.DomEvent.stop(ev);
                    var removed = tempMarkers.splice(pointIdx, tempMarkers.length - pointIdx);
                    removed.forEach(function (m) { map.removeLayer(m); });
                    drawnPoints.splice(pointIdx, drawnPoints.length - pointIdx);
                    if (dotCircle) { map.removeLayer(dotCircle); }
                    if (tempPolygon) { map.removeLayer(tempPolygon); tempPolygon = null; }
                    updateTempShape();
                    updateDrawStatus();
                });
            })(idx, dot, accCircle);
            tempMarkers.push(dot);
            updateTempShape();
            map.setView([lat, lng], Math.max(map.getZoom(), 18));
            updateDrawStatus();
            showGpsStatus(statusEl, '✅ Point ' + drawnPoints.length + ' added · ±' + Math.round(acc) + ' m', 'success');
            showToast('📍 Point ' + drawnPoints.length + ' saved · ±' + Math.round(acc) + ' m');
            setTimeout(function () { hideGpsStatus(statusEl); }, 3000);
        }, statusEl, btn);
    });

    addBtn.addEventListener('click', function () {
        if (addItemMode) {
            cancelAddItem();
        } else {
            enterAddItemMode();
        }
    });

    function enterAddItemMode() {
        // Close other draw modes
        if (drawingActive)  toggleDrawMode(false);
        if (landDrawActive) toggleLandDrawMode(false);

        addItemMode = true;
        addBtn.textContent = '✕ Cancel';
        addBtn.classList.add('btn-danger');
        addBtn.classList.remove('btn-primary');
        map.getContainer().style.cursor = 'crosshair';
        showToast('Tap the map to place the item pin');
    }

    function cancelAddItem() {
        addItemMode = false;
        addBtn.textContent = '+ Add Item';
        addBtn.classList.remove('btn-danger');
        addBtn.classList.add('btn-primary');
        map.getContainer().style.cursor = '';
        if (addItemMarker) { map.removeLayer(addItemMarker); addItemMarker = null; }
        closeAddSheet();
    }

    function openAddSheet(lat, lng) {
        addItemLat = lat;
        addItemLng = lng;
        addCoordsText.textContent = lat.toFixed(6) + ', ' + lng.toFixed(6);
        addTypeSelect.value = '';
        addNameInput.value  = '';
        addErrorDiv.style.display = 'none';
        addSheet.classList.add('open');
        addSheet.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        setTimeout(function () { addTypeSelect.focus(); }, 320);

        // Update "Open Full Form" link with pre-filled coords
        addOpenFull.href = addOpenFull.href.split('?')[0] + '?lat=' + lat + '&lng=' + lng;
    }

    function closeAddSheet() {
        addSheet.classList.remove('open');
        addSheet.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
    }

    addSheetClose.addEventListener('click', cancelAddItem);
    addSheetBackdrop.addEventListener('click', cancelAddItem);

    addSubmitBtn.addEventListener('click', function () {
        var type = addTypeSelect.value.trim();
        var name = addNameInput.value.trim();
        addErrorDiv.style.display = 'none';

        if (!type) { showSheetError('Please select an item type.'); addTypeSelect.focus(); return; }
        if (!name) { showSheetError('Please enter a name.'); addNameInput.focus(); return; }
        if (addItemLat === null) { showSheetError('Tap the map to set a location first.'); return; }

        addSubmitBtn.disabled = true;
        addSubmitBtn.textContent = 'Saving…';

        fetch(MAP_API_ITEMS_URL, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: [
                '_token='      + encodeURIComponent(MAP_CSRF_TOKEN),
                'type='        + encodeURIComponent(type),
                'name='        + encodeURIComponent(name),
                'gps_lat='     + encodeURIComponent(addItemLat),
                'gps_lng='     + encodeURIComponent(addItemLng),
                'gps_source=map',
            ].join('&'),
        })
        .then(function (r) { return r.json(); })
        .then(function (res) {
            addSubmitBtn.disabled = false;
            addSubmitBtn.textContent = 'Save Item';
            if (res.success) {
                cancelAddItem();
                loadItems();
                showToast('✅ ' + res.data.name + ' added to map');
            } else {
                var msg = res.message || 'Could not save item.';
                if (res.errors) {
                    msg = Object.values(res.errors).join(' ');
                }
                showSheetError(msg);
            }
        })
        .catch(function () {
            addSubmitBtn.disabled = false;
            addSubmitBtn.textContent = 'Save Item';
            showSheetError('Network error. Please try again.');
        });
    });

    function showSheetError(msg) {
        addErrorDiv.textContent = msg;
        addErrorDiv.style.display = 'block';
    }

    // Simple toast notification
    var toastEl = null;
    function showToast(msg) {
        if (toastEl) { clearTimeout(toastEl._timer); toastEl.remove(); }
        toastEl = document.createElement('div');
        toastEl.className = 'map-toast';
        toastEl.textContent = msg;
        document.body.appendChild(toastEl);
        toastEl._timer = setTimeout(function () { if (toastEl) { toastEl.remove(); toastEl = null; } }, 3500);
    }

    // ── Walk recording overlay — shown ON the map while GPS walk is active ──────
    var _walkOverlayEl  = null;
    var _walkPosMarker  = null;

    function _ensureWalkOverlay() {
        if (_walkOverlayEl) return;
        _walkOverlayEl = document.createElement('div');
        _walkOverlayEl.id = 'walkRecordingOverlay';
        _walkOverlayEl.innerHTML = '<span class="walk-rec-dot"></span><span id="walkRecordingText">Waiting for GPS…</span>';
        _walkOverlayEl.style.display = 'none';
        map.getContainer().appendChild(_walkOverlayEl);
    }

    function showWalkOverlay(text) {
        _ensureWalkOverlay();
        var el = document.getElementById('walkRecordingText');
        if (el) el.textContent = text;
        _walkOverlayEl.style.display = 'flex';
    }

    function hideWalkOverlay() {
        if (_walkOverlayEl) _walkOverlayEl.style.display = 'none';
    }

    function updateWalkPosMarker(lat, lng) {
        if (_walkPosMarker) {
            _walkPosMarker.setLatLng([lat, lng]);
        } else {
            _walkPosMarker = L.circleMarker([lat, lng], {
                radius: 9, color: '#fff', weight: 3,
                fillColor: '#e74c3c', fillOpacity: 1,
                interactive: false,
            }).addTo(map);
        }
    }

    function removeWalkPosMarker() {
        if (_walkPosMarker) { map.removeLayer(_walkPosMarker); _walkPosMarker = null; }
    }

    // -------------------------------------------------------------------------
    // Boundary drawing (accessible from item popup)
    // -------------------------------------------------------------------------
    var drawingActive   = false;
    var drawingFinished = false; // true after Finish button / double-click, blocks new points
    var drawnPoints     = [];
    var tempMarkers     = [];
    var tempPolyline    = null;
    var tempCloseLine   = null; // faint preview line from last point back to first
    var tempPolygon     = null;

    document.getElementById('mapDrawToggle') && document.getElementById('mapDrawToggle').addEventListener('click', function () {
        toggleDrawMode(!drawingActive);
    });

    document.getElementById('cancelDraw').addEventListener('click', function () { toggleDrawMode(false); });
    document.getElementById('clearBoundary').addEventListener('click', clearDraw);
    document.getElementById('finishZoneBoundary').addEventListener('click', function () {
        var itemId = document.getElementById('boundaryItemSelect').value;
        var selectedItem = itemId && allItems.find(function (i) { return String(i.id) === String(itemId); });
        var isLineType = selectedItem && LINE_TYPES.indexOf(selectedItem.type) >= 0;
        if (isLineType) {
            if (drawnPoints.length < 2) { showToast('Need at least 2 points for a row.'); return; }
            // For lines, "finish" just locks drawing and shows Save
            drawingFinished = true;
            if (tempCloseLine) { map.removeLayer(tempCloseLine); tempCloseLine = null; }
            document.getElementById('boundaryStatus').textContent =
                '✅ Row complete (' + drawnPoints.length + ' points). Select item and Save.';
            document.getElementById('finishZoneBoundary').style.display = 'none';
            document.getElementById('saveBoundary').style.display = 'inline-flex';
            map.getContainer().style.cursor = '';
        } else {
            finishPolygon();
        }
    });

    function toggleDrawMode(active) {
        drawingActive   = active;
        drawingFinished = false;
        document.getElementById('boundaryPanel').style.display = active ? 'block' : 'none';
        document.getElementById('finishZoneBoundary').style.display = 'none';
        document.getElementById('saveBoundary').style.display = 'none';
        map.getContainer().style.cursor = active ? 'crosshair' : '';
        if (!active) clearDraw();
        if (active) {
            cancelAddItem();
            // Open sidebar on mobile so controls are visible
            var sidebar = document.getElementById('mapSidebar');
            if (sidebar && sidebar.classList.contains('map-sidebar--hidden')) {
                sidebar.classList.remove('map-sidebar--hidden');
                var layersBtn = document.getElementById('mapLayersToggle');
                if (layersBtn) layersBtn.classList.remove('map-layers-toggle--active');
                setTimeout(function () { if (window.map && map.invalidateSize) map.invalidateSize(); }, 320);
            }
        }
    }

    function clearDraw() {
        // Stop walk mode if active
        if (typeof stopZoneWalk === 'function') stopZoneWalk(false);

        drawingFinished = false;
        drawnPoints = [];
        tempMarkers.forEach(function (m) { map.removeLayer(m); });
        tempMarkers = [];
        if (tempPolyline)  { map.removeLayer(tempPolyline);  tempPolyline  = null; }
        if (tempCloseLine) { map.removeLayer(tempCloseLine); tempCloseLine = null; }
        if (tempPolygon)   { map.removeLayer(tempPolygon);   tempPolygon   = null; }
        document.getElementById('finishZoneBoundary').style.display = 'none';
        document.getElementById('saveBoundary').style.display = 'none';
        map.getContainer().style.cursor = drawingActive ? 'crosshair' : '';
        updateDrawStatus();
    }

    function updateDrawStatus() {
        var itemId = document.getElementById('boundaryItemSelect').value;
        var selectedItem = itemId && allItems.find(function (i) { return String(i.id) === String(itemId); });
        var isLineType = selectedItem && LINE_TYPES.indexOf(selectedItem.type) >= 0;
        if (drawingFinished) return; // status already set by finishPolygon
        document.getElementById('boundaryStatus').textContent =
            drawnPoints.length > 0
                ? drawnPoints.length + ' point(s) placed.' + (isLineType
                    ? ' Add more or Save.'
                    : (drawnPoints.length >= 3 ? ' Tap Finish to close the polygon.' : ' Need at least 3 — keep adding.'))
                : (isLineType ? 'Click map or use GPS to add points (min 2).' : 'Click map or use GPS to place corners (min 3).');
    }

    function updateTempShape() {
        if (tempPolyline)  map.removeLayer(tempPolyline);
        if (tempCloseLine) { map.removeLayer(tempCloseLine); tempCloseLine = null; }

        var itemId = document.getElementById('boundaryItemSelect').value;
        var selectedItem = itemId && allItems.find(function (i) { return String(i.id) === String(itemId); });
        var isLineType = selectedItem && LINE_TYPES.indexOf(selectedItem.type) >= 0;

        if (drawnPoints.length >= 2) {
            tempPolyline = L.polyline(drawnPoints, { color: '#e74c3c', dashArray: '5,5', weight: 2 }).addTo(map);
        }
        // Faint closing line preview (polygon types only, 3+ points)
        if (!isLineType && drawnPoints.length >= 3) {
            tempCloseLine = L.polyline(
                [drawnPoints[drawnPoints.length - 1], drawnPoints[0]],
                { color: '#e74c3c', dashArray: '3,10', weight: 1.5, opacity: 0.45 }
            ).addTo(map);
        }
        // Show Finish button once there are enough points
        var minPts = isLineType ? 2 : 3;
        document.getElementById('finishZoneBoundary').style.display =
            (!drawingFinished && drawnPoints.length >= minPts) ? 'inline-flex' : 'none';
    }

    function finishPolygon() {
        if (drawnPoints.length < 3) return;
        drawingFinished = true;
        if (tempPolyline)  { map.removeLayer(tempPolyline);  tempPolyline  = null; }
        if (tempCloseLine) { map.removeLayer(tempCloseLine); tempCloseLine = null; }
        if (tempPolygon)   { map.removeLayer(tempPolygon); }
        tempPolygon = L.polygon(drawnPoints, {
            color: '#e74c3c', fillColor: '#e74c3c', fillOpacity: 0.2, weight: 2,
        }).addTo(map);
        document.getElementById('boundaryStatus').textContent =
            '✅ Polygon closed (' + drawnPoints.length + ' points). Select an item below and tap Save.';
        document.getElementById('finishZoneBoundary').style.display = 'none';
        document.getElementById('saveBoundary').style.display = 'inline-flex';
        map.getContainer().style.cursor = '';
    }

    document.getElementById('saveBoundary').addEventListener('click', function () {
        var itemId = document.getElementById('boundaryItemSelect').value;
        if (!itemId) { alert('Please select an item to assign the boundary to.'); return; }

        var selectedItem = allItems.find(function (i) { return String(i.id) === String(itemId); });
        var isLineType = selectedItem && LINE_TYPES.indexOf(selectedItem.type) >= 0;

        var geojson;
        if (isLineType) {
            if (drawnPoints.length < 2) {
                alert('Draw at least 2 points for a planting row.'); return;
            }
            geojson = {
                type: 'LineString',
                coordinates: drawnPoints.map(function (p) { return [p[1], p[0]]; }),
            };
        } else {
            if (drawnPoints.length < 3 && !tempPolygon) {
                alert('Draw a polygon first (at least 3 points, double-click to finish).'); return;
            }
            if (!tempPolygon && drawnPoints.length >= 3) finishPolygon();
            geojson = {
                type: 'Polygon',
                coordinates: [drawnPoints.map(function (p) { return [p[1], p[0]]; })],
            };
            geojson.coordinates[0].push(geojson.coordinates[0][0]);
        }

        var status = document.getElementById('boundaryStatus');
        status.textContent = 'Saving…';

        fetch(MAP_BOUNDARY_URL + itemId, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: '_token=' + encodeURIComponent(MAP_CSRF_TOKEN) +
                  '&geojson=' + encodeURIComponent(JSON.stringify(geojson)),
        })
        .then(function (r) { return r.json(); })
        .then(function (res) {
            if (res.success) {
                status.textContent = '✅ ' + res.message;
                toggleDrawMode(false);
                loadItems();
            } else {
                status.textContent = '❌ ' + res.message;
            }
        })
        .catch(function () { status.textContent = '❌ Network error. Try again.'; });
    });

    window.mapDrawForItem = function (id) {
        toggleDrawMode(true);
        document.getElementById('boundaryItemSelect').value = id;
    };

    // -------------------------------------------------------------------------
    // Populate boundary item select
    // -------------------------------------------------------------------------
    function populateBoundarySelect(items) {
        var sel = document.getElementById('boundaryItemSelect');
        sel.innerHTML = '<option value="">— pick item —</option>';
        var candidates = items.filter(function (i) { return ALL_DRAWABLE.indexOf(i.type) >= 0; });
        candidates.sort(function (a, b) { return a.type.localeCompare(b.type) || a.name.localeCompare(b.name); });
        candidates.forEach(function (item) {
            var opt = document.createElement('option');
            opt.value = item.id;
            opt.textContent = typeLabel(item.type) + ': ' + item.name;
            sel.appendChild(opt);
        });
    }

    // -------------------------------------------------------------------------
    // Land boundary — render + draw + save
    // -------------------------------------------------------------------------
    var landBoundaryLayer = null;

    // Dedicated pane for the land perimeter — pointer-events:none at CSS level
    // so the polygon NEVER intercepts clicks, even on its fill area.
    // Must be created before renderLandBoundary is first called.
    map.createPane('landBoundaryPane');
    map.getPane('landBoundaryPane').style.pointerEvents = 'none';
    map.getPane('landBoundaryPane').style.zIndex = '350'; // below item polygons (overlayPane=400)

    function renderLandBoundary(geojson) {
        if (landBoundaryLayer) { map.removeLayer(landBoundaryLayer); }
        if (!geojson) return;
        landBoundaryLayer = L.geoJSON(geojson, {
            pane: 'landBoundaryPane',
            interactive: false,
            style: {
                color: '#2d5a27', weight: 3, opacity: 1,
                dashArray: '8 4',
                fillColor: '#2d5a27', fillOpacity: 0.05,
            },
        });
        landBoundaryLayer.addTo(map);
    }

    if (MAP_LAND_BOUNDARY) {
        renderLandBoundary(MAP_LAND_BOUNDARY);
        if (landBoundaryLayer) {
            map.fitBounds(landBoundaryLayer.getBounds(), { padding: [40, 40] });
        }
    }

    // -------------------------------------------------------------------------
    // Geo utilities — used by walk mode
    // -------------------------------------------------------------------------

    /** Haversine distance in metres between two [lat,lng] points */
    function haversineM(lat1, lng1, lat2, lng2) {
        var R   = 6371000;
        var dLat = (lat2 - lat1) * Math.PI / 180;
        var dLng = (lng2 - lng1) * Math.PI / 180;
        var a   = Math.sin(dLat/2) * Math.sin(dLat/2)
                + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180)
                * Math.sin(dLng/2) * Math.sin(dLng/2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /**
     * Ramer-Douglas-Peucker simplification.
     * points: [[lat,lng]…], tolerance: metres
     * Returns reduced [[lat,lng]…] array.
     */
    function rdp(points, toleranceM) {
        if (points.length < 3) return points.slice();
        var dmax = 0, idx = 0;
        var a = points[0], b = points[points.length - 1];
        for (var i = 1; i < points.length - 1; i++) {
            var d = pointSegDistM(points[i], a, b);
            if (d > dmax) { dmax = d; idx = i; }
        }
        if (dmax > toleranceM) {
            var left  = rdp(points.slice(0, idx + 1), toleranceM);
            var right = rdp(points.slice(idx),         toleranceM);
            return left.slice(0, -1).concat(right);
        }
        return [a, b];
    }

    /** Perpendicular distance from point p to segment [a,b] in metres */
    function pointSegDistM(p, a, b) {
        var dx = b[0] - a[0], dy = b[1] - a[1];
        if (dx === 0 && dy === 0) return haversineM(p[0], p[1], a[0], a[1]);
        var t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy);
        t = Math.max(0, Math.min(1, t));
        return haversineM(p[0], p[1], a[0] + t * dx, a[1] + t * dy);
    }

    // -------------------------------------------------------------------------
    // Walk-perimeter mode — shared constants
    // -------------------------------------------------------------------------
    var WALK_MIN_DIST_M  = 1.5;  // record a new point only every 1.5 m
    var WALK_MAX_ACC_M   = 25;   // skip readings worse than 25 m accuracy (relaxed for rural areas)
    var WALK_SIMPLIFY_M  = 0.8;  // RDP tolerance: keep points that deviate > 0.8 m

    // -------------------------------------------------------------------------
    // Walk mode shared: Wake Lock to keep screen on while recording
    // -------------------------------------------------------------------------
    var _walkWakeLock = null;
    function _acquireWakeLock() {
        if ('wakeLock' in navigator) {
            navigator.wakeLock.request('screen').then(function (wl) {
                _walkWakeLock = wl;
            }).catch(function () { /* silently ignore — not critical */ });
        }
    }
    function _releaseWakeLock() {
        if (_walkWakeLock) { _walkWakeLock.release(); _walkWakeLock = null; }
    }

    // -------------------------------------------------------------------------
    // Walk mode for LAND boundary
    // Uses RootedGPS.subscribe — no competing watchPosition, works on iOS/Android
    // -------------------------------------------------------------------------
    var landWalkActive    = false;
    var landWalkUnsub     = null;    // unsubscribe handle from RootedGPS
    var landWalkPts       = [];
    var landWalkLine      = null;
    var landWalkLastLat   = null;
    var landWalkLastLng   = null;
    var landWalkDist      = 0;

    document.getElementById('landWalkBtn').addEventListener('click', function () {
        if (!navigator.geolocation) {
            alert('Geolocation is not available on this device/browser.');
            return;
        }
        startLandWalk();
    });

    document.getElementById('landWalkStopBtn').addEventListener('click', function () {
        stopLandWalk(true);
    });

    function startLandWalk() {
        clearLandDraw();

        landWalkActive  = true;
        landWalkPts     = [];
        landWalkDist    = 0;
        landWalkLastLat = null;
        landWalkLastLng = null;

        document.getElementById('landWalkBtn').style.display    = 'none';
        document.getElementById('landWalkActive').style.display = 'block';
        document.getElementById('landWalkStats').innerHTML      =
            '<span class="walk-recording-dot"></span> Waiting for GPS fix…';
        document.getElementById('landGpsBtn').disabled = true;

        showWalkOverlay('Waiting for GPS…');
        _acquireWakeLock();

        // Use shared RootedGPS stream — no competing watchPosition
        landWalkUnsub = window.RootedGPS
            ? RootedGPS.subscribe(onLandWalkPos)
            : (function () {
                // Fallback if gps.js not loaded yet (shouldn't happen in practice)
                var wid = navigator.geolocation.watchPosition(
                    function (p) { onLandWalkPos({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy }); },
                    function () {},
                    { enableHighAccuracy: true, maximumAge: 0 }
                );
                return function () { navigator.geolocation.clearWatch(wid); };
            })();
    }

    function onLandWalkPos(gpsPos) {
        if (!landWalkActive) return;
        if (!gpsPos) {
            // null = permission denied from RootedGPS
            stopLandWalk(false);
            document.getElementById('landBoundaryStatus').textContent =
                '🔒 GPS access denied — enable Location in browser settings.';
            return;
        }
        var lat = gpsPos.lat;
        var lng = gpsPos.lng;
        var acc = gpsPos.accuracy;

        var statsEl = document.getElementById('landWalkStats');

        // Reject noisy readings
        if (acc > WALK_MAX_ACC_M) {
            statsEl.innerHTML = '<span class="walk-recording-dot"></span>' +
                '⚠️ Weak signal ±' + Math.round(acc) + ' m — move to open sky';
            showWalkOverlay('⚠️ Weak GPS ±' + Math.round(acc) + ' m');
            updateWalkPosMarker(lat, lng);
            return;
        }

        updateWalkPosMarker(lat, lng);

        // Distance gate — only record if moved enough
        if (landWalkLastLat !== null) {
            var ldist = haversineM(landWalkLastLat, landWalkLastLng, lat, lng);
            if (ldist < WALK_MIN_DIST_M) {
                var lMovingText = landWalkPts.length + ' pts · ' + Math.round(landWalkDist) + ' m · ±' + Math.round(acc) + ' m';
                statsEl.innerHTML = '<span class="walk-recording-dot"></span>' + lMovingText;
                showWalkOverlay('⏺ REC · ' + lMovingText);
                return;
            }
            landWalkDist += ldist;
        }

        landWalkLastLat = lat;
        landWalkLastLng = lng;
        landWalkPts.push([lat, lng]);

        // Update live polyline
        if (landWalkLine) {
            landWalkLine.setLatLngs(landWalkPts);
        } else {
            landWalkLine = L.polyline(landWalkPts, {
                color: '#2d5a27', weight: 3, opacity: 0.85,
            }).addTo(map);
        }

        // Keep map centred on the walker
        map.panTo([lat, lng]);

        var lDistLabel = landWalkDist >= 1000
            ? (landWalkDist / 1000).toFixed(2) + ' km'
            : Math.round(landWalkDist) + ' m';
        var lStatsText = landWalkPts.length + ' pts · ' + lDistLabel + ' · ±' + Math.round(acc) + ' m';
        statsEl.innerHTML = '<span class="walk-recording-dot"></span>' + lStatsText;
        showWalkOverlay('⏺ REC · ' + lStatsText);
    }

    function stopLandWalk(usePath) {
        if (!landWalkActive && landWalkUnsub === null) return;
        landWalkActive = false;
        if (landWalkUnsub) { landWalkUnsub(); landWalkUnsub = null; }
        _releaseWakeLock();
        hideWalkOverlay();
        removeWalkPosMarker();

        document.getElementById('landWalkBtn').style.display    = 'inline-flex';
        document.getElementById('landWalkActive').style.display = 'none';
        document.getElementById('landWalkStats').innerHTML      = '';
        document.getElementById('landGpsBtn').disabled          = false;

        if (landWalkLine) { map.removeLayer(landWalkLine); landWalkLine = null; }

        if (!usePath || landWalkPts.length < 3) {
            if (usePath) {
                document.getElementById('landBoundaryStatus').textContent =
                    '⚠️ Not enough points (' + landWalkPts.length + '). Walk further before stopping.';
            }
            return;
        }

        // Simplify the path using RDP, then close the polygon
        var simplified = rdp(landWalkPts, WALK_SIMPLIFY_M);
        landDrawPoints = simplified;

        // Draw final polygon
        if (landTempPoly) { map.removeLayer(landTempPoly); }
        if (landTempLine) { map.removeLayer(landTempLine); landTempLine = null; }
        if (landTempCloseLine) { map.removeLayer(landTempCloseLine); landTempCloseLine = null; }

        landTempPoly = L.polygon(landDrawPoints, {
            color: '#2d5a27', fillColor: '#2d5a27', fillOpacity: 0.08, weight: 3, dashArray: '8 4',
        }).addTo(map);
        map.fitBounds(landTempPoly.getBounds(), { padding: [40, 40] });

        landDrawFinished = true;
        document.getElementById('landBoundaryStatus').textContent =
            '✅ Path recorded: ' + landDrawPoints.length + ' points · ' +
            Math.round(landWalkDist) + ' m perimeter. Tap Save to confirm.';
        document.getElementById('saveLandBoundary').style.display   = 'inline-flex';
        document.getElementById('finishLandBoundary').style.display = 'none';
    }

    // -------------------------------------------------------------------------
    // Walk mode for ZONE boundary
    // -------------------------------------------------------------------------
    var zoneWalkActive  = false;
    var zoneWalkUnsub   = null;
    var zoneWalkPts     = [];
    var zoneWalkLine    = null;
    var zoneWalkLastLat = null;
    var zoneWalkLastLng = null;
    var zoneWalkDist    = 0;

    document.getElementById('zoneWalkBtn').addEventListener('click', function () {
        if (!navigator.geolocation) {
            alert('Geolocation is not available on this device/browser.');
            return;
        }
        startZoneWalk();
    });

    document.getElementById('zoneWalkStopBtn').addEventListener('click', function () {
        stopZoneWalk(true);
    });

    function startZoneWalk() {
        // Clear any manually placed corners
        clearDraw();

        zoneWalkActive  = true;
        zoneWalkPts     = [];
        zoneWalkDist    = 0;
        zoneWalkLastLat = null;
        zoneWalkLastLng = null;

        document.getElementById('zoneWalkBtn').style.display    = 'none';
        document.getElementById('zoneWalkActive').style.display = 'block';
        document.getElementById('zoneWalkStats').innerHTML      =
            '<span class="walk-recording-dot"></span> Waiting for GPS fix…';

        document.getElementById('zoneGpsBtn').disabled = true;

        showWalkOverlay('Waiting for GPS…');
        _acquireWakeLock();

        zoneWalkUnsub = window.RootedGPS
            ? RootedGPS.subscribe(onZoneWalkPos)
            : (function () {
                var wid = navigator.geolocation.watchPosition(
                    function (p) { onZoneWalkPos({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy }); },
                    function () {},
                    { enableHighAccuracy: true, maximumAge: 0 }
                );
                return function () { navigator.geolocation.clearWatch(wid); };
            })();
    }

    function onZoneWalkPos(gpsPos) {
        if (!zoneWalkActive) return;
        if (!gpsPos) {
            stopZoneWalk(false);
            document.getElementById('boundaryStatus').textContent =
                '🔒 GPS access denied — enable Location in browser settings.';
            return;
        }
        var lat = gpsPos.lat;
        var lng = gpsPos.lng;
        var acc = gpsPos.accuracy;

        var statsEl = document.getElementById('zoneWalkStats');

        if (acc > WALK_MAX_ACC_M) {
            statsEl.innerHTML = '<span class="walk-recording-dot"></span>' +
                '⚠️ Weak signal ±' + Math.round(acc) + ' m — move to open sky';
            showWalkOverlay('⚠️ Weak GPS ±' + Math.round(acc) + ' m');
            updateWalkPosMarker(lat, lng);
            return;
        }

        updateWalkPosMarker(lat, lng);

        if (zoneWalkLastLat !== null) {
            var dist = haversineM(zoneWalkLastLat, zoneWalkLastLng, lat, lng);
            if (dist < WALK_MIN_DIST_M) {
                var movingText = zoneWalkPts.length + ' pts · ' + Math.round(zoneWalkDist) + ' m · ±' + Math.round(acc) + ' m';
                statsEl.innerHTML = '<span class="walk-recording-dot"></span>' + movingText;
                showWalkOverlay('⏺ REC · ' + movingText);
                return;
            }
            zoneWalkDist += dist;
        }

        zoneWalkLastLat = lat;
        zoneWalkLastLng = lng;
        zoneWalkPts.push([lat, lng]);

        if (zoneWalkLine) {
            zoneWalkLine.setLatLngs(zoneWalkPts);
        } else {
            zoneWalkLine = L.polyline(zoneWalkPts, {
                color: '#e74c3c', weight: 3, opacity: 0.85,
            }).addTo(map);
        }

        map.panTo([lat, lng]);

        var distLabel = zoneWalkDist >= 1000
            ? (zoneWalkDist / 1000).toFixed(2) + ' km'
            : Math.round(zoneWalkDist) + ' m';
        var statsText = zoneWalkPts.length + ' pts · ' + distLabel + ' · ±' + Math.round(acc) + ' m';
        statsEl.innerHTML = '<span class="walk-recording-dot"></span>' + statsText;
        showWalkOverlay('⏺ REC · ' + statsText);
    }

    function stopZoneWalk(usePath) {
        if (!zoneWalkActive && zoneWalkUnsub === null) return;
        zoneWalkActive = false;
        if (zoneWalkUnsub) { zoneWalkUnsub(); zoneWalkUnsub = null; }
        _releaseWakeLock();
        hideWalkOverlay();
        removeWalkPosMarker();

        document.getElementById('zoneWalkBtn').style.display    = 'inline-flex';
        document.getElementById('zoneWalkActive').style.display = 'none';
        document.getElementById('zoneWalkStats').innerHTML      = '';
        document.getElementById('zoneGpsBtn').disabled          = false;

        if (zoneWalkLine) { map.removeLayer(zoneWalkLine); zoneWalkLine = null; }

        if (!usePath || zoneWalkPts.length < 3) {
            if (usePath) {
                document.getElementById('boundaryStatus').textContent =
                    '⚠️ Not enough points. Keep walking before stopping.';
            }
            return;
        }

        var simplified = rdp(zoneWalkPts, WALK_SIMPLIFY_M);
        drawnPoints    = simplified;

        if (tempPolyline)  { map.removeLayer(tempPolyline);  tempPolyline  = null; }
        if (tempCloseLine) { map.removeLayer(tempCloseLine); tempCloseLine = null; }
        if (tempPolygon)   { map.removeLayer(tempPolygon); }

        tempPolygon = L.polygon(drawnPoints, {
            color: '#e74c3c', fillColor: '#e74c3c', fillOpacity: 0.2, weight: 2,
        }).addTo(map);
        map.fitBounds(tempPolygon.getBounds(), { padding: [40, 40] });

        drawingFinished = true;
        document.getElementById('boundaryStatus').textContent =
            '✅ Path recorded: ' + drawnPoints.length + ' points · ' +
            Math.round(zoneWalkDist) + ' m perimeter. Select item and Save.';
        document.getElementById('saveBoundary').style.display        = 'inline-flex';
        document.getElementById('finishZoneBoundary').style.display  = 'none';
    }

    // -------------------------------------------------------------------------
    // Land boundary — draw state
    // -------------------------------------------------------------------------
    var landDrawActive    = false;
    var landDrawFinished  = false;
    var landDrawPoints    = [];
    var landTempMarkers   = [];
    var landTempLine      = null;
    var landTempCloseLine = null;
    var landTempPoly      = null;

    document.getElementById('mapDrawLandToggle').addEventListener('click', function () {
        toggleLandDrawMode(!landDrawActive);
    });
    document.getElementById('cancelLandDraw').addEventListener('click', function () { toggleLandDrawMode(false); });
    document.getElementById('clearLandBoundary').addEventListener('click', clearLandDraw);
    document.getElementById('finishLandBoundary').addEventListener('click', function () {
        finishLandPolygon();
    });

    function toggleLandDrawMode(active) {
        landDrawActive   = active;
        landDrawFinished = false;
        document.getElementById('landBoundaryPanel').style.display = active ? 'block' : 'none';
        document.getElementById('mapDrawLandToggle').textContent = active ? '✕ Cancel Land Draw' : '🗺 Set Land Boundary';
        document.getElementById('finishLandBoundary').style.display = 'none';
        document.getElementById('saveLandBoundary').style.display = 'none';
        map.getContainer().style.cursor = active ? 'crosshair' : '';
        if (active) {
            toggleDrawMode(false);
            cancelAddItem();
            // Open sidebar on mobile
            var sidebar = document.getElementById('mapSidebar');
            if (sidebar && sidebar.classList.contains('map-sidebar--hidden')) {
                sidebar.classList.remove('map-sidebar--hidden');
                var layersBtn = document.getElementById('mapLayersToggle');
                if (layersBtn) layersBtn.classList.remove('map-layers-toggle--active');
                setTimeout(function () { if (window.map && map.invalidateSize) map.invalidateSize(); }, 320);
            }
        }
        if (!active) clearLandDraw();
    }

    function clearLandDraw() {
        // Stop walk mode if active
        stopLandWalk(false);

        landDrawFinished = false;
        landDrawPoints = [];
        landTempMarkers.forEach(function (m) { map.removeLayer(m); });
        landTempMarkers = [];
        if (landTempLine)      { map.removeLayer(landTempLine);      landTempLine      = null; }
        if (landTempCloseLine) { map.removeLayer(landTempCloseLine); landTempCloseLine = null; }
        if (landTempPoly)      { map.removeLayer(landTempPoly);      landTempPoly      = null; }
        document.getElementById('finishLandBoundary').style.display = 'none';
        document.getElementById('saveLandBoundary').style.display   = 'none';
        document.getElementById('landBoundaryStatus').textContent = '';
        if (landDrawActive) map.getContainer().style.cursor = 'crosshair';
    }

    function updateLandTempLines() {
        if (landTempLine)      { map.removeLayer(landTempLine);      landTempLine      = null; }
        if (landTempCloseLine) { map.removeLayer(landTempCloseLine); landTempCloseLine = null; }
        if (landDrawPoints.length >= 2) {
            landTempLine = L.polyline(landDrawPoints, { color: '#2d5a27', dashArray: '6 3', weight: 2 }).addTo(map);
        }
        if (landDrawPoints.length >= 3) {
            landTempCloseLine = L.polyline(
                [landDrawPoints[landDrawPoints.length - 1], landDrawPoints[0]],
                { color: '#2d5a27', dashArray: '3,10', weight: 1.5, opacity: 0.4 }
            ).addTo(map);
        }
        // Show/hide Finish button
        document.getElementById('finishLandBoundary').style.display =
            (!landDrawFinished && landDrawPoints.length >= 3) ? 'inline-flex' : 'none';
        document.getElementById('landBoundaryStatus').textContent =
            landDrawPoints.length > 0
                ? landDrawPoints.length + ' point(s) placed.' + (landDrawPoints.length >= 3
                    ? ' Tap Finish Polygon to close the shape.'
                    : ' Keep adding corners.')
                : 'Click the map or use GPS to place corners.';
    }

    function finishLandPolygon() {
        if (landDrawPoints.length < 3) return;
        landDrawFinished = true;
        if (landTempLine)      { map.removeLayer(landTempLine);      landTempLine      = null; }
        if (landTempCloseLine) { map.removeLayer(landTempCloseLine); landTempCloseLine = null; }
        if (landTempPoly) map.removeLayer(landTempPoly);
        landTempPoly = L.polygon(landDrawPoints, {
            color: '#2d5a27', fillColor: '#2d5a27', fillOpacity: 0.08, weight: 3, dashArray: '8 4',
        }).addTo(map);
        document.getElementById('landBoundaryStatus').textContent =
            '✅ Polygon closed (' + landDrawPoints.length + ' points). Tap Save to confirm.';
        document.getElementById('finishLandBoundary').style.display = 'none';
        document.getElementById('saveLandBoundary').style.display   = 'inline-flex';
        map.getContainer().style.cursor = '';
    }

    document.getElementById('saveLandBoundary').addEventListener('click', function () {
        if (landDrawPoints.length < 3) {
            document.getElementById('landBoundaryStatus').textContent = 'Draw the boundary first (at least 3 points).';
            return;
        }
        if (!landTempPoly) finishLandPolygon();

        var geojson = {
            type: 'Polygon',
            coordinates: [landDrawPoints.map(function (p) { return [p[1], p[0]]; })],
        };
        geojson.coordinates[0].push(geojson.coordinates[0][0]);

        var status = document.getElementById('landBoundaryStatus');
        status.textContent = 'Saving…';

        fetch(MAP_LAND_BOUNDARY_URL, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: '_token=' + encodeURIComponent(MAP_CSRF_TOKEN) +
                  '&geojson=' + encodeURIComponent(JSON.stringify(geojson)),
        })
        .then(function (r) { return r.json(); })
        .then(function (res) {
            if (res.success) {
                status.textContent = '✅ ' + res.message;
                renderLandBoundary(geojson);
                var notice = document.getElementById('landBoundaryNotice');
                if (notice) notice.style.display = 'none';
                toggleLandDrawMode(false);
            } else {
                status.textContent = '❌ ' + res.message;
            }
        })
        .catch(function () { status.textContent = '❌ Network error.'; });
    });

    var delLandBtn = document.getElementById('deleteLandBoundary');
    if (delLandBtn) {
        delLandBtn.addEventListener('click', function () {
            if (!confirm('Remove the land boundary?')) return;
            fetch(MAP_LAND_BOUNDARY_URL + '/delete', {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: '_token=' + encodeURIComponent(MAP_CSRF_TOKEN),
            })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.success) {
                    if (landBoundaryLayer) { map.removeLayer(landBoundaryLayer); landBoundaryLayer = null; }
                    document.getElementById('landBoundaryPanel').style.display = 'none';
                }
            });
        });
    }

    // -------------------------------------------------------------------------
    // Map click handler — unified (Add Item / boundary drawing)
    // -------------------------------------------------------------------------
    map.on('click', function (e) {
        // Add Item mode: place/move the pin, then open sheet
        if (addItemMode) {
            if (addItemMarker) map.removeLayer(addItemMarker);
            addItemMarker = L.marker([e.latlng.lat, e.latlng.lng], {
                icon: makeIcon('zone', 36),
                draggable: true,
            }).addTo(map);
            addItemMarker.on('dragend', function (ev) {
                var ll = ev.target.getLatLng();
                addItemLat = ll.lat;
                addItemLng = ll.lng;
                addCoordsText.textContent = ll.lat.toFixed(6) + ', ' + ll.lng.toFixed(6);
            });
            openAddSheet(e.latlng.lat, e.latlng.lng);
            map.getContainer().style.cursor = '';
            addItemMode = false; // one tap is enough; can drag pin after
            addBtn.textContent = '✕ Cancel';
            return;
        }

        // Zone boundary drawing
        if (drawingActive && !drawingFinished) {
            drawnPoints.push([e.latlng.lat, e.latlng.lng]);

            var idx = drawnPoints.length - 1;
            var dot = L.circleMarker([e.latlng.lat, e.latlng.lng], {
                radius: 7, color: '#e74c3c', fillColor: '#e74c3c', fillOpacity: 1,
                weight: 2,
            }).addTo(map);

            // Click on existing point: remove it and all points after it
            (function (pointIdx, dotMarker) {
                dotMarker.on('click', function (ev) {
                    if (drawingFinished) return;
                    L.DomEvent.stop(ev);
                    var removed = tempMarkers.splice(pointIdx, tempMarkers.length - pointIdx);
                    removed.forEach(function (m) { map.removeLayer(m); });
                    drawnPoints.splice(pointIdx, drawnPoints.length - pointIdx);
                    if (tempPolygon) { map.removeLayer(tempPolygon); tempPolygon = null; }
                    updateTempShape();
                    updateDrawStatus();
                });
            })(idx, dot);

            tempMarkers.push(dot);
            updateTempShape();
            updateDrawStatus();
            return;
        }

        // Land boundary drawing
        if (landDrawActive && !landDrawFinished) {
            var lIdx = landDrawPoints.length;
            landDrawPoints.push([e.latlng.lat, e.latlng.lng]);
            var lDot = L.circleMarker([e.latlng.lat, e.latlng.lng], {
                radius: 7, color: '#2d5a27', fillColor: '#2d5a27', fillOpacity: 1, weight: 2,
            }).addTo(map);

            (function (pIdx, pMarker) {
                pMarker.on('click', function (ev) {
                    if (landDrawFinished) return;
                    L.DomEvent.stop(ev);
                    var removed = landTempMarkers.splice(pIdx, landTempMarkers.length - pIdx);
                    removed.forEach(function (m) { map.removeLayer(m); });
                    landDrawPoints.splice(pIdx, landDrawPoints.length - pIdx);
                    if (landTempPoly) { map.removeLayer(landTempPoly); landTempPoly = null; }
                    updateLandTempLines();
                });
            })(lIdx, lDot);

            landTempMarkers.push(lDot);
            updateLandTempLines();
            return;
        }

        // Direct click on map: only place a pin when "+ Add Item" mode is active.
        // (Accidental taps no longer open the sheet unexpectedly.)
    });

    map.on('dblclick', function (e) {
        L.DomEvent.stop(e);
        if (drawingActive   && !drawingFinished   && drawnPoints.length >= 3)     { finishPolygon();     return; }
        if (landDrawActive  && !landDrawFinished  && landDrawPoints.length >= 3)  { finishLandPolygon(); }
    });

    // -------------------------------------------------------------------------
    // Satellite toggle button
    // -------------------------------------------------------------------------
    var satBtn = document.createElement('button');
    satBtn.className = 'btn btn-secondary btn-sm';
    satBtn.textContent = '🗺 Map';
    satBtn.style.cssText = 'position:absolute;top:8px;right:8px;z-index:999;';
    document.getElementById('map').appendChild(satBtn);
    satBtn.addEventListener('click', function () {
        useSatellite = !useSatellite;
        if (useSatellite) {
            map.removeLayer(plainOsmLayer);
            satelliteLayer.addTo(map); osmLayer.addTo(map);
            satBtn.textContent = '🗺 Map';
        } else {
            map.removeLayer(satelliteLayer); map.removeLayer(osmLayer);
            plainOsmLayer.addTo(map);
            satBtn.textContent = '🛰 Satellite';
        }
    });

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    function escHtml(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    // -------------------------------------------------------------------------
    // Boot
    // -------------------------------------------------------------------------
    loadItems();

}());
